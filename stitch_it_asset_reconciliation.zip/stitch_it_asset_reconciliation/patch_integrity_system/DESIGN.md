---
name: Postgres Guardian
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#EFEDED'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#424750'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#727781'
  outline-variant: '#c2c6d1'
  surface-tint: '#2c609d'
  primary: '#002f5a'
  on-primary: '#ffffff'
  primary-container: '#004581'
  on-primary-container: '#86b4f7'
  inverse-primary: '#a5c8ff'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#ffd342'
  on-secondary-container: '#725a00'
  tertiary: '#002d62'
  on-tertiary: '#ffffff'
  tertiary-container: '#00438b'
  on-tertiary-container: '#89b3ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#a5c8ff'
  on-primary-fixed: '#001c3a'
  on-primary-fixed-variant: '#054783'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#edc232'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#d7e3ff'
  tertiary-fixed-dim: '#abc7ff'
  on-tertiary-fixed: '#001b3f'
  on-tertiary-fixed-variant: '#05458d'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
  error-critical: '#BA1A1A'
  surface-subtle: '#FBF9F8'
  outline-muted: '#C1C6D3'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-data:
    fontFamily: monospace
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  section-gap: 32px
  gutter: 16px
  container-padding: 24px
  stack-loose: 12px
  base: 8px
  stack-tight: 4px
---

## Brand & Style
The brand personality is **authoritative, systematic, and mission-critical**. As an enterprise security platform, the UI evokes a sense of "guarded stability" and "active monitoring." 

The design style is **Corporate Modern with a "Command Center" aesthetic**. It utilizes a structured, high-density layout common in technical dashboards but softens it with professional typography and a refined Material-inspired color system. The visual language balances utility (data density) with urgency (high-contrast status indicators), ensuring that critical security vulnerabilities are immediately actionable.

## Colors
The palette is rooted in a **Deep Navy Primary** (#004581) to establish trust and institutional authority. A **Cyber Gold Secondary** (#FCD040) is used sparingly for high-priority actions and "Quick Patch" functions, providing a clear visual bridge to urgency without the alarmism of red.

**Status Colors:**
- **Critical/Error:** A bold red (#BA1A1A) reserved for compliance failures and critical CVEs.
- **Surface System:** Uses a sophisticated range of warm grays (FBF9F8 to EFEDED) to differentiate between navigation, canvas, and container elements without relying on heavy borders.
- **On-Surface:** High-contrast dark grays (#1B1C1C) ensure maximum legibility for data-dense tables.

## Typography
The system relies exclusively on **Inter**, a typeface designed for screen legibility and systematic UI. 

- **Hierarchy:** We use a strict distinction between "Display" (for page titles) and "Label Caps." 
- **Functional Roles:** "Label Caps" are utilized for navigation, table headers, and button text to provide a technical, structured feel.
- **Data Integrity:** A monospaced font is used for Patch IDs, CVE codes, and time-stamps to ensure character alignment in technical audit contexts.
- **Weight Strategy:** Heavy weights (700-900) are used for branding and critical status numbers, while semi-bold (600) handles sectional navigation.

## Layout & Spacing
The layout follows a **Fixed Sidebar + Fluid Content Canvas** model. 

- **Sidebar:** A fixed 256px (64rem) width optimized for navigation hierarchy.
- **Grid:** A 12-column responsive grid for the main canvas, transitioning to a single-column stack on mobile.
- **Rhythm:** An 8px base unit drives all spacing. 
    - Use `section-gap` (32px) to separate major modules.
    - Use `gutter` (16px) for internal card padding and element grouping.
    - Use `stack-tight` (4px) for related label/icon pairs.

## Elevation & Depth
Depth is achieved through **Tonal Layering** rather than heavy drop shadows.

- **Level 0 (Background):** `surface-subtle` (#FBF9F8) for the main canvas.
- **Level 1 (Navigation):** `surface-container-low` (#F5F3F3) with a 1px border.
- **Level 2 (Cards):** `surface-container-lowest` (#FFFFFF) with a `shadow-sm` and a subtle 1px border (`outline-muted`).
- **Urgency Indicators:** Critical cards use a "top-border accent" (4px width) in `error-critical` to denote status without relying on background fills.
- **FAB:** The Floating Action Button is the only element using `shadow-2xl` to denote its position at the top of the Z-index.

## Shapes
The shape language is **Soft and Professional**. 

- **Standard Elements:** Buttons, input fields, and small cards use a default radius of 0.25rem (4px).
- **Navigation/Container Elements:** Active states in the sidebar and main content cards use 0.5rem (8px) for a more approachable feel.
- **Interactive Circles:** Profile images and utility buttons (settings, help) use `rounded-full` for distinct iconographic targets.

## Components
- **Buttons:**
  - *Primary:* Solid `primary` color with white text.
  - *Action (Urgent):* `secondary-container` (Gold) with `on-secondary-container` text.
  - *Ghost/Outline:* 1px `primary` border with `primary` text.
- **Status Chips:** Small, rectangular with high-contrast backgrounds (e.g., Red for Critical, Gold for High). Always paired with `label-caps`.
- **Input Fields:** Flat `surface-container-low` backgrounds with no borders; focus states utilize a 2px `primary` ring.
- **Data Tables:** High-density, zebra-striping via `hover:bg-surface-container`. Headers are always `label-caps` in `on-surface-variant`.
- **Progress Bars:** Thin (6px-8px) with `surface-container-low` tracks and `primary` fills to indicate remediation completion.