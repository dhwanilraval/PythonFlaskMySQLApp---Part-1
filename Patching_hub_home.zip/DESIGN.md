---
name: Patch Integrity System
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#414751'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#727782'
  outline-variant: '#c1c6d3'
  surface-tint: '#075fac'
  primary: '#004581'
  on-primary: '#ffffff'
  primary-container: '#005daa'
  on-primary-container: '#bed7ff'
  inverse-primary: '#a5c8ff'
  secondary: '#745b00'
  on-secondary: '#ffffff'
  secondary-container: '#fcd040'
  on-secondary-container: '#705900'
  tertiary: '#00438b'
  on-tertiary: '#ffffff'
  tertiary-container: '#195baf'
  on-tertiary-container: '#c3d6ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#a5c8ff'
  on-primary-fixed: '#001c3a'
  on-primary-fixed-variant: '#004785'
  secondary-fixed: '#ffe08a'
  secondary-fixed-dim: '#edc232'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574400'
  tertiary-fixed: '#d7e3ff'
  tertiary-fixed-dim: '#abc7ff'
  on-tertiary-fixed: '#001b3f'
  on-tertiary-fixed-variant: '#00458e'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-data:
    fontFamily: monospace
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  gutter: 16px
  section-gap: 32px
  stack-tight: 4px
  stack-loose: 12px
---

## Brand & Style

The design system is engineered for the high-stakes environment of IT security and asset management. It adopts a **Corporate/Modern** aesthetic, heavily drawing from institutional banking principles to communicate reliability, precision, and authority. The primary objective is to instill a sense of "financial-grade" security in the management of digital vulnerabilities.

The interface prioritizes extreme clarity and a structured information architecture. By utilizing a restrained color palette and a rigid grid, the system minimizes cognitive load for security analysts who must process large volumes of critical data. The emotional response is one of calm control and professional stewardship, ensuring that urgent security threats are highlighted without inducing unnecessary panic through cluttered visuals.

## Colors

This design system utilizes a high-contrast, professional palette anchored by **Royal Blue** and **Gold**. The primary blue provides a foundation of institutional trust, while the gold is used sparingly as a "utility accent" to highlight primary actions or key status indicators without overwhelming the professional tone.

- **Primary Blue (#005DAA):** Used for headers, primary buttons, and active states.
- **Secondary Gold (#FED141):** Used for highlighting specific attention-required areas or high-level CTAs.
- **Neutral Grays:** Used for secondary text, borders, and background layering to maintain a crisp, airy feel.
- **Status Semantic Colors:** A dedicated high-visibility palette for vulnerability levels, ensuring immediate recognition of Critical (Deep Red) vs. Low (Forest Green) risks.

## Typography

The system uses **Inter** as its primary typeface to ensure maximum legibility across dense data tables and complex dashboards. The typographic hierarchy is strictly enforced to guide the user's eye from high-level summaries to granular asset details.

- **Headlines:** Set with tighter tracking and heavier weights to provide clear section anchoring.
- **Body Text:** Optimized for readability with a generous line-height of 1.5x.
- **Data Mono:** For technical identifiers like IP addresses, CVE IDs, and patch versions, a monospaced font is used to prevent character confusion.
- **Label Caps:** Used for metadata categories and table headers to provide a distinct visual "header" style that is easily skimmable.

## Layout & Spacing

This design system employs a **Fixed Grid** philosophy for dashboard views to maintain a consistent density, transitioning to a fluid model for data tables. 

The layout relies on a **12-column grid** with a standard 16px gutter. White space is used intentionally as a structural element to separate disparate data sets, avoiding the use of excessive lines which can lead to visual "noise." Margins are generous (24px+) to prevent the UI from feeling cramped, reinforcing the clean, high-end institutional aesthetic.

## Elevation & Depth

Visual hierarchy is achieved primarily through **Tonal Layers** rather than heavy shadows. The background remains a crisp #F5F7F9, with primary content areas housed in pure white (#FFFFFF) containers.

Depth is communicated through:
- **Subtle Surface Offsets:** Lower-level containers use a very light gray stroke (#E1E4E8) instead of shadows.
- **Hover States:** Interactive elements like table rows or cards use a "lift" effect—a soft, low-opacity blue-tinted shadow (0px 4px 12px rgba(0, 93, 170, 0.08)).
- **Modal Overlays:** Use a semi-transparent dark wash (#000000 40%) to focus attention, maintaining a flat but distinct layer.

## Shapes

The shape language is **Soft (0.25rem)**, reflecting a conservative and structured personality. This slight rounding removes the harshness of a purely sharp grid while remaining more professional and "buttoned-up" than a fully rounded or pill-shaped system.

- **Standard Elements:** Buttons, inputs, and small cards use a 4px (0.25rem) radius.
- **Large Containers:** Dashboard widgets and main content panels use an 8px (0.5rem) radius for a slightly more modern feel.
- **Status Indicators:** Small status badges (tags) may use a pill-shape to distinguish them from interactive buttons.

## Components

The component library is built for efficiency and high-density information display.

### Buttons
- **Primary:** Solid Royal Blue (#005DAA) with white text. High contrast, sharp focus.
- **Secondary:** White background with a Royal Blue border and text.
- **Action Gold:** Reserved for the "Apply Patch" or "Deploy" actions to differentiate from navigation-based buttons.

### Data Tables
- **Header:** Light gray background (#F8F9FA) with Label Caps typography.
- **Rows:** 48px height minimum. Zebra striping is avoided in favor of subtle border-bottom separators (#EDF0F2).
- **Status Chips:** High-contrast background with dark text for vulnerability levels (e.g., Red bg for Critical, Orange for High).

### Input Fields
- **Default:** White background with a 1px gray border. On focus, the border thickens to 2px in Royal Blue with a soft blue outer glow.
- **Validation:** Error states use a distinct 1px Red border with a small supporting icon.

### Cards & Widgets
- **Asset Summary:** Cards feature a thick 4px top-border color-coded to the highest vulnerability level found within that asset group.
- **KPI Widgets:** Large numerical displays with "Inter-Bold" and a small trend indicator (arrow + percentage).

### Specialized Components
- **Patch Progress Bar:** A thin, dual-tone bar (Light Blue track, Royal Blue fill) with percentage text placed to the right.
- **Vulnerability Timeline:** A vertical line-based component using dots color-coded by severity to show historical risk patterns.