# Database Migration Service — application package

Frontend + backend for the migration service. **Debezium / Kafka Connect is NOT
included** — the backend drives an external Kafka Connect deployment that you run
yourself (see "External engine requirements").

```
frontend/   React + Material UI app (source + prebuilt dist/)
backend/    Python/Flask API: orchestration, schema translation, CDC applier
```

How it fits together: the UI talks to the Flask API. For each migration the API
creates a Debezium connector on your Kafka Connect (REST), Debezium streams the
source database into Kafka topics, and the API's applier consumes those topics
and writes to the target database. Validation and cutover are API-driven.

---

## 1. Prerequisites

| Need | Version / notes |
|---|---|
| Python | 3.12 (backend) |
| Node | 18+ — only if you rebuild the frontend; a prebuilt `frontend/dist/` is included |
| External engine | Kafka Connect with the Debezium connectors installed (see §2) |
| Test databases | PostgreSQL 16 and/or MariaDB 11 (or MySQL 8) — any reachable instances |

## 2. External engine requirements (your Debezium)

Verified against **Debezium 2.7.3 on Kafka Connect / Kafka 3.7.1**. You need:

- Kafka Connect (distributed mode) with both Debezium connector plugins on its
  `plugin.path`: `debezium-connector-postgres` and `debezium-connector-mysql`.
- Connect REST API reachable from the backend host (default `http://127.0.0.1:8083`).
- Kafka brokers reachable from **both** Connect and the backend host
  (default `127.0.0.1:9092`). The backend's applier consumes migration topics
  directly from Kafka, and the MySQL connector stores its schema history in Kafka.
- PostgreSQL sources: `wal_level = logical` (set + restart), and the connecting
  user needs `REPLICATION` plus `SELECT` on the migrated tables. The app uses the
  `pgoutput` plugin and Debezium's default publication (`dbz_publication`,
  auto-created for the included tables).
- MariaDB / MySQL sources: binary logging enabled with `binlog_format = ROW`;
  the connecting user needs `SELECT`, `REPLICATION SLAVE`, and `REPLICATION CLIENT`.
- Target databases: the connecting user needs `CREATE TABLE` + `INSERT / UPDATE /
  DELETE` (the app creates target tables itself, `IF NOT EXISTS`).

Point the app at your engine either way (both are live — in-app wins):

- Env: `CONNECT_URL`, `KAFKA_BOOTSTRAP` when starting the backend, or
- In the UI: **Settings → Engine** (URL, bootstrap servers, Test, Save).

## 3. Backend setup

```bash
cd backend
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
./run.sh                      # serves on :5000
curl http://127.0.0.1:5000/api/health   # {"ok": true, "connect": {...}}
```

Configuration is environment variables (all optional):

| Variable | Default | Purpose |
|---|---|---|
| `CONNECT_URL` | `http://127.0.0.1:8083` | Kafka Connect REST base URL |
| `KAFKA_BOOTSTRAP` | `127.0.0.1:9092` | Kafka brokers for the applier / schema history |
| `PORT` | `5000` | API port |
| `PW_ORDERS_RO`, `PW_SHOP_RO` | `dbz` | Passwords for the built-in credential refs (below) |
| `PW_TARGET_RW`, `PW_ANALYTICS_RW` | `dbz` | Same, target side |
| `DEVIN_API_KEY` | — | Optional. Without it the code-refactoring track runs as a clearly labeled stub |

State lives in `backend/data/state.json` (created on first run; endpoints and
migrations). Delete it to reset the app — it does not touch any database.

**Credentials model.** Endpoints never store passwords. An endpoint stores a
credential reference (`vault://orders-ro`, `vault://shop-ro`, `vault://target-rw`,
`vault://analytics-rw` — selectable in the endpoint form), and the local vault in
`config.py` maps each ref to the matching `PW_*` env var. The `dbz` default is a
local-demo convenience only — set real passwords via env for any real database.

## 4. Frontend setup

Option A — serve the prebuilt build (no Node needed):

```bash
cd frontend
./serve.sh                    # http://localhost:3000
```

The build finds the API via `frontend/dist/config.js`
(`window.__API_BASE__`, default `http://localhost:5000/api`) — edit that one file
if the backend runs elsewhere.

Option B — develop / rebuild:

```bash
cd frontend
npm install
npm run dev                   # Vite dev server
npm run build                 # regenerates dist/
```

Sign-in is a mock SSO screen (any provider button signs you in) — there is no
real authentication in this build.

## 5. What you need to test in a local environment

Minimum rig: the backend, the frontend, your external Connect/Kafka, and two
databases (one source, one target). For the full matrix, mirror the demo rig:

1. **Create four databases** (names are conventions, not requirements):
   `ordersdb` (PG source), `targetdb` (PG target), `shop` (MariaDB source),
   `targetmy` (MariaDB target). Create a user for them (demo: `dbz` / `dbz`)
   with the grants from §2.
2. **Prepare the PG source**: `ALTER SYSTEM SET wal_level = 'logical';` and
   restart PostgreSQL.
3. **Load the seed data** (5 tables, 34 rows — `customers` 6, `orders` 8,
   `order_items` 12, `products` 5, `audit_log` 3):
   ```bash
   psql -d ordersdb -f backend/seed/seed-postgres.sql
   mysql shop < backend/seed/seed-mariadb.sql
   ```
   Leave the target databases empty — the app creates their tables.
4. **Add the four endpoints** in the UI (Endpoints → Add endpoint), one per
   database, picking the matching credential ref, and run **Test** on each row —
   all four should show a green check with a server version.
5. **Smoke test 1 — same engine (PostgreSQL → PostgreSQL).** New migration
   wizard: source `ordersdb`, target `targetdb`, all tables, launch. On the
   migration page the next-step bar walks you through it: replication reaches
   **Live**, then insert/update/delete a row in the source and watch it appear
   under *Ongoing replication → Live changes*; run validation (5/5 match);
   execute cutover → status **Completed** with the completion summary.
6. **Smoke test 2 — cross engine (MariaDB → PostgreSQL).** Same wizard with the
   MariaDB source; enable the code-refactoring track on its wizard step (any
   repo URL + consent). Expect two extra journey steps: **Schema conversion**
   (per-table type mappings + DDL) and **Code refactoring** (review items with
   before/after diffs you can approve or send back).
7. **Engine settings check.** Settings → Engine: point Connect URL at a wrong
   port and Test (should fail cleanly), restore yours, Save.

## 6. Known prototype limits

- State is a single JSON file and the API is a single process — fine for
  evaluation, not a production topology.
- The code-refactoring track is schema-derived and clearly labeled *simulated*
  in the UI; with `DEVIN_API_KEY` set it opens a real Devin session instead.
- Demo credential defaults (`dbz`) exist for the local rig only.
