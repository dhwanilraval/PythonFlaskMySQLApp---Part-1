#!/usr/bin/env bash
# Serves the production MUI build (dist/) on :3000.
cd "$(dirname "$0")/dist"
exec python3 -m http.server 3000
