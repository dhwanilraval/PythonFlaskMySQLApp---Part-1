import React, { useEffect, useRef, useState } from "react";
import {
  Box,
  Typography,
  Chip,
  Stack,
  Paper,
  Button,
  CircularProgress,
  Switch,
  FormControlLabel,
  Checkbox,
  Divider,
  LinearProgress,
  Grid,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import RadioButtonUncheckedIcon from "@mui/icons-material/RadioButtonUnchecked";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import { StageActivity, stageStatus } from "./StepPanels";
import { friendlyError } from "../errorText";

// --------------------------------------------------------------------------
// local helpers
// --------------------------------------------------------------------------

function relTime(ts) {
  if (!ts) return "—";
  const diff = Date.now() - new Date(ts).getTime();
  if (Number.isNaN(diff)) return "—";
  if (diff < 0) return "just now";
  const s = Math.floor(diff / 1000);
  if (s < 5) return "just now";
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function getPerTableProgress(m) {
  const p = m?.progress;
  if (!p) return [];
  if (Array.isArray(p.tables)) return p.tables;
  if (Array.isArray(p.perTable)) return p.perTable;
  return [];
}

function PanelHeader({ title, status, children }) {
  const STATE_CHIP = {
    pending: { label: "Pending", color: "default", variant: "outlined" },
    running: { label: "Running", color: "info", variant: "filled" },
    completed: { label: "Completed", color: "success", variant: "filled" },
    failed: { label: "Failed", color: "error", variant: "filled" },
    skipped: { label: "Skipped", color: "default", variant: "outlined" },
  };
  const cfg = STATE_CHIP[status] || STATE_CHIP.pending;
  return (
    <Stack
      direction="row"
      alignItems="center"
      justifyContent="space-between"
      sx={{ mb: 2 }}
    >
      <Stack direction="row" spacing={1.5} alignItems="center">
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          {title}
        </Typography>
        <Chip size="small" label={cfg.label} color={cfg.color} variant={cfg.variant} />
      </Stack>
      <Box>{children}</Box>
    </Stack>
  );
}

// --------------------------------------------------------------------------
// ReplicatePanel — the live console
// --------------------------------------------------------------------------

export function ReplicatePanel({ m, notify, onRunStage, runningStage, locked }) {
  const status = stageStatus(m, "replicate");
  const progress = m?.progress || {};
  const [follow, setFollow] = useState(true);
  const [streamExpanded, setStreamExpanded] = useState(false);
  const [changesExpanded, setChangesExpanded] = useState(false);
  const [changesShowAll, setChangesShowAll] = useState(false);
  const [showRawError, setShowRawError] = useState(false);
  const [, forceTick] = useState(0);
  const consoleRef = useRef(null);

  // 1s ticker to keep "last event Xs ago" fresh
  useEffect(() => {
    const id = setInterval(() => forceTick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const events = m?.events || [];
  const latestEvents = events.slice(0, 4);

  useEffect(() => {
    if (follow && consoleRef.current) {
      consoleRef.current.scrollTop = 0; // newest-first: top is newest
    }
  }, [events.length, follow]);

  const isRunningThis = runningStage === "replicate";
  const canRestart =
    status === "failed" || Boolean(progress.error);
  const restartDisabled = locked || isRunningThis || runningStage !== null;

  // ---- Activities derivation ----
  const includedTables = (m?.tables || []).filter((t) => t.include);
  const includedCount = includedTables.length;
  const sourceTotal = includedTables.reduce((sum, t) => sum + (t.rows || 0), 0);
  const eventsApplied = progress.eventsApplied ?? 0;
  const recentChanges = Array.isArray(progress.recentChanges) ? progress.recentChanges : [];
  const tablesByName = {};
  includedTables.forEach((t) => {
    tablesByName[t.name] = t.rows || 0;
  });

  let phase = progress.phase;
  if (!phase) {
    if (status === "failed") phase = "failed";
    else if (progress.snapshotComplete) phase = "streaming";
    else if (status === "running") phase = "loading";
    else phase = "idle";
  }

  let rowStatuses;
  if (status === "completed") {
    rowStatuses = ["done", "done", "done", "done"];
  } else if (phase === "preparing") {
    rowStatuses = ["active", "pending", "pending", "pending"];
  } else if (phase === "loading") {
    rowStatuses = ["done", "active", "pending", "pending"];
  } else if (phase === "streaming") {
    rowStatuses = ["done", "done", "done", "active"];
  } else if (phase === "failed") {
    let failIndex;
    if (!progress.lastEventAt && eventsApplied === 0 && !progress.snapshotComplete) {
      failIndex = 0;
    } else if (!progress.snapshotComplete) {
      failIndex = 1;
    } else {
      failIndex = 3;
    }
    rowStatuses = [0, 1, 2, 3].map((i) =>
      i < failIndex ? "done" : i === failIndex ? "failed" : "pending"
    );
  } else {
    rowStatuses = ["pending", "pending", "pending", "pending"];
  }

  const failedEvent = events.find(
    (e) => e.stage === "replicate" && /fail|error/i.test(e.msg || "")
  );
  const failCaption = failedEvent
    ? friendlyError(failedEvent.msg)
    : "Failed — see the event stream below";

  const defaultCaptions = [
    "Tables & indexes on the target database",
    "Snapshot of the source tables",
    "Debezium connector · Kafka change stream",
    "Streaming live changes",
  ];

  const captions = [...defaultCaptions];
  const labels = [
    "Preparing target",
    "Initial load",
    "Setting up change data capture",
    "Ongoing replication",
  ];

  if (rowStatuses[0] === "done") {
    captions[0] = `${(progress.targetTables ?? includedCount).toLocaleString()} tables prepared`;
  }
  if (rowStatuses[1] === "active") {
    captions[1] = `${eventsApplied.toLocaleString()} of ${sourceTotal.toLocaleString()} rows`;
  } else if (rowStatuses[1] === "done") {
    captions[1] = `${(sourceTotal || eventsApplied).toLocaleString()} rows loaded`;
  }
  if (rowStatuses[2] === "done") {
    captions[2] = "Connector running — changes are being captured";
  }
  if (rowStatuses[3] === "active") {
    captions[3] = `Streaming — last event ${relTime(progress.lastEventAt)}`;
  } else if (status === "completed") {
    captions[3] = "Ended at cutover";
  }
  rowStatuses.forEach((s, i) => {
    if (s === "failed") captions[i] = failCaption;
  });

  const renderIcon = (s) => {
    switch (s) {
      case "done":
        return <CheckCircleIcon sx={{ fontSize: 20 }} color="success" />;
      case "active":
        return (
          <AutorenewIcon
            color="primary"
            sx={{
              fontSize: 20,
              animation: "rep-spin 1.1s linear infinite",
              "@keyframes rep-spin": {
                from: { transform: "rotate(0deg)" },
                to: { transform: "rotate(360deg)" },
              },
            }}
          />
        );
      case "failed":
        return <ErrorOutlineIcon sx={{ fontSize: 20 }} color="error" />;
      default:
        return <RadioButtonUncheckedIcon sx={{ fontSize: 20 }} color="disabled" />;
    }
  };

  const perTableEntries = Object.entries(progress.perTable || {});
  const progressValue =
    sourceTotal > 0 ? Math.min(100, Math.round((100 * eventsApplied) / sourceTotal)) : null;

  return (
    <Box>
      <PanelHeader title="Replicate" status={status}>
        {canRestart && (
          <Button
            size="small"
            variant="outlined"
            color="error"
            disabled={restartDisabled}
            onClick={() => onRunStage?.("replicate")}
            startIcon={isRunningThis ? <CircularProgress size={16} /> : null}
          >
            Restart replication
          </Button>
        )}
      </PanelHeader>

      <Stack spacing={1.5} sx={{ mb: 2 }}>
        {labels.map((label, i) => {
          const s = rowStatuses[i];
          const labelSx =
            s === "done"
              ? { fontWeight: 500 }
              : s === "active"
              ? { fontWeight: 650 }
              : s === "failed"
              ? { fontWeight: 600 }
              : { fontWeight: 400, color: "text.secondary" };
          const captionColor =
            s === "failed" ? "error" : s === "pending" ? "text.disabled" : "text.secondary";

          return (
            <Box key={label}>
              <Stack
                direction="row"
                spacing={1.25}
                alignItems="flex-start"
                onClick={i === 3 ? () => setChangesExpanded((v) => !v) : undefined}
                sx={i === 3 ? { cursor: "pointer" } : undefined}
              >
                <Box sx={{ mt: 0.25, flexShrink: 0 }}>{renderIcon(s)}</Box>
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Typography variant="body2" sx={labelSx}>
                    {label}
                  </Typography>
                  {i === 3 && s === "active" ? (
                    <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mt: 0.25 }}>
                      <Box
                        sx={{
                          width: 8,
                          height: 8,
                          borderRadius: "50%",
                          bgcolor: "success.main",
                          flexShrink: 0,
                          animation: "rep-pulse 1.6s ease-in-out infinite",
                          "@keyframes rep-pulse": {
                            "0%": { opacity: 1 },
                            "50%": { opacity: 0.3 },
                            "100%": { opacity: 1 },
                          },
                        }}
                      />
                      <Typography variant="caption" color="text.secondary">
                        {`Live — ${eventsApplied.toLocaleString()} events applied · last event ${relTime(progress.lastEventAt)}`}
                      </Typography>
                    </Stack>
                  ) : (
                    <Typography variant="caption" color={captionColor} sx={{ display: "block" }}>
                      {captions[i]}
                    </Typography>
                  )}
                  {i === 1 && s === "active" && (
                    <LinearProgress
                      variant={progressValue !== null ? "determinate" : "indeterminate"}
                      value={progressValue !== null ? progressValue : undefined}
                      sx={{ height: 4, borderRadius: 2, mt: 0.75, maxWidth: 320 }}
                    />
                  )}
                  {i === 1 && perTableEntries.length > 0 && (
                    <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mt: 0.75 }}>
                      {perTableEntries.map(([table, applied]) => {
                        const sourceRows = tablesByName[table];
                        const label =
                          sourceRows !== undefined
                            ? `${table}: ${applied.toLocaleString()}/${sourceRows.toLocaleString()}`
                            : `${table}: ${applied.toLocaleString()}`;
                        return (
                          <Chip key={table} size="small" variant="outlined" label={label} />
                        );
                      })}
                    </Stack>
                  )}
                  {i === 3 && changesExpanded && (
                    <Box onClick={(e) => e.stopPropagation()}>
                      {recentChanges.length > 0 && (
                        <Typography
                          variant="caption"
                          color="text.secondary"
                          sx={{ display: "block", mb: 0.5, mt: 1 }}
                        >
                          Live changes
                        </Typography>
                      )}
                      {recentChanges.length === 0 ? (
                        <Typography variant="body2" color="text.secondary">
                          Waiting for changes…
                        </Typography>
                      ) : (
                        <>
                          <Stack spacing={0.5}>
                            {(changesShowAll ? recentChanges : recentChanges.slice(0, 25)).map(
                              (c, idx) => (
                                <Stack
                                  key={`${c.ts}-${idx}`}
                                  direction="row"
                                  spacing={1}
                                  alignItems="center"
                                >
                                  <Typography
                                    variant="caption"
                                    color="text.secondary"
                                    sx={{ minWidth: 52, flexShrink: 0 }}
                                  >
                                    {relTime(c.ts)}
                                  </Typography>
                                  <Typography variant="body2">{c.table}</Typography>
                                  <Chip
                                    size="small"
                                    sx={{ height: 20 }}
                                    label={(c.op || "").toUpperCase()}
                                    color={
                                      c.op === "insert"
                                        ? "success"
                                        : c.op === "update"
                                        ? "info"
                                        : c.op === "delete"
                                        ? "error"
                                        : "default"
                                    }
                                  />
                                  <Typography
                                    variant="body2"
                                    sx={{ fontFamily: "monospace" }}
                                    noWrap
                                  >
                                    {c.key}
                                  </Typography>
                                </Stack>
                              )
                            )}
                          </Stack>
                          {recentChanges.length > 25 && (
                            <Button
                              size="small"
                              onClick={() => setChangesShowAll((v) => !v)}
                              sx={{ mt: 0.5 }}
                            >
                              {changesShowAll
                                ? "Show less"
                                : `Show all ${recentChanges.length} changes`}
                            </Button>
                          )}
                        </>
                      )}
                    </Box>
                  )}
                </Box>
                {i === 3 &&
                  (changesExpanded ? (
                    <ExpandLessIcon sx={{ fontSize: 20, color: "text.secondary" }} />
                  ) : (
                    <ExpandMoreIcon sx={{ fontSize: 20, color: "text.secondary" }} />
                  ))}
              </Stack>
            </Box>
          );
        })}
      </Stack>

      {phase === "failed" && failedEvent && (
        <Box sx={{ mb: 2 }}>
          <Button
            size="small"
            onClick={() => setShowRawError((v) => !v)}
            sx={{ textTransform: "none", px: 0 }}
          >
            Technical details
          </Button>
          {showRawError && (
            <Typography
              variant="caption"
              sx={{ display: "block", fontFamily: "monospace", wordBreak: "break-word" }}
            >
              {failedEvent.msg}
            </Typography>
          )}
        </Box>
      )}

      {status === "completed" && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Replication ended at cutover.
        </Typography>
      )}

      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
        <Typography variant="caption" color="text.secondary">
          Event stream — stage events
        </Typography>
        {streamExpanded && (
          <FormControlLabel
            sx={{ m: 0 }}
            control={
              <Switch
                size="small"
                checked={follow}
                onChange={(e) => setFollow(e.target.checked)}
              />
            }
            label={
              <Typography variant="caption" color="text.secondary">
                Follow live
              </Typography>
            }
          />
        )}
      </Stack>

      {streamExpanded ? (
        <>
          <Paper
            ref={consoleRef}
            variant="outlined"
            sx={{
              bgcolor: "action.hover",
              maxHeight: 260,
              overflowY: "auto",
              p: 1.25,
              fontFamily: "monospace",
              fontSize: 12,
            }}
          >
            {events.length ? (
              events.map((e, i) => (
                <Box key={e.ts + i} sx={{ display: "flex", gap: 1, py: 0.25 }}>
                  <Typography
                    component="span"
                    variant="inherit"
                    color="text.secondary"
                    sx={{ minWidth: 52, flexShrink: 0, fontFamily: "inherit", fontSize: "inherit" }}
                  >
                    {relTime(e.ts)}
                  </Typography>
                  <Typography component="span" variant="inherit" sx={{ fontFamily: "inherit", fontSize: "inherit" }}>
                    {e.msg}
                  </Typography>
                </Box>
              ))
            ) : (
              <Typography variant="caption" color="text.secondary">
                No events yet.
              </Typography>
            )}
          </Paper>
          <Button
            size="small"
            onClick={() => setStreamExpanded(false)}
            sx={{ mt: 0.5 }}
          >
            Show less
          </Button>
        </>
      ) : (
        <>
          <Paper variant="outlined" sx={{ p: 0.5 }}>
            {latestEvents.length ? (
              latestEvents.map((e, i) => (
                <Stack
                  key={e.ts + i}
                  direction="row"
                  spacing={1}
                  alignItems="center"
                  sx={{ px: 1, py: 0.5 }}
                >
                  <Box
                    sx={{
                      width: 6,
                      height: 6,
                      borderRadius: "50%",
                      bgcolor: "info.main",
                      flexShrink: 0,
                    }}
                  />
                  <Typography variant="body2" sx={{ flexGrow: 1 }} noWrap>
                    {e.msg}
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ flexShrink: 0 }}>
                    {relTime(e.ts)}
                  </Typography>
                </Stack>
              ))
            ) : (
              <Typography variant="caption" color="text.secondary" sx={{ px: 1, py: 0.5, display: "block" }}>
                No events yet.
              </Typography>
            )}
          </Paper>
          {events.length > 0 && (
            <Button
              size="small"
              onClick={() => setStreamExpanded(true)}
              sx={{ mt: 0.5 }}
            >
              Show full stream ({events.length})
            </Button>
          )}
        </>
      )}
    </Box>
  );
}

// --------------------------------------------------------------------------
// CutoverPanel — the guided checklist
// --------------------------------------------------------------------------

function ChecklistIcon({ state }) {
  if (state === "done") return <CheckCircleIcon fontSize="small" color="success" />;
  if (state === "blocked") return <ErrorOutlineIcon fontSize="small" color="error" />;
  return <RadioButtonUncheckedIcon fontSize="small" color="disabled" />;
}

export function CutoverPanel({ m, notify, onCutover, runningStage, locked }) {
  const status = stageStatus(m, "cutover");
  const [confirmed, setConfirmed] = useState(false);

  const validation = m?.validation;
  const progress = m?.progress || {};

  const vTables = Array.isArray(validation?.tables)
    ? validation.tables
    : Object.values(validation?.tables || {});

  const validationDone = Boolean(validation?.passed);
  const validationBlocked = Boolean(validation) && !validation.passed;
  const validationState = validationDone ? "done" : validationBlocked ? "blocked" : "pending";
  const validationDetail = validation
    ? `${vTables.filter((t) => t.match).length} of ${vTables.length} tables match`
    : "Not run yet";

  const lastEventFresh =
    progress.lastEventAt &&
    Date.now() - new Date(progress.lastEventAt).getTime() < 30000;
  const caughtUpDone =
    m?.status === "ready" ||
    m?.status === "completed" ||
    (Boolean(progress.snapshotComplete) && Boolean(lastEventFresh));
  const caughtUpState = caughtUpDone ? "done" : "pending";
  const caughtUpDetail = `${(progress.eventsApplied ?? 0).toLocaleString()} events applied`;

  const notLockedDone = m?.status !== "failed" && !progress.error;
  const notLockedState = notLockedDone ? "done" : "blocked";
  const notLockedDetail = notLockedDone
    ? "No blocking errors"
    : progress.error || "Migration is in a failed state";

  const items = [
    { label: "Validation passed", state: validationState, detail: validationDetail },
    { label: "Replication caught up", state: caughtUpState, detail: caughtUpDetail },
    { label: "Migration not locked by errors", state: notLockedState, detail: notLockedDetail },
  ];

  const allTrue = items.every((it) => it.state === "done");
  const canCutover = !locked && Boolean(validation?.passed);
  const isRunningThis = runningStage === "cutover";
  const executeDisabled = !confirmed || !canCutover || locked || isRunningThis;

  const cutoverEvent = (m?.events || []).find((e) => (e.msg || "").startsWith("Cutover"));

  const includedCount = (m?.tables || []).filter((t) => t.include).length;
  const excludedNames = (m?.tables || [])
    .filter((t) => t.include === false)
    .map((t) => t.name || t.table)
    .filter(Boolean);

  const totalRows =
    vTables.length > 0
      ? vTables.reduce((sum, t) => sum + (t.targetRows || 0), 0)
      : progress.eventsApplied;

  const completedTs = m?.completedAt || m?.cutoverAt;

  return (
    <Box>
      <PanelHeader title="Cutover" status={status} />

      <Stack spacing={1.25} sx={{ mb: 2 }}>
        {items.map((it) => (
          <Stack key={it.label} direction="row" spacing={1} alignItems="flex-start">
            <ChecklistIcon state={it.state} />
            <Box>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {it.label}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {it.detail}
              </Typography>
            </Box>
          </Stack>
        ))}
      </Stack>

      {status === "completed" ? (
        <Paper variant="outlined" sx={{ p: 1.5, bgcolor: "action.hover" }}>
          <Stack spacing={0.5}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              Cutover complete
            </Typography>
            {m?.sourceEngine && m?.targetEngine && (
              <Typography variant="caption" color="text.secondary">
                {m.sourceEngine} → {m.targetEngine}
              </Typography>
            )}
            {m?.tables && (
              <Typography variant="caption" color="text.secondary">
                {includedCount} tables migrated
              </Typography>
            )}
            {(totalRows !== undefined && totalRows !== null) && (
              <Typography variant="caption" color="text.secondary">
                {totalRows.toLocaleString()} rows on the target
              </Typography>
            )}
            {validation && (
              <Typography variant="caption" color="text.secondary">
                Validation {validation.passed ? "passed" : "failed"}
                {validation.checkedAt
                  ? ` · ${new Date(validation.checkedAt).toLocaleString()}`
                  : ""}
              </Typography>
            )}
            {completedTs && (
              <Typography variant="caption" color="text.secondary">
                Completed {new Date(completedTs).toLocaleString()}
              </Typography>
            )}
            {excludedNames.length > 0 && (
              <Typography variant="caption" color="text.secondary">
                Excluded: {excludedNames.join(", ")}
              </Typography>
            )}
            {cutoverEvent && (
              <Typography variant="caption" color="text.secondary">
                {cutoverEvent.msg}
              </Typography>
            )}
          </Stack>
        </Paper>
      ) : !validationDone ? (
        <Typography variant="body2" color="text.secondary">
          Cutover is gated until validation passes — run Validate and resolve any
          mismatches first.
        </Typography>
      ) : (
        <Box>
          <FormControlLabel
            control={
              <Checkbox
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
                disabled={!allTrue || locked}
              />
            }
            label={
              <Typography variant="body2">
                I understand cutover stops replication and completes this migration.
              </Typography>
            }
          />
          <Box sx={{ mt: 1 }}>
            <Button
              variant="contained"
              disabled={executeDisabled}
              onClick={() => onCutover?.()}
              startIcon={isRunningThis ? <CircularProgress size={16} color="inherit" /> : null}
            >
              Execute cutover
            </Button>
          </Box>
        </Box>
      )}

      <StageActivity m={m} stage="cutover" />
    </Box>
  );
}
