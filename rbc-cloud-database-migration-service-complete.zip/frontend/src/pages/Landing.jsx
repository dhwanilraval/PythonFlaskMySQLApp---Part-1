import React from "react";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import StepConnector, { stepConnectorClasses } from "@mui/material/StepConnector";
import { styled } from "@mui/material/styles";

import SwapHorizRoundedIcon from "@mui/icons-material/SwapHorizRounded";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import FiberManualRecordRoundedIcon from "@mui/icons-material/FiberManualRecordRounded";
import RadioButtonUncheckedRoundedIcon from "@mui/icons-material/RadioButtonUncheckedRounded";
import WarningAmberRoundedIcon from "@mui/icons-material/WarningAmberRounded";

// ---------------------------------------------------------------------------
// Path-line steps — same five stages shown everywhere else in the app, but
// here each one is pinned to a fixed demo state (done / active / gate) to
// illustrate the flow on the marketing page. Not driven by real data.
// ---------------------------------------------------------------------------
const PATH_STEPS = [
  { label: "Discover", state: "done" },
  { label: "Schema conversion", state: "default" },
  { label: "Replicate", state: "active" },
  { label: "Validate · gate", state: "gate" },
  { label: "Cutover", state: "default" },
];

const PathConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 14,
  },
  [`& .${stepConnectorClasses.line}`]: {
    borderColor: theme.palette.divider,
    borderTopWidth: 1.5,
  },
}));

function PathStepIcon({ state }) {
  const sx = { fontSize: 28 };
  if (state === "done") return <CheckCircleRoundedIcon sx={{ ...sx, color: "success.main" }} />;
  if (state === "active") return <FiberManualRecordRoundedIcon sx={{ ...sx, color: "primary.main" }} />;
  if (state === "gate") return <WarningAmberRoundedIcon sx={{ ...sx, color: "warning.main" }} />;
  return <RadioButtonUncheckedRoundedIcon sx={{ ...sx, color: "text.disabled" }} />;
}

function PathLabel({ label, state }) {
  const color = state === "gate" ? "warning.main" : state === "active" ? "primary.main" : "text.secondary";
  const weight = state === "default" ? 500 : 700;
  return (
    <Typography variant="body2" sx={{ color, fontWeight: weight, mt: 0.5 }}>
      {label}
    </Typography>
  );
}

function TopBar({ onSignIn, onToggleTheme, mode }) {
  return (
    <Box
      component="header"
      sx={{
        borderBottom: "1px solid",
        borderColor: "divider",
        position: "sticky",
        top: 0,
        bgcolor: "background.default",
        zIndex: 10,
      }}
    >
      <Container maxWidth="lg">
        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ py: 1.75 }}>
          <Stack direction="row" spacing={1.25} alignItems="center">
            <Box
              sx={{
                width: 34,
                height: 34,
                borderRadius: 2,
                bgcolor: "primary.main",
                color: "primary.contrastText",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <SwapHorizRoundedIcon fontSize="small" />
            </Box>
            <Typography variant="h5" sx={{ letterSpacing: "-0.01em" }}>
              Migration Hub
            </Typography>
          </Stack>

          <Stack direction="row" spacing={3} alignItems="center">
            <Stack direction="row" spacing={3} sx={{ display: { xs: "none", md: "flex" } }}>
              <Typography
                component="a"
                href="#how"
                variant="body2"
                sx={{ color: "text.secondary", fontWeight: 600, textDecoration: "none", "&:hover": { color: "text.primary" } }}
              >
                How it works
              </Typography>
              <Typography
                component="a"
                href="#engines"
                variant="body2"
                sx={{ color: "text.secondary", fontWeight: 600, textDecoration: "none", "&:hover": { color: "text.primary" } }}
              >
                Engines
              </Typography>
              <Typography
                component="a"
                href="#faq"
                variant="body2"
                sx={{ color: "text.secondary", fontWeight: 600, textDecoration: "none", "&:hover": { color: "text.primary" } }}
              >
                FAQ
              </Typography>
            </Stack>
            <Button
              size="small"
              color="inherit"
              onClick={onToggleTheme}
              startIcon={mode === "light" ? <Brightness4Icon fontSize="small" /> : <Brightness7Icon fontSize="small" />}
              sx={{ color: "text.secondary", fontWeight: 600 }}
            >
              Theme
            </Button>
            <Button variant="contained" onClick={onSignIn}>
              Sign in
            </Button>
          </Stack>
        </Stack>
      </Container>
    </Box>
  );
}

export default function Landing({ onSignIn, onToggleTheme, mode }) {
  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "background.default" }}>
      <TopBar onSignIn={onSignIn} onToggleTheme={onToggleTheme} mode={mode} />

      {/* ---------------- hero ---------------- */}
      <Container maxWidth="lg">
        <Box sx={{ pt: { xs: 8, md: 12 }, pb: { xs: 6, md: 8 }, textAlign: "center" }}>
          <Typography
            variant="h1"
            sx={{
              fontSize: { xs: "2.25rem", md: "3.25rem" },
              fontWeight: 700,
              letterSpacing: "-0.02em",
              lineHeight: 1.15,
              mb: 3,
            }}
          >
            Move databases with
            <br />
            near-zero downtime.
          </Typography>
          <Typography
            variant="body1"
            sx={{ color: "text.secondary", maxWidth: 640, mx: "auto", fontSize: "1.0625rem", mb: 4 }}
          >
            Discover, convert, replicate, validate, cut over — continuous replication powered by
            Debezium CDC keeps your target in sync until the moment you switch.
          </Typography>
          <Button variant="contained" size="large" onClick={onSignIn} sx={{ px: 4, py: 1.25, fontSize: "1rem" }}>
            Start a migration
          </Button>

          <Box id="how" sx={{ mt: 8, maxWidth: 760, mx: "auto" }}>
            <Stepper alternativeLabel connector={<PathConnector />}>
              {PATH_STEPS.map((step) => (
                <Step key={step.label}>
                  <StepLabel
                    StepIconComponent={() => <PathStepIcon state={step.state} />}
                  >
                    <PathLabel label={step.label} state={step.state} />
                  </StepLabel>
                </Step>
              ))}
            </Stepper>
            <Typography variant="caption" sx={{ color: "text.secondary", display: "block", mt: 3 }}>
              Convert is skipped automatically for same-engine moves. Validation is a hard gate —
              cutover never opens on unverified data.
            </Typography>
          </Box>
        </Box>
      </Container>

      {/* ---------------- engines band ---------------- */}
      <Box id="engines" sx={{ borderTop: "1px solid", borderColor: "divider", py: { xs: 6, md: 7 } }}>
        <Container maxWidth="lg">
          <Typography variant="h4" sx={{ mb: 3 }}>
            Engines in this build
          </Typography>
          <Stack divider={<Divider />}>
            {[
              { name: "PostgreSQL", desc: "source · target — logical replication (pgoutput)" },
              { name: "MariaDB", desc: "source · target — binlog CDC" },
              { name: "MySQL", desc: "source · target — binlog CDC" },
            ].map((row) => (
              <Stack
                key={row.name}
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                sx={{ py: 2 }}
              >
                <Typography variant="subtitle1">{row.name}</Typography>
                <Typography variant="body2" sx={{ color: "text.secondary" }}>
                  {row.desc}
                </Typography>
              </Stack>
            ))}
          </Stack>
        </Container>
      </Box>

      {/* ---------------- faq band ---------------- */}
      <Box id="faq" sx={{ borderTop: "1px solid", borderColor: "divider", py: { xs: 6, md: 7 } }}>
        <Container maxWidth="lg">
          <Typography variant="h4" sx={{ mb: 3 }}>
            Questions
          </Typography>
          <Stack divider={<Divider />} spacing={0}>
            {[
              {
                q: "What is an endpoint?",
                a: "A saved connection: host, port, database, a vault credential reference (never a raw password), SSL mode, and its last connection-test result. Endpoints are created and tested in the wizard, then reused.",
              },
              {
                q: "How does CDC work?",
                a: "Debezium reads the source's transaction log (Postgres logical decoding / MariaDB binlog). The initial snapshot and every later change stream through Kafka to the target, so cutover takes seconds, not a maintenance window.",
              },
              {
                q: "What about my application code?",
                a: "For cross-engine moves, an optional code track prepares refactoring pull requests for your review. Nothing is ever auto-applied to your codebase.",
              },
            ].map((row) => (
              <Box key={row.q} sx={{ py: 2.5 }}>
                <Typography variant="subtitle1" sx={{ mb: 0.75 }}>
                  {row.q}
                </Typography>
                <Typography variant="body2" sx={{ color: "text.secondary", maxWidth: 720 }}>
                  {row.a}
                </Typography>
              </Box>
            ))}
          </Stack>
        </Container>
      </Box>

      <Box sx={{ borderTop: "1px solid", borderColor: "divider", py: 4 }}>
        <Container maxWidth="lg">
          <Typography variant="caption" sx={{ color: "text.disabled" }}>
            Migration Hub — internal demo build.
          </Typography>
        </Container>
      </Box>
    </Box>
  );
}
