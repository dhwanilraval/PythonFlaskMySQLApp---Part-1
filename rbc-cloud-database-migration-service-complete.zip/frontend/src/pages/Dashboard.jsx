import { useState, useMemo, useEffect } from "react";
import {
  Box,
  Stack,
  Typography,
  Button,
  Chip,
  Divider,
  LinearProgress,
} from "@mui/material";
import FiberManualRecordIcon from "@mui/icons-material/FiberManualRecord";

// ---- status → chip presentation (mirrors current app.js status pill map) ----
function statusMeta(status) {
  switch (status) {
    case "completed":
      return { label: "Completed", color: "success", variant: "filled" };
    case "replicating":
      return { label: "Running", color: "primary", variant: "filled" };
    case "ready":
      return { label: "Ready", color: "success", variant: "outlined" };
    case "failed":
      return { label: "Failed", color: "error", variant: "filled" };
    case "attention":
      return { label: "Failed", color: "error", variant: "outlined" };
    case "discovered":
      return { label: "Running", color: "primary", variant: "outlined" };
    case "draft":
      return { label: "Draft", color: "default", variant: "outlined" };
    default:
      return { label: status, color: "default", variant: "outlined" };
  }
}

function StatusChip({ status }) {
  const { label, color, variant } = statusMeta(status);
  const dotColor = color === "default" ? "text.disabled" : `${color}.main`;
  return (
    <Chip
      size="small"
      variant={variant}
      color={color === "default" ? undefined : color}
      icon={
        <FiberManualRecordIcon
          sx={{ fontSize: "10px !important", color: `${dotColor} !important` }}
        />
      }
      label={label}
      sx={{ fontWeight: 600 }}
    />
  );
}

// Percent of events applied vs total source rows of included tables — mirrors current migPct().
function migPct(m) {
  const total = m.tables
    .filter((t) => t.include)
    .reduce((a, t) => a + (t.sourceRows || 0), 0);
  if (!total) return 0;
  return Math.min(100, Math.round((100 * (m.progress?.eventsApplied || 0)) / total));
}

const STAGE_LABELS = {
  discover: "Discover",
  convert: "Schema conversion",
  replicate: "Replicate",
  validate: "Validate",
  cutover: "Cutover",
  code: "Code refactoring",
};

// Relative time formatter — mirrors panels' relTime().
function relTime(ts) {
  if (!ts) return "—";
  const diffMs = Date.now() - new Date(ts).getTime();
  const sec = Math.max(0, Math.floor(diffMs / 1000));
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  return `${day}d ago`;
}

function findFailedStage(m) {
  const entries = Object.entries(m.stages || {});
  const hit = entries.find(([, v]) => v === "failed");
  return hit ? hit[0] : null;
}

function hasRunningStage(m) {
  return Object.values(m.stages || {}).some((v) => v === "running");
}

// Per-row status line, computed from status + stages.
function rowLine(m) {
  const failedStage = findFailedStage(m);
  if (failedStage) {
    const label = STAGE_LABELS[failedStage] || failedStage;
    return { text: `${label} failed`, color: "error.main" };
  }
  switch (m.status) {
    case "replicating":
      return {
        text: `Replicating · ${(m.progress?.eventsApplied || 0).toLocaleString()} events · updated ${relTime(
          m.progress?.lastEventAt
        )}`,
        color: "text.secondary",
      };
    case "ready":
      return { text: "Validation passed · ready for cutover", color: "text.secondary" };
    case "completed": {
      const ts = m.completedAt || m.cutoverAt;
      const text = ts ? `Completed ${new Date(ts).toLocaleDateString()}` : "Completed";
      return { text, color: "text.secondary" };
    }
    case "discovered":
      return { text: `Discovered · ${(m.tables || []).length} tables`, color: "text.secondary" };
    case "draft":
      return { text: "Draft — not started", color: "text.secondary" };
    default:
      return null;
  }
}

function isAttentionGroup(m) {
  return m.status === "failed" || m.status === "attention" || !!findFailedStage(m);
}

function isActiveGroup(m) {
  return m.status === "replicating" || m.status === "discovered" || hasRunningStage(m);
}

function rankOf(m) {
  if (isAttentionGroup(m)) return 0;
  if (isActiveGroup(m)) return 1;
  if (m.status === "ready") return 2;
  if (m.status === "draft") return 3;
  if (m.status === "completed") return 4;
  return 1.5;
}

const FILTERS = [
  { key: "all", label: "All" },
  { key: "running", label: "Running" },
  { key: "ready", label: "Ready" },
  { key: "attention", label: "Needs attention" },
  { key: "completed", label: "Completed" },
];

// Same filter semantics as current app.js renderDashboard().
function matchesFilter(m, filter) {
  if (filter === "all") return true;
  if (filter === "running") return m.status === "replicating";
  if (filter === "ready") return m.status === "ready";
  if (filter === "attention") return m.status === "attention" || m.status === "failed";
  if (filter === "completed") return m.status === "completed";
  return true;
}

export default function Dashboard({
  migrations,
  endpoints, // eslint-disable-line no-unused-vars -- reserved for parity with brief signature
  onOpen,
  onNewMigration,
  onManageEndpoints,
  refresh, // eslint-disable-line no-unused-vars -- data is owned by App; kept for signature parity
}) {
  const [filter, setFilter] = useState("all");

  // Ticker to keep relative "updated Xs ago" text fresh.
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, []);

  // --- KPI math, mirrors current renderDashboard() exactly ---
  const kpis = useMemo(() => {
    const active = migrations.filter((m) => m.status === "replicating").length;
    const tables = migrations.reduce(
      (a, m) =>
        a + m.tables.filter((t) => t.include).reduce((x, t) => x + (t.targetRows || 0), 0),
      0
    );
    const ready = migrations.filter((m) => m.status === "ready").length;
    const validated = migrations.filter((m) => m.validation);
    const pass = validated.length
      ? Math.round((100 * validated.filter((m) => m.validation.passed).length) / validated.length)
      : 100;
    return [
      { label: "Active migrations", value: active },
      { label: "Tables replicated", value: tables.toLocaleString() },
      { label: "Ready to cut over", value: ready },
      { label: "Validation pass rate", value: `${pass}%` },
    ];
  }, [migrations]);

  const list = useMemo(() => {
    const filtered = migrations
      .map((m, idx) => ({ m, idx }))
      .filter(({ m }) => matchesFilter(m, filter));
    filtered.sort((a, b) => {
      const ra = rankOf(a.m);
      const rb = rankOf(b.m);
      if (ra !== rb) return ra - rb;
      return a.idx - b.idx;
    });
    return filtered.map(({ m }) => m);
  }, [migrations, filter]);

  return (
    <Box sx={{ maxWidth: 1150, mx: "auto" }}>
      {/* Page head */}
      <Stack
        direction={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ xs: "flex-start", sm: "center" }}
        spacing={2}
        sx={{ mb: 3 }}
      >
        <Box>
          <Typography variant="h4" component="h1" fontWeight={650}>
            Dashboard
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            Track replication, validation gates, and cutover readiness.
          </Typography>
        </Box>
        <Stack direction="row" spacing={1.5}>
          <Button variant="outlined" onClick={onManageEndpoints}>
            Manage endpoints
          </Button>
          <Button variant="contained" onClick={onNewMigration}>
            + New migration
          </Button>
        </Stack>
      </Stack>

      {/* KPI row */}
      <Stack
        direction="row"
        divider={<Divider orientation="vertical" flexItem />}
        sx={{
          border: "1px solid",
          borderColor: "divider",
          borderRadius: 2,
          px: 3,
          py: 2.5,
          mb: 3,
          bgcolor: "background.paper",
        }}
      >
        {kpis.map((k) => (
          <Box key={k.label} sx={{ flex: 1, px: { xs: 1, sm: 2 } }}>
            <Typography
              variant="overline"
              color="text.secondary"
              sx={{ letterSpacing: "0.08em", fontWeight: 600 }}
            >
              {k.label}
            </Typography>
            <Typography variant="h4" fontWeight={650} sx={{ mt: 0.5 }}>
              {k.value}
            </Typography>
          </Box>
        ))}
      </Stack>

      {/* Filter chips */}
      <Stack direction="row" spacing={1} sx={{ mb: 2, flexWrap: "wrap", rowGap: 1 }}>
        {FILTERS.map((f) => (
          <Chip
            key={f.key}
            label={f.label}
            clickable
            onClick={() => setFilter(f.key)}
            color={filter === f.key ? "primary" : "default"}
            variant={filter === f.key ? "filled" : "outlined"}
            sx={{ fontWeight: 550 }}
          />
        ))}
      </Stack>

      {/* Migration list */}
      <Box
        sx={{
          border: "1px solid",
          borderColor: "divider",
          borderRadius: 2,
          bgcolor: "background.paper",
          overflow: "hidden",
        }}
      >
        {list.length === 0 ? (
          <Box sx={{ px: 3, py: 5, textAlign: "center" }}>
            <Typography color="text.secondary">
              No migrations yet. Start one — the wizard takes a couple of minutes.
            </Typography>
          </Box>
        ) : (
          list.map((m, idx) => {
            const inc = m.tables.filter((t) => t.include);
            const replicating = m.status === "replicating";
            const failedRow = isAttentionGroup(m);
            const line = rowLine(m);
            return (
              <Box
                key={m.id}
                onClick={() => onOpen(m)}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 2,
                  px: 3,
                  py: 2,
                  cursor: "pointer",
                  borderBottom: idx === list.length - 1 ? "none" : "1px solid",
                  borderColor: "divider",
                  transition: "background-color 120ms ease",
                  "&:hover": { bgcolor: "action.hover" },
                  ...(failedRow && {
                    borderLeft: "3px solid",
                    borderLeftColor: "error.main",
                  }),
                }}
              >
                <Box sx={{ minWidth: 0 }}>
                  <Typography fontWeight={600} noWrap>
                    {m.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" noWrap>
                    {m.sourceEngine} → {m.targetEngine} · {inc.length} tables · created{" "}
                    {m.createdAt ? new Date(m.createdAt).toLocaleDateString() : "—"}
                  </Typography>
                  {line && (
                    <Typography variant="body2" color={line.color} noWrap>
                      {line.text}
                    </Typography>
                  )}
                </Box>
                <Stack alignItems="flex-end" spacing={0.75} sx={{ minWidth: 190 }}>
                  <StatusChip status={m.status} />
                  {replicating && (
                    <Box sx={{ width: "100%" }}>
                      <LinearProgress
                        variant="determinate"
                        value={migPct(m)}
                        sx={{ height: 5, borderRadius: 3 }}
                      />
                      <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{ display: "block", textAlign: "right", mt: 0.3 }}
                      >
                        {m.progress?.eventsApplied || 0} events applied
                      </Typography>
                    </Box>
                  )}
                </Stack>
              </Box>
            );
          })
        )}
      </Box>
    </Box>
  );
}
