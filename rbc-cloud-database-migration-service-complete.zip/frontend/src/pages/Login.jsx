import React, { useState } from "react";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Paper from "@mui/material/Paper";
import CircularProgress from "@mui/material/CircularProgress";

import SwapHorizRoundedIcon from "@mui/icons-material/SwapHorizRounded";
import BusinessRoundedIcon from "@mui/icons-material/BusinessRounded";
import WindowRoundedIcon from "@mui/icons-material/WindowRounded";
import GoogleIcon from "@mui/icons-material/Google";
import ShieldRoundedIcon from "@mui/icons-material/ShieldRounded";

const PROVIDERS = [
  { name: "Company SSO", icon: BusinessRoundedIcon },
  { name: "Microsoft Entra", icon: WindowRoundedIcon },
  { name: "Google Workspace", icon: GoogleIcon },
  { name: "Okta", icon: ShieldRoundedIcon },
];

export default function Login({ onLogin, onBack }) {
  const [pending, setPending] = useState(null); // provider name currently "redirecting"

  const handleClick = (provider) => {
    if (pending) return;
    setPending(provider);
    // Mocked SSO — any provider "succeeds" after a short, visible delay.
    setTimeout(() => {
      onLogin(provider);
    }, 600);
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        bgcolor: "background.default",
        px: 2,
      }}
    >
      <Paper
        variant="outlined"
        sx={{ width: "100%", maxWidth: 400, p: 4.5, display: "flex", flexDirection: "column", alignItems: "center" }}
      >
        <Stack direction="row" spacing={1.25} alignItems="center" sx={{ mb: 3 }}>
          <Box
            sx={{
              width: 34,
              height: 34,
              borderRadius: 2,
              bgcolor: "primary.main",
              color: "primary.contrastText",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <SwapHorizRoundedIcon fontSize="small" />
          </Box>
          <Typography variant="h5" sx={{ letterSpacing: "-0.01em" }}>
            Migration Hub
          </Typography>
        </Stack>

        <Typography variant="h4" sx={{ textAlign: "center", mb: 1 }}>
          Sign in with your organization
        </Typography>
        <Typography variant="body2" sx={{ color: "text.secondary", textAlign: "center", mb: 3.5 }}>
          Single sign-on only. This build mocks the identity provider — pick one to continue.
        </Typography>

        <Stack spacing={1.5} sx={{ width: "100%" }}>
          {PROVIDERS.map(({ name, icon: Icon }) => {
            const isPending = pending === name;
            return (
              <Button
                key={name}
                variant="outlined"
                color="inherit"
                onClick={() => handleClick(name)}
                disabled={!!pending}
                startIcon={isPending ? undefined : <Icon fontSize="small" />}
                sx={{
                  height: 44,
                  justifyContent: "flex-start",
                  px: 2,
                  fontWeight: 600,
                  borderColor: "divider",
                  color: "text.primary",
                }}
              >
                {isPending ? (
                  <Stack direction="row" spacing={1.25} alignItems="center">
                    <CircularProgress size={16} thickness={5} />
                    <span>Redirecting to {name}…</span>
                  </Stack>
                ) : (
                  name
                )}
              </Button>
            );
          })}
        </Stack>

        <Button
          color="inherit"
          onClick={onBack}
          sx={{ mt: 3.5, color: "text.secondary", fontWeight: 600 }}
        >
          ← Back
        </Button>
      </Paper>
    </Box>
  );
}
