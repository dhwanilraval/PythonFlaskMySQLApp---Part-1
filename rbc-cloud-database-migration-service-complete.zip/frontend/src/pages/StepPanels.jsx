import React from "react";
import {
  Box,
  Typography,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Chip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Paper,
  IconButton,
  Stack,
  Divider,
  Button,
  CircularProgress,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import FiberManualRecordIcon from "@mui/icons-material/FiberManualRecord";
import { friendlyError } from "../errorText";

// --------------------------------------------------------------------------
// shared helpers
// --------------------------------------------------------------------------

function relTime(ts) {
  if (!ts) return "—";
  const diff = Date.now() - new Date(ts).getTime();
  if (Number.isNaN(diff)) return "—";
  if (diff < 0) return "just now";
  const s = Math.floor(diff / 1000);
  if (s < 5) return "just now";
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

const STAGE_PREFIX = {
  discover: "Discover",
  convert: "Convert",
  replicate: "Replicate",
  validate: "Validate",
  cutover: "Cutover",
  code: "Devin",
};

const PREV_STAGE = {
  discover: null,
  convert: "Discover",
  replicate: "Schema conversion",
  validate: "Replicate",
  cutover: "Validate",
  code: "Schema conversion",
};

const STATE_CHIP = {
  pending: { label: "Pending", color: "default", variant: "outlined" },
  running: { label: "Running", color: "info", variant: "filled" },
  completed: { label: "Completed", color: "success", variant: "filled" },
  failed: { label: "Failed", color: "error", variant: "filled" },
  skipped: { label: "Skipped", color: "default", variant: "outlined" },
};

// Unified event matcher: accepts an event for `stage` when e.stage === stage
// OR the (legacy, unprefixed-stage) message starts with the stage's prefix.
export function stageEvents(m, stage) {
  const prefix = STAGE_PREFIX[stage];
  return (m?.events || []).filter(
    (e) => e.stage === stage || (!!prefix && (e.msg || "").startsWith(prefix))
  );
}

export function stageStatus(m, stage) {
  if (stage === "code") {
    const ct = m?.codeTrack;
    if (!ct) return "pending";
    const devin = ct.devin;
    if (devin?.status === "error") return "failed";
    if (devin?.status === "working") return "running";
    const steps = ct.steps || [];
    const verifyDone = steps.some(
      (s) => s.name === "Verify" && s.status === "done"
    );
    if (verifyDone) return "completed";
    if (devin || (ct.items && ct.items.length)) return "completed";
    return "pending";
  }
  if (
    stage === "replicate" &&
    m?.stages?.[stage] === "running" &&
    (m?.status === "completed" || m?.stages?.cutover === "done")
  ) {
    return "completed";
  }

  const raw = m?.stages?.[stage] || "pending";
  return raw === "done" ? "completed" : raw;
}

function StateChip({ status }) {
  const cfg = STATE_CHIP[status] || STATE_CHIP.pending;
  return (
    <Chip
      size="small"
      label={cfg.label}
      color={cfg.color}
      variant={cfg.variant}
    />
  );
}

function nowLine(m, stage) {
  const status = stageStatus(m, stage);
  const prev = PREV_STAGE[stage];

  if (status === "pending") {
    return prev ? `Waiting for ${prev}` : "Not started";
  }

  if (stage === "discover") {
    if (status === "running") return "Scanning source schema…";
    if (status === "failed") return "Discovery failed";
    if (status === "completed") {
      const n = (m?.tables || []).length;
      return `Discovered ${n} table${n === 1 ? "" : "s"}`;
    }
  }

  if (stage === "convert") {
    if (status === "skipped")
      return "Homogeneous migration — no translation needed";
    if (status === "running") return "Generating schema conversion…";
    if (status === "failed") return "Conversion failed";
    if (status === "completed") {
      const n = (m?.conversion?.tables || []).length;
      return `${n} table${n === 1 ? "" : "s"} converted`;
    }
  }

  if (stage === "replicate") {
    const progress = m?.progress;
    const applied = progress?.eventsApplied ?? 0;
    if (status === "running") {
      return `Streaming — ${applied.toLocaleString()} events applied · last event ${relTime(
        progress?.lastEventAt
      )}`;
    }
    if (status === "failed") {
      return progress?.error
        ? `Replication failed — ${progress.error}`
        : "Replication failed";
    }
    if (status === "completed") {
      return `Completed — ${applied.toLocaleString()} events applied`;
    }
  }

  if (stage === "validate") {
    const v = m?.validation;
    if (status === "running") return "Validating…";
    if (status === "failed") return "Validation failed";
    if (status === "completed" && v) {
      const tables = Array.isArray(v.tables) ? v.tables : Object.values(v.tables || {});
      const matched = tables.filter((t) => t.match).length;
      const at = v.completedAt || v.ranAt;
      const timeStr = at ? new Date(at).toLocaleTimeString() : "";
      return `${v.passed ? "Passed" : "Failed"}${
        timeStr ? ` at ${timeStr}` : ""
      } · ${matched} of ${tables.length} tables match`;
    }
  }

  if (stage === "cutover") {
    if (status === "running") return "Executing cutover…";
    if (status === "completed") {
      const at = m?.cutoverAt || m?.completedAt;
      return `Completed${at ? ` at ${new Date(at).toLocaleTimeString()}` : ""}`;
    }
    if (status === "failed") return "Cutover failed";
  }

  if (stage === "code") {
    if (status === "running") return "Devin is working on the refactor…";
    if (status === "failed") return "Devin session error";
    if (status === "completed") {
      const events = stageEvents(m, "code");
      const latest = events[0];
      return latest?.msg || `Devin session ${m?.codeTrack?.devin?.status}`;
    }
  }

  return "—";
}

export function StageActivity({ m, stage }) {
  const [expanded, setExpanded] = React.useState(false);
  const [showRaw, setShowRaw] = React.useState(false);
  const events = stageEvents(m, stage);
  const status = stageStatus(m, stage);
  const hasMore = events.length > 4;
  const shown = expanded ? events : events.slice(0, 4);

  return (
    <Box sx={{ mt: 2 }}>
      <Divider sx={{ mb: 1.5 }} />
      <Typography variant="body2" sx={{ fontWeight: 600, mb: 1 }}>
        {nowLine(m, stage)}
      </Typography>
      {events.length ? (
        <>
          <Stack spacing={0.5}>
            {shown.map((e, i) => {
              const isNewest = i === 0;
              let icon;
              if (status === "running" && isNewest) {
                icon = <CircularProgress size={14} />;
              } else if (status === "failed" && isNewest) {
                icon = <ErrorOutlineIcon color="error" fontSize="small" />;
              } else if (status === "completed" || status === "skipped") {
                icon = <CheckCircleIcon color="success" fontSize="small" />;
              } else {
                icon = (
                  <FiberManualRecordIcon
                    color="disabled"
                    sx={{ fontSize: 8 }}
                  />
                );
              }
              return (
                <Stack
                  key={e.ts + i}
                  direction="row"
                  spacing={1}
                  alignItems="center"
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      width: 16,
                      flexShrink: 0,
                    }}
                  >
                    {icon}
                  </Box>
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ flexGrow: 1 }}
                  >
                    {status === "failed" && isNewest
                      ? friendlyError(e.msg)
                      : e.msg}
                  </Typography>
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ flexShrink: 0 }}
                  >
                    {relTime(e.ts)}
                  </Typography>
                </Stack>
              );
            })}
          </Stack>
          {hasMore && (
            <Button
              size="small"
              onClick={() => setExpanded((x) => !x)}
              sx={{ mt: 0.5 }}
            >
              {expanded ? "Show less" : `Show all ${events.length} activities`}
            </Button>
          )}
          {status === "failed" && events.length > 0 && (
            <>
              <Button
                size="small"
                onClick={() => setShowRaw((x) => !x)}
                sx={{ textTransform: "none", px: 0 }}
              >
                Technical details
              </Button>
              {showRaw && (
                <Typography
                  variant="caption"
                  display="block"
                  sx={{ fontFamily: "monospace", wordBreak: "break-word" }}
                >
                  {events[0].msg}
                </Typography>
              )}
            </>
          )}
        </>
      ) : (
        <Typography variant="caption" color="text.secondary">
          No activity yet.
        </Typography>
      )}
    </Box>
  );
}

const STAGE_LABEL = {
  discover: "Discover",
  convert: "Schema conversion",
  replicate: "Replicate",
  validate: "Validate",
  cutover: "Cutover",
  code: "Code refactoring",
};

function StageAction({ stage, label, m, onRunStage, runningStage, locked }) {
  const status = stageStatus(m, stage);
  const isRunningThis = runningStage === stage;
  const disabled = locked || isRunningThis || runningStage !== null;
  const text = label || (status === "completed" || status === "failed"
    ? `Re-run ${STAGE_LABEL[stage]}`
    : `Run ${STAGE_LABEL[stage]}`);

  return (
    <Button
      size="small"
      variant="outlined"
      disabled={disabled}
      onClick={() => onRunStage?.(stage)}
      startIcon={isRunningThis ? <CircularProgress size={16} /> : null}
    >
      {text}
    </Button>
  );
}

function PanelHeader({ title, status, children }) {
  return (
    <Stack
      direction="row"
      alignItems="center"
      justifyContent="space-between"
      sx={{ mb: 2 }}
    >
      <Stack direction="row" spacing={1.5} alignItems="center">
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          {title}
        </Typography>
        <StateChip status={status} />
      </Stack>
      <Box>{children}</Box>
    </Stack>
  );
}

function EmptyState({ text }) {
  return (
    <Box sx={{ py: 3, px: 1 }}>
      <Typography variant="body2" color="text.secondary">
        {text}
      </Typography>
    </Box>
  );
}

// --------------------------------------------------------------------------
// Discover
// --------------------------------------------------------------------------
export function DiscoverPanel({ m, notify, onRunStage, runningStage, locked }) {
  const status = stageStatus(m, "discover");
  const tables = m?.tables || [];

  return (
    <Box>
      <PanelHeader title="Discover" status={status}>
        <StageAction
          stage="discover"
          m={m}
          onRunStage={onRunStage}
          runningStage={runningStage}
          locked={locked}
        />
      </PanelHeader>

      {tables.length ? (
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Table</TableCell>
              <TableCell align="right">Source rows</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {tables.map((t) => {
              const included = t.included !== false;
              const rows = t.sourceRows ?? t.rows ?? t.rowCount ?? "—";
              return (
                <TableRow key={t.name}>
                  <TableCell sx={{ fontFamily: "monospace" }}>
                    {t.name}
                  </TableCell>
                  <TableCell align="right">{rows}</TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={included ? "Included" : "Excluded"}
                      color={included ? "success" : "default"}
                      variant={included ? "filled" : "outlined"}
                    />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      ) : (
        <EmptyState text="No tables discovered yet." />
      )}

      <StageActivity m={m} stage="discover" />
    </Box>
  );
}

// --------------------------------------------------------------------------
// Convert
// --------------------------------------------------------------------------
function ConversionTable({ table, notify }) {
  const { table: name, sourceColumns = [], targetColumns = [], ddl } = table;
  const changedCount = sourceColumns.filter(
    (c, i) => targetColumns[i] && targetColumns[i].type !== c.type
  ).length;

  const copyDdl = async () => {
    try {
      await navigator.clipboard.writeText(ddl || "");
      notify?.("DDL copied", name);
    } catch {
      notify?.("Copy failed", name, "error");
    }
  };

  return (
    <Accordion disableGutters>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Typography sx={{ fontFamily: "monospace", mr: 1 }}>{name}</Typography>
        <Typography variant="body2" color="text.secondary">
          {sourceColumns.length} columns · {changedCount} changed
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Table size="small" sx={{ mb: 2 }}>
          <TableHead>
            <TableRow>
              <TableCell>Source column</TableCell>
              <TableCell>Source type</TableCell>
              <TableCell align="center">→</TableCell>
              <TableCell>Target column</TableCell>
              <TableCell>Target type</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sourceColumns.map((sc, i) => {
              const tc = targetColumns[i] || {};
              const changed = tc.type !== undefined && tc.type !== sc.type;
              return (
                <TableRow key={sc.name + i}>
                  <TableCell sx={{ fontFamily: "monospace" }}>
                    {sc.name}
                  </TableCell>
                  <TableCell sx={{ fontFamily: "monospace" }}>
                    {sc.type}
                  </TableCell>
                  <TableCell align="center">→</TableCell>
                  <TableCell sx={{ fontFamily: "monospace" }}>
                    {tc.name}
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography
                        component="span"
                        sx={{
                          fontFamily: "monospace",
                          fontWeight: changed ? 700 : 400,
                        }}
                      >
                        {tc.type}
                      </Typography>
                      {changed && (
                        <Chip size="small" color="warning" label="changed" />
                      )}
                    </Stack>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        <Paper
          variant="outlined"
          sx={{
            position: "relative",
            bgcolor: "action.hover",
            p: 1.5,
            overflowX: "auto",
          }}
        >
          <IconButton
            size="small"
            onClick={copyDdl}
            sx={{ position: "absolute", top: 4, right: 4 }}
            aria-label="Copy DDL"
          >
            <ContentCopyIcon fontSize="small" />
          </IconButton>
          <Box
            component="pre"
            sx={{
              m: 0,
              fontFamily: "monospace",
              fontSize: 12,
              whiteSpace: "pre",
            }}
          >
            {ddl}
          </Box>
        </Paper>
      </AccordionDetails>
    </Accordion>
  );
}

export function ConvertPanel({ m, notify, onRunStage, runningStage, locked }) {
  const status = stageStatus(m, "convert");
  const tables = m?.conversion?.tables || [];
  const skipped = status === "skipped";

  return (
    <Box>
      <PanelHeader title="Schema conversion" status={status}>
        {!skipped && (
          <StageAction
            stage="convert"
            m={m}
            onRunStage={onRunStage}
            runningStage={runningStage}
            locked={locked}
          />
        )}
      </PanelHeader>

      {skipped ? (
        <EmptyState text="Homogeneous migration — no translation needed." />
      ) : !m?.conversion ? (
        <EmptyState text="Run Schema conversion to generate the schema conversion report." />
      ) : !tables.length ? (
        <EmptyState text="Conversion ran but produced no table reports." />
      ) : (
        <Box>
          {tables.map((t) => (
            <ConversionTable key={t.table} table={t} notify={notify} />
          ))}
        </Box>
      )}

      <StageActivity m={m} stage="convert" />
    </Box>
  );
}

// --------------------------------------------------------------------------
// Validate
// --------------------------------------------------------------------------
export function ValidatePanel({ m, notify, onRunStage, runningStage, locked }) {
  const status = stageStatus(m, "validate");
  const v = m?.validation;
  const vtables = Array.isArray(v?.tables)
    ? v.tables
    : Object.entries(v?.tables || {}).map(([table, t]) => ({ table, ...t }));
  const matched = vtables.filter((t) => t.match).length;

  const sourceTables = m?.tables || [];
  const includedTables = sourceTables.filter((t) => t.include !== false);
  const includedNames = includedTables.map((t) => t.name).join(", ");

  return (
    <Box>
      <PanelHeader title="Validate" status={status}>
        <StageAction
          stage="validate"
          label={v ? "Re-check validation" : "Run validation"}
          m={m}
          onRunStage={onRunStage}
          runningStage={runningStage}
          locked={locked}
        />
      </PanelHeader>

      {!v ? (
        <Box>
          <Typography variant="body2" color="text.secondary">
            {`Compares row counts for ${includedTables.length} tables, source vs target.`}
          </Typography>
          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ fontFamily: "monospace", display: "block" }}
          >
            {includedNames}
          </Typography>
        </Box>
      ) : (
        <Box>
          <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 2 }}>
            <Chip
              size="small"
              label={v.passed ? "Passed" : "Failed"}
              color={v.passed ? "success" : "error"}
            />
            <Typography variant="body2" color="text.secondary">
              {matched} of {vtables.length} tables match
            </Typography>
          </Stack>

          {vtables.length ? (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Table</TableCell>
                  <TableCell align="right">Source rows</TableCell>
                  <TableCell align="right">Target rows</TableCell>
                  <TableCell>Match</TableCell>
                  <TableCell>Sample</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {vtables.map((t) => (
                  <TableRow key={t.table}>
                    <TableCell sx={{ fontFamily: "monospace" }}>
                      {t.table}
                    </TableCell>
                    <TableCell align="right">{t.sourceRows}</TableCell>
                    <TableCell align="right">{t.targetRows}</TableCell>
                    <TableCell>
                      <Chip
                        size="small"
                        label={t.match ? "Match" : "Mismatch"}
                        color={t.match ? "success" : "error"}
                      />
                      {!t.match && (
                        <Typography
                          variant="caption"
                          color="error"
                          display="block"
                        >
                          {`differs by ${Math.abs(t.sourceRows - t.targetRows)}`}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      {t.sample ? (
                        <Chip size="small" variant="outlined" label={t.sample} />
                      ) : (
                        <Typography variant="caption" color="text.secondary">
                          —
                        </Typography>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <Typography variant="body2" color="text.secondary">
              No per-table detail recorded.
            </Typography>
          )}

          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ mt: 1, display: "block" }}
          >
            Re-checking is safe while replication runs — it only reads row counts.
          </Typography>
        </Box>
      )}

      <StageActivity m={m} stage="validate" />
    </Box>
  );
}
