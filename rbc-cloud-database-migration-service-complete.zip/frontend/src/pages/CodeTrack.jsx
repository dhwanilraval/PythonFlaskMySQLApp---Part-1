import React, { useMemo, useState } from "react";
import {
  Box,
  Typography,
  Chip,
  Stack,
  Divider,
  Button,
  Paper,
  Card,
  CardContent,
  Alert,
  Link,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import RadioButtonUncheckedIcon from "@mui/icons-material/RadioButtonUnchecked";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import { api } from "../api";
import { StageActivity } from "./StepPanels";

const STATUS_LABEL = {
  pending: "Pending",
  approved: "Approved",
  "changes-requested": "Changes requested",
};
const STATUS_COLOR = {
  pending: "default",
  approved: "success",
  "changes-requested": "warning",
};

const DEVIN_STATUS_COLOR = {
  working: "info",
  blocked: "warning",
  finished: "success",
  error: "error",
  stub: "default",
};

function stepId(step) {
  if (!step) return undefined;
  return step.id || step.key || step.name;
}

function stepStatusWord(step, id, activeId) {
  const status = step.status;
  if (status === "done" || status === "completed") return "Done";
  if (id === activeId) return "In progress";
  if (status === "waiting") return "In progress";
  if (status === "pending") return "Pending";
  return status;
}

function StepIcon({ step, id, activeId }) {
  const status = step.status;
  if (status === "done" || status === "completed") {
    return <CheckCircleIcon color="success" fontSize="small" />;
  }
  if (id === activeId) {
    return (
      <AutorenewIcon
        color="primary"
        fontSize="small"
        sx={{
          animation: "ct-spin 1.1s linear infinite",
          "@keyframes ct-spin": {
            "0%": { transform: "rotate(0deg)" },
            "100%": { transform: "rotate(360deg)" },
          },
        }}
      />
    );
  }
  return <RadioButtonUncheckedIcon color="disabled" fontSize="small" />;
}

const STEP_DESCRIPTIONS = [
  [/scan/i, "Findings are derived from the schema conversion report for this migration."],
  [/generate|pr/i, "Devin prepares the changes; every item lands in You review & merge for approval."],
  [/verify/i, "Runs after the review completes — the app is re-checked against the converted schema."],
];

function stepDescription(name) {
  const match = STEP_DESCRIPTIONS.find(([re]) => re.test(name || ""));
  return match ? match[1] : "Part of the code-refactoring track for this migration.";
}

function truncateMiddle(str, head = 8, tail = 6) {
  if (!str) return "";
  if (str.length <= head + tail + 3) return str;
  return `${str.slice(0, head)}…${str.slice(-tail)}`;
}

function ReviewItemRow({ item, migId, onRefresh, notify }) {
  const [showDiff, setShowDiff] = useState(false);

  const decide = async (decision) => {
    try {
      await api.reviewCodeItem(migId, item.id, decision);
      onRefresh?.();
      notify?.(
        decision === "approved" ? "Item approved" : "Changes requested",
        item.title
      );
    } catch (e) {
      notify?.("Review failed", e.message, "error");
    }
  };

  const hasDiff = Boolean(item.before || item.after);

  return (
    <Box
      sx={{
        py: 1.25,
        borderBottom: "1px solid",
        borderColor: "divider",
        "&:last-of-type": { borderBottom: "none" },
      }}
    >
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }}>
        <Chip size="small" label={item.kind} />
        <Typography sx={{ fontWeight: 600, flexGrow: 1 }}>
          {item.title}
        </Typography>
        <Chip
          size="small"
          label={STATUS_LABEL[item.status] || item.status}
          color={STATUS_COLOR[item.status] || "default"}
        />
      </Stack>
      <Typography
        variant="caption"
        sx={{ fontFamily: "monospace", color: "text.secondary" }}
      >
        {item.file}
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
        {item.detail}
      </Typography>
      {hasDiff && (
        <Button
          size="small"
          sx={{ textTransform: "none", px: 0.5 }}
          endIcon={showDiff ? <ExpandLessIcon /> : <ExpandMoreIcon />}
          onClick={() => setShowDiff((v) => !v)}
        >
          View change
        </Button>
      )}
      {hasDiff && showDiff && (
        <Stack spacing={1} sx={{ mt: 1 }}>
          {item.before && (
            <Box
              sx={{
                border: 1,
                borderColor: "divider",
                borderRadius: 1,
                p: 1,
                bgcolor: "rgba(211, 47, 47, 0.05)",
              }}
            >
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{ display: "block" }}
              >
                Before
              </Typography>
              <Typography sx={{ fontFamily: "monospace", fontSize: 12 }}>
                {item.before}
              </Typography>
            </Box>
          )}
          {item.after && (
            <Box
              sx={{
                border: 1,
                borderColor: "divider",
                borderRadius: 1,
                p: 1,
                bgcolor: "rgba(46, 125, 50, 0.06)",
              }}
            >
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{ display: "block" }}
              >
                After
              </Typography>
              <Typography sx={{ fontFamily: "monospace", fontSize: 12 }}>
                {item.after}
              </Typography>
            </Box>
          )}
        </Stack>
      )}
      {item.status === "pending" && (
        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
          <Button
            size="small"
            variant="contained"
            onClick={() => decide("approved")}
          >
            Approve
          </Button>
          <Button
            size="small"
            onClick={() => decide("changes-requested")}
          >
            Request changes
          </Button>
        </Stack>
      )}
    </Box>
  );
}

function DevinCard({ devin, onDevinRefresh }) {
  const [refreshing, setRefreshing] = useState(false);

  const handleClick = async () => {
    setRefreshing(true);
    try {
      await onDevinRefresh?.();
    } finally {
      setRefreshing(false);
    }
  };

  const hasSession = devin && devin.sessionId;
  const isStub = devin?.mode === "stub";

  return (
    <Card variant="outlined" sx={{ mb: 2 }}>
      <CardContent>
        <Stack
          direction="row"
          spacing={1}
          alignItems="center"
          sx={{ mb: 1, flexWrap: "wrap" }}
        >
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Devin — code refactoring session
          </Typography>
          {hasSession && (
            <>
              <Chip
                size="small"
                label={devin.mode === "live" ? "Live" : "Stub mode"}
                color={devin.mode === "live" ? "success" : "warning"}
              />
              <Chip
                size="small"
                label={devin.status || "unknown"}
                color={DEVIN_STATUS_COLOR[devin.status] || "default"}
              />
            </>
          )}
        </Stack>

        {!hasSession ? (
          <>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
              No Devin session yet.
            </Typography>
            <Button
              size="small"
              variant="contained"
              onClick={handleClick}
              disabled={refreshing}
            >
              Start Devin session
            </Button>
          </>
        ) : (
          <>
            <Typography
              variant="caption"
              sx={{ fontFamily: "monospace", color: "text.secondary", display: "block" }}
            >
              {truncateMiddle(devin.sessionId)}
            </Typography>
            {devin.detail && (
              <Typography variant="body2" sx={{ mt: 0.5, mb: 1 }}>
                {devin.detail}
              </Typography>
            )}
            <Stack direction="row" spacing={2} sx={{ mb: 1.5, flexWrap: "wrap" }}>
              {devin.url && (
                <Link href={devin.url} target="_blank" rel="noopener">
                  Open session
                </Link>
              )}
              {devin.prUrl && (
                <Link href={devin.prUrl} target="_blank" rel="noopener">
                  View pull request
                </Link>
              )}
            </Stack>
            <Button
              size="small"
              variant="outlined"
              onClick={handleClick}
              disabled={refreshing}
            >
              Refresh status
            </Button>
          </>
        )}

        {isStub && (
          <Alert severity="info" sx={{ mt: 2 }}>
            Devin is running in stub mode — no API key configured. Add
            DEVIN_API_KEY to the backend to run live sessions.
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}

export function CodeTrackPanel({ m, notify, onDevinRefresh }) {
  const codeTrack = m?.codeTrack;
  const steps = codeTrack?.steps || [];
  const items = codeTrack?.items || [];
  const summary = codeTrack?.summary || { total: items.length, approved: 0 };
  const devin = codeTrack?.devin;

  const activeId = useMemo(() => {
    const first = steps.find(
      (s) => !(s.status === "done" || s.status === "completed")
    );
    return first ? stepId(first) : null;
  }, [steps]);

  const [selected, setSelected] = useState(null);

  const defaultId = useMemo(() => {
    const review = steps.find((s) => /review/i.test(s.name || s.label || ""));
    return stepId(
      review || steps.find((s) => stepId(s) === activeId) || steps[0]
    );
  }, [steps, activeId]);

  const selectedId = selected ?? defaultId;

  const selectedStep = useMemo(
    () => steps.find((s) => stepId(s) === selectedId),
    [steps, selectedId]
  );
  const isReviewStep =
    selectedStep &&
    /review/i.test(selectedStep.label || selectedStep.name || "");

  if (!steps.length) {
    return (
      <Box sx={{ mt: 4 }}>
        <Typography variant="h6" sx={{ mb: 1 }}>
          Code track
        </Typography>
        <Typography variant="body2" color="text.secondary">
          No code track for this migration.
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 2 }}>
      <DevinCard devin={devin} onDevinRefresh={onDevinRefresh} />

      <Stack
        direction="row"
        spacing={1}
        alignItems="center"
        sx={{ mb: 1, flexWrap: "wrap" }}
      >
        <Typography variant="h6">Code track</Typography>
        <Chip size="small" label="Cross-engine" variant="outlined" />
        <Typography variant="body2" color="text.secondary">
          {summary.approved} of {summary.total} approved
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
          Simulated — schema-derived review items, not real repo PRs.
        </Typography>
      </Stack>

      <Stack spacing={0.5} sx={{ mb: 2 }}>
        {steps.map((s) => {
          const id = stepId(s);
          const isSelected = id === selectedId;
          const isActive = id === activeId;
          const name = s.label || s.name;
          return (
            <Button
              key={id}
              onClick={() => setSelected(id)}
              sx={{
                justifyContent: "flex-start",
                textTransform: "none",
                color: "inherit",
                borderRadius: 2,
                px: 1.5,
                py: 1,
                bgcolor: isSelected ? "action.selected" : "transparent",
              }}
            >
              <Stack direction="row" spacing={1.5} alignItems="center" sx={{ width: "100%" }}>
                <StepIcon step={s} id={id} activeId={activeId} />
                <Typography
                  sx={{ fontWeight: isSelected || isActive ? 600 : 400 }}
                >
                  {name}
                </Typography>
                <Typography
                  variant="caption"
                  color="text.secondary"
                  sx={{ marginLeft: "auto" }}
                >
                  {stepStatusWord(s, id, activeId)}
                </Typography>
              </Stack>
            </Button>
          );
        })}
      </Stack>

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        {isReviewStep ? (
          items.length ? (
            <Box>
              {items.map((item) => (
                <ReviewItemRow
                  key={item.id}
                  item={item}
                  migId={m.id}
                  onRefresh={onDevinRefresh}
                  notify={notify}
                />
              ))}
            </Box>
          ) : (
            <Typography variant="body2" color="text.secondary">
              No review items generated for this migration.
            </Typography>
          )
        ) : (
          <Box>
            <Typography variant="body2" sx={{ fontWeight: 700, mb: 0.5 }}>
              {(selectedStep?.label || selectedStep?.name || "This step")} —{" "}
              {stepStatusWord(selectedStep || {}, selectedId, activeId)}.
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {stepDescription(selectedStep?.label || selectedStep?.name)}
            </Typography>
          </Box>
        )}
      </Paper>

      <Divider sx={{ mb: 2 }} />

      <StageActivity m={m} stage="code" />
    </Box>
  );
}

export default CodeTrackPanel;
