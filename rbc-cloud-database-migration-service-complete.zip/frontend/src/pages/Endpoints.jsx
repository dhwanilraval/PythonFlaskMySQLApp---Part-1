import { useState } from "react";
import {
  Box,
  Stack,
  Typography,
  Button,
  Chip,
  Grid,
  TextField,
  MenuItem,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  TableContainer,
  IconButton,
  Tooltip,
  Paper,
  CircularProgress,
} from "@mui/material";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import api from "../api";
import { friendlyError } from "../errorText";

const ENGINES = [
  { value: "postgres", label: "PostgreSQL" },
  { value: "mariadb", label: "MariaDB" },
  { value: "mysql", label: "MySQL" },
];

const VAULTS = [
  "vault://orders-ro",
  "vault://shop-ro",
  "vault://analytics-rw",
  "vault://target-rw",
];

const EMPTY_FORM = {
  name: "",
  role: "source",
  engine: "postgres",
  host: "",
  port: "",
  database: "",
  user: "",
  credentialRef: VAULTS[0],
};

export default function Endpoints({ endpoints, refresh, notify }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [testingId, setTestingId] = useState(null);

  const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const body = { ...form, port: Number(form.port) };
      await api.createEndpoint(body);
      notify("Endpoint saved", `${body.name} is ready to use.`);
      setForm(EMPTY_FORM);
      setShowForm(false);
      refresh();
    } catch (err) {
      notify("Could not save endpoint", err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleTest(ep) {
    setTestingId(ep.id);
    try {
      const r = await api.testEndpoint(ep.id);
      notify(
        "Connection test",
        r.ok ? `OK · ${r.latencyMs} ms · ${r.version}` : friendlyError(r.error || "Test failed")
      );
    } catch (err) {
      notify("Test failed", err.message);
    } finally {
      setTestingId(null);
      refresh();
    }
  }

  async function handleDelete(ep) {
    try {
      await api.deleteEndpoint(ep.id);
      refresh();
    } catch (err) {
      notify("Could not delete endpoint", err.message);
    }
  }

  return (
    <Box sx={{ maxWidth: 1150, mx: "auto" }}>
      {/* Page head */}
      <Stack
        direction={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ xs: "flex-start", sm: "center" }}
        spacing={2}
        sx={{ mb: 3 }}
      >
        <Box>
          <Typography variant="h4" component="h1" fontWeight={650}>
            Endpoints
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            Saved source and target connections used across migrations.
          </Typography>
        </Box>
        <Button variant="contained" onClick={() => setShowForm((v) => !v)}>
          {showForm ? "Cancel" : "+ Add endpoint"}
        </Button>
      </Stack>

      {/* Add-endpoint form */}
      {showForm && (
        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={{
            border: "1px solid",
            borderColor: "divider",
            borderRadius: 2,
            p: 3,
            mb: 3,
            bgcolor: "background.paper",
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Name"
                fullWidth
                required
                value={form.name}
                onChange={set("name")}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <TextField select label="Role" fullWidth value={form.role} onChange={set("role")}>
                <MenuItem value="source">Source</MenuItem>
                <MenuItem value="target">Target</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={12} sm={3}>
              <TextField
                select
                label="Engine"
                fullWidth
                value={form.engine}
                onChange={set("engine")}
              >
                {ENGINES.map((e) => (
                  <MenuItem key={e.value} value={e.value}>
                    {e.label}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Host"
                fullWidth
                required
                value={form.host}
                onChange={set("host")}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <TextField
                label="Port"
                type="number"
                fullWidth
                required
                value={form.port}
                onChange={set("port")}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <TextField
                label="Database"
                fullWidth
                required
                value={form.database}
                onChange={set("database")}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="User"
                fullWidth
                required
                value={form.user}
                onChange={set("user")}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                select
                label="Credential reference"
                fullWidth
                value={form.credentialRef}
                onChange={set("credentialRef")}
                helperText="Vault reference — credentials are never stored or shown in plain text."
              >
                {VAULTS.map((v) => (
                  <MenuItem key={v} value={v}>
                    {v}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12}>
              <Stack direction="row" spacing={1.5} justifyContent="flex-end">
                <Button
                  variant="text"
                  onClick={() => {
                    setForm(EMPTY_FORM);
                    setShowForm(false);
                  }}
                  disabled={saving}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="contained" disabled={saving}>
                  {saving ? "Saving…" : "Save endpoint"}
                </Button>
              </Stack>
            </Grid>
          </Grid>
        </Box>
      )}

      {/* Endpoints list */}
      {endpoints.length === 0 ? (
        <Paper
          variant="outlined"
          sx={{ p: 4, textAlign: "center", color: "text.secondary" }}
        >
          <Typography variant="body2">
            No endpoints yet — add one, or create them inside the migration wizard.
          </Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Engine</TableCell>
                <TableCell>Host / Database</TableCell>
                <TableCell>Credential ref</TableCell>
                <TableCell>Last test</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {endpoints.map((ep) => (
                <TableRow key={ep.id} hover>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" fontWeight={600}>
                        {ep.name}
                      </Typography>
                      <Chip
                        label={ep.role}
                        size="small"
                        variant="outlined"
                        sx={{ textTransform: "capitalize" }}
                      />
                    </Stack>
                  </TableCell>
                  <TableCell sx={{ textTransform: "capitalize" }}>{ep.engine}</TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {ep.host}:{ep.port}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {ep.database} · user {ep.user}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ fontFamily: "monospace" }}>
                      {ep.credentialRef}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {ep.lastTest ? (
                      ep.lastTest.ok ? (
                        <Typography variant="body2" color="success.main">
                          ✓ {new Date(ep.lastTest.at).toLocaleTimeString()} ·{" "}
                          {ep.lastTest.latencyMs} ms · {ep.lastTest.version || ""}
                        </Typography>
                      ) : (
                        <Typography variant="body2" color="error.main">
                          ✗ {friendlyError(ep.lastTest.error || "test failed")}
                        </Typography>
                      )
                    ) : (
                      <Typography variant="body2" color="text.secondary">
                        Not tested yet
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell align="right">
                    <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                      <Tooltip title="Test connection">
                        <span>
                          <IconButton
                            size="small"
                            onClick={() => handleTest(ep)}
                            disabled={testingId === ep.id}
                          >
                            {testingId === ep.id ? (
                              <CircularProgress size={16} />
                            ) : (
                              <PlayArrowIcon fontSize="small" />
                            )}
                          </IconButton>
                        </span>
                      </Tooltip>
                      <Tooltip title="Delete endpoint">
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(ep)}
                          color="error"
                        >
                          <DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
}
