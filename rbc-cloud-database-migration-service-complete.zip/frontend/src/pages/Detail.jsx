import { useCallback, useEffect, useRef, useState } from "react";
import {
  Box,
  Button,
  Chip,
  CircularProgress,
  Collapse,
  Divider,
  IconButton,
  Paper,
  Stack,
  Step,
  StepButton,
  Stepper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import RadioButtonUncheckedIcon from "@mui/icons-material/RadioButtonUnchecked";
import DoNotDisturbOnIcon from "@mui/icons-material/DoNotDisturbOn";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import api from "../api";
import { friendlyError } from "../errorText";
import { DiscoverPanel, ConvertPanel, ValidatePanel } from "./StepPanels";
import { ReplicatePanel, CutoverPanel } from "./LivePanels";
import { CodeTrackPanel } from "./CodeTrack";

// Labels shown on the stepper / panel headers.
const STAGE_LABEL = {
  discover: "Discover",
  convert: "Schema conversion",
  replicate: "Replicate",
  validate: "Validate",
  cutover: "Cutover",
  code: "Code refactoring",
};

// Prefix used to match legacy event messages for every stage. Old events
// have no `stage` field and their msg starts with this prefix; new events
// carry `e.stage` directly. Code-track events are Devin session messages.
const EVENT_PREFIX = {
  discover: "Discover",
  convert: "Convert",
  replicate: "Replicate",
  validate: "Validate",
  cutover: "Cutover",
  code: "Devin",
};

// status -> chip label/color, mirrors statusPill() in the legacy app.js
const STATUS_MAP = {
  replicating: { label: "Running", color: "primary" },
  ready: { label: "Ready", color: "success" },
  completed: { label: "Completed", color: "success" },
  failed: { label: "Failed", color: "error" },
  attention: { label: "Failed", color: "error" },
  draft: { label: "Draft", color: "default" },
  discovered: { label: "Running", color: "primary" },
};

// postgres/postgresql -> "pg", mysql/mariadb -> "mysql" — used to decide
// whether a migration is cross-engine (different families).
function fam(engine) {
  if (!engine) return "";
  const low = String(engine).toLowerCase();
  return low === "postgres" || low === "postgresql" ? "pg" : "mysql";
}

// Compose the journey steps at runtime from the migration's engine pair +
// whether a code track exists (cross-engine with refactoring enabled).
function computeSteps(m) {
  if (!m) return [];
  const cross = fam(m.sourceEngine) !== fam(m.targetEngine);
  return [
    "discover",
    ...(cross ? ["convert"] : []),
    "replicate",
    "validate",
    "cutover",
    ...(m.codeTrack ? ["code"] : []),
  ];
}

// Derive the step state for a given step key — data stages read straight
// from m.stages; the "code" (app refactoring) step derives from codeTrack.
function stepState(m, st) {
  if (st === "code") {
    const ct = m.codeTrack;
    if (!ct) return "pending";
    if (ct.devin?.status === "error") return "failed";
    if (ct.steps?.pr === "done") return "done";
    if (ct.devin?.status === "working") return "running";
    return "pending";
  }
  if (
    st === "replicate" &&
    m.stages[st] === "running" &&
    (m.status === "completed" || m.stages.cutover === "done")
  ) {
    return "done";
  }

  return m.stages[st];
}

function StatusChip({ status }) {
  const m = STATUS_MAP[status] || { label: status, color: "default" };
  return <Chip size="small" label={m.label} color={m.color} variant={m.color === "default" ? "outlined" : "filled"} />;
}

// Icon per raw stage state — done/skipped/running/failed/pending
function StageIcon({ state }) {
  if (state === "done") return <CheckCircleIcon fontSize="small" color="success" />;
  if (state === "failed") return <ErrorIcon fontSize="small" color="error" />;
  if (state === "skipped") return <DoNotDisturbOnIcon fontSize="small" color="disabled" />;
  if (state === "running")
    return (
      <AutorenewIcon
        fontSize="small"
        color="primary"
        sx={{
          animation: "mh-spin 1.1s linear infinite, mh-pulse 1.6s ease-in-out infinite",
          "@keyframes mh-spin": { from: { transform: "rotate(0deg)" }, to: { transform: "rotate(360deg)" } },
          "@keyframes mh-pulse": { "0%, 100%": { opacity: 1 }, "50%": { opacity: 0.45 } },
        }}
      />
    );
  return <RadioButtonUncheckedIcon fontSize="small" color="disabled" />;
}

function computeDefaultStep(m, steps) {
  for (const st of steps) {
    const state = stepState(m, st);
    if (state === "running" || state === "failed") return st;
  }
  if (m.status === "ready" && steps.includes("validate")) return "validate";
  let last = steps[0] || "discover";
  for (const st of steps) {
    if (stepState(m, st) === "done") last = st;
  }
  return last;
}

// Unified matcher: accepts an event for a stage when e.stage === stage, or
// (for legacy events with no stage field) when msg starts with the stage's
// legacy prefix.
function latestStageEvent(m, stage) {
  const events = m.events || [];
  const prefix = EVENT_PREFIX[stage];
  for (let i = events.length - 1; i >= 0; i--) {
    const e = events[i];
    if (e.stage === stage) return e;
    if (!e.stage && e.msg && prefix && e.msg.startsWith(prefix)) return e;
  }
  return null;
}

// Short status captions for the journey stepper — no raw event text, just a
// terse phrase describing where each step stands.
function stepCaption(m, st) {
  const state = stepState(m, st);
  if (st === "discover") {
    if (state === "done") return `${(m.tables || []).length} tables`;
    if (state === "running") return "Running";
    if (state === "failed") return "Failed";
    return "Not run";
  }
  if (st === "convert") {
    if (state === "skipped") return "Skipped — same family";
    if (state === "done") return `${(m.conversion?.tables || []).length} tables converted`;
    if (state === "running") return "Converting";
    if (state === "failed") return "Failed";
    return "Not run";
  }
  if (st === "replicate") {
    if (state === "failed") return "Failed";
    if (state === "running") {
      if (m.progress?.snapshotComplete) {
        return `Streaming · ${(m.progress?.eventsApplied || 0).toLocaleString()} events`;
      }
      const included = (m.tables || []).filter((t) => t.include);
      const total = included.reduce((sum, t) => sum + (t.sourceRows || t.rows || 0), 0);
      return `Snapshot · ${(m.progress?.eventsApplied || 0).toLocaleString()} of ${total} rows`;
    }
    if (state === "done") return "Done";
    return "Not run";
  }
  if (st === "validate") {
    if (m.validation) {
      const tables = m.validation.tables;
      let n = 0;
      let k = 0;
      if (tables) {
        const list = Array.isArray(tables) ? tables : Object.values(tables);
        n = list.length;
        k = list.filter((t) => t.match === false).length;
      }
      if (m.validation.passed) return `Passed · ${n} tables`;
      return `Failed · ${k} mismatch${k === 1 ? "" : "es"}`;
    }
    if (state === "running") return "Running";
    if (state === "failed") return "Failed";
    return "Not run";
  }
  if (st === "cutover") {
    if (state === "done") {
      const ts = m.completedAt || m.cutoverAt;
      return ts ? `Done ${new Date(ts).toLocaleDateString()}` : "Done";
    }
    if (state === "running") return "Running";
    if (state === "failed") return "Failed";
    return "Ready when validation passes";
  }
  return state;
}

function truncate(str, n) {
  if (!str) return str;
  return str.length > n ? str.slice(0, n - 1) + "…" : str;
}

export default function Detail({ migrationId, onBack, notify }) {
  const [m, setM] = useState(null);
  const [runningStage, setRunningStage] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [selectedStep, setSelectedStep] = useState(null);
  const [expandedTable, setExpandedTable] = useState(null);
  const [lastFetchAt, setLastFetchAt] = useState(null);
  const [, setTick] = useState(0);
  const userSelectedRef = useRef(false);
  const timerRef = useRef(null);

  const fetchMigration = useCallback(async () => {
    try {
      const data = await api.getMigration(migrationId);
      setM(data);
      setLastFetchAt(Date.now());
    } catch (err) {
      notify("Could not refresh migration", err.message, "error");
    }
  }, [migrationId, notify]);

  // Poll every 2.5s while this page is mounted — keep polling even after
  // completion, mirroring the legacy behavior (refresh runs regardless of
  // status as long as the detail view is open).
  useEffect(() => {
    fetchMigration();
    timerRef.current = setInterval(fetchMigration, 2500);
    return () => clearInterval(timerRef.current);
  }, [fetchMigration]);

  // Tick once a second so the "Updated Ns ago" caption stays fresh without
  // depending on the 2.5s poll cycle.
  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // Keep following the default-selection rule until the user manually
  // picks a step; once they do, their choice sticks across polls. If the
  // currently selected step disappears (defensive — e.g. codeTrack is
  // removed), fall back to "discover".
  useEffect(() => {
    if (!m) return;
    const steps = computeSteps(m);
    if (!userSelectedRef.current) {
      setSelectedStep(computeDefaultStep(m, steps));
    } else if (selectedStep && !steps.includes(selectedStep)) {
      setSelectedStep("discover");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [m]);

  const handleSelectStep = (st) => {
    userSelectedRef.current = true;
    setSelectedStep(st);
  };

  if (!m) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  const steps = computeSteps(m);

  const pipelineSteps = steps.filter((s) => s !== "code");
  // --- gates (exact rules from the brief) ---
  const locked = m.status === "completed" || m.stages.cutover === "done";
  const canCutover = !locked && m.validation && m.validation.passed;

  const NEXT_COPY = {
    discover: { guide: "Next step: Discover — inventory the source tables", button: "Run Discover" },
    convert: { guide: "Next step: Schema conversion — translate the schema to the target engine", button: "Run conversion" },
    replicate: { guide: "Next step: Replicate — copy the data and stream changes", button: "Start replication" },
    validate: { guide: "Next step: Validate — confirm the target matches the source", button: "Run validation" },
    cutover: { guide: "Next step: Cutover — finalize and hand over to the target", button: "Go to cutover" },
  };
  let nextGuide = null;
  if (!locked) {
    const failedStep = pipelineSteps.find((st) => stepState(m, st) === "failed");
    if (failedStep) {
      nextGuide = {
        step: failedStep,
        guide: `${STAGE_LABEL[failedStep]} failed — fix or retry`,
        button: `Retry ${STAGE_LABEL[failedStep].toLowerCase()}`,
        action: "run",
        failed: true,
      };
    } else {
      const repState = stepState(m, "replicate");
      const valState = stepState(m, "validate");
      let step = null;
      let action = "run";
      if (stepState(m, "discover") !== "done" && stepState(m, "discover") !== "skipped") {
        step = "discover";
      } else if (steps.includes("convert") && stepState(m, "convert") !== "done" && stepState(m, "convert") !== "skipped") {
        step = "convert";
      } else if (repState === "running") {
        if (valState === "done") { step = "cutover"; action = "select"; }
        else step = "validate";
      } else if (repState !== "done" && repState !== "skipped") {
        step = "replicate";
      } else if (valState !== "done") {
        step = "validate";
      } else if (stepState(m, "cutover") !== "done") {
        step = "cutover";
        action = "select";
      }
      if (step) {
        nextGuide = {
          step,
          guide: NEXT_COPY[step].guide,
          button: NEXT_COPY[step].button,
          action,
          failed: false,
        };
      }
    }
    if (nextGuide && (stepState(m, nextGuide.step) === "running" || runningStage === nextGuide.step)) {
      nextGuide = { ...nextGuide, running: true };
    }
  }
  const nextStepKey = nextGuide ? nextGuide.step : null;

  const included = m.tables.filter((t) => t.include);

  const handleRunStage = async (stage) => {
    setRunningStage(stage);
    try {
      await api.runStage(m.id, stage);
      notify(`${STAGE_LABEL[stage]} finished`, `Stage completed for ${m.name}.`);
    } catch (err) {
      notify(`${STAGE_LABEL[stage]} failed`, friendlyError(err), "error");
    } finally {
      setRunningStage(null);
      fetchMigration();
    }
  };

  const handleDevinRefresh = async () => {
    try {
      const upd = await api.refreshCodeTrack(m.id);
      setM(upd);
      notify("Devin status updated", `Session status: ${upd.codeTrack?.devin?.status || "unknown"}.`, "success");
    } catch (err) {
      notify("Could not refresh Devin status", err.message, "error");
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await api.deleteMigration(m.id);
      notify("Migration deleted", `${m.name} has been removed.`);
      onBack();
    } catch (err) {
      notify("Could not delete migration", err.message, "error");
      setDeleting(false);
    }
  };

  // target rows: prefer the latest validation snapshot, fall back to
  // sourceRows once the full-load snapshot has completed, else raw targetRows
  const targetRowsFor = (t) => {
    if (m.validation && m.validation.tables && m.validation.tables[t.name]) {
      return m.validation.tables[t.name].targetRows;
    }
    if (m.progress?.snapshotComplete) return t.rows || t.sourceRows || 0;
    return t.targetRows || 0;
  };

  // m.conversion = { generatedAt, tables: [{ table, sourceColumns: [{name,
  // type}], targetColumns: [{name, type}], ddl }] } — find the entry for
  // this table and zip source/target columns by name into mapping rows.
  const conversionFor = (name) => {
    const tables = m.conversion?.tables || [];
    const entry = tables.find((t) => t.table === name);
    if (!entry) return null;
    const sourceColumns = entry.sourceColumns || [];
    const targetColumns = entry.targetColumns || [];
    const mapping = sourceColumns.map((sc) => {
      const tc = targetColumns.find((c) => c.name === sc.name);
      return { column: sc.name, sourceType: sc.type, targetType: tc ? tc.type : undefined };
    });
    const ddl = entry.ddl || "";
    return { mapping, ddl };
  };

  const panelProps = { m, notify, onRunStage: handleRunStage, runningStage, locked };

  const renderStepPanel = () => {
    switch (selectedStep) {
      case "discover":
        return <DiscoverPanel {...panelProps} />;
      case "convert":
        return <ConvertPanel {...panelProps} />;
      case "replicate":
        return <ReplicatePanel {...panelProps} />;
      case "validate":
        return <ValidatePanel {...panelProps} />;
      case "cutover":
        return <CutoverPanel {...panelProps} onCutover={() => handleRunStage("cutover")} canCutover={canCutover} />;
      case "code":
        return <CodeTrackPanel m={m} notify={notify} onDevinRefresh={handleDevinRefresh} />;
      default:
        return null;
    }
  };

  return (
    <Box>
      <Button onClick={onBack} sx={{ mb: 2, px: 0 }} color="inherit">
        ← All migrations
      </Button>

      {/* ---------- header ---------- */}
      <Stack direction="row" alignItems="flex-start" justifyContent="space-between" sx={{ flexWrap: "wrap", gap: 1 }}>
        <Typography variant="h4" sx={{ fontWeight: 650 }}>
          {m.name}
        </Typography>
        <Button variant="text" color="error" size="small" disabled={deleting} onClick={handleDelete}>
          Delete migration
        </Button>
      </Stack>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 0.75, mb: 3, flexWrap: "wrap" }}>
        <Typography variant="body2" color="text.secondary">
          {m.sourceEngine} → {m.targetEngine} · {included.length} of {m.tables.length} tables ·
        </Typography>
        <StatusChip status={m.status} />
        {lastFetchAt && (
          <Typography variant="caption" color="text.secondary">
            {(() => {
              const seconds = Math.floor((Date.now() - lastFetchAt) / 1000);
              return seconds < 2 ? "· Updated just now" : `· Updated ${seconds}s ago`;
            })()}
          </Typography>
        )}
      </Stack>

      {/* ---------- journey stepper (data steps + conditional convert/code) ---------- */}
      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1.5 }}>
        Migration journey
      </Typography>
      <Paper variant="outlined" sx={{ p: 2.5, mb: 2 }}>
        <Stepper alternativeLabel nonLinear>
          {steps.map((st) => {
            const state = stepState(m, st);
            const isSelected = selectedStep === st;
            let secondary;
            if (st === "code") {
              const lastEvent = latestStageEvent(m, st);
              secondary = lastEvent ? truncate(lastEvent.msg, 42) : state;
            } else {
              secondary = stepCaption(m, st);
            }
            return (
              <Step key={st} completed={state === "done" || state === "skipped"}>
                <StepButton
                  onClick={() => handleSelectStep(st)}
                  icon={
                    st === nextStepKey ? (
                      <Box
                        sx={{
                          display: "inline-flex",
                          borderRadius: "50%",
                          boxShadow: (th) =>
                            `0 0 0 3px ${th.palette[nextGuide.failed ? "error" : "primary"].main}40`,
                          animation: "mh-pulse 1.6s ease-in-out infinite",
                          "@keyframes mh-pulse": { "0%, 100%": { opacity: 1 }, "50%": { opacity: 0.45 } },
                        }}
                      >
                        <StageIcon state={state} />
                      </Box>
                    ) : (
                      <StageIcon state={state} />
                    )
                  }
                  sx={{
                    borderRadius: 2,
                    px: 1,
                    py: 0.5,
                    bgcolor: isSelected
                      ? (th) => `${th.palette.primary.main}14`
                      : "transparent",
                    "& .MuiStepLabel-label": {
                      fontWeight: isSelected ? 700 : 400,
                    },
                  }}
                >
                  {STAGE_LABEL[st]}
                  {state === "skipped" ? " (skipped)" : ""}
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ display: "block", textAlign: "center", mt: 0.25, px: 1 }}
                  >
                    {secondary}
                  </Typography>
                </StepButton>
              </Step>
            );
          })}
        </Stepper>
      </Paper>

      {nextGuide && !locked && (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 2,
            border: 1,
            borderColor: nextGuide.failed ? "error.main" : "divider",
            borderRadius: 1,
            px: 2,
            py: 1.25,
            mb: 2,
          }}
        >
          <Typography variant="body2" sx={{ fontWeight: 550 }}>
            {nextGuide.guide}
          </Typography>
          <Button
            variant="contained"
            size="small"
            color={nextGuide.failed ? "error" : "primary"}
            disabled={nextGuide.running}
            startIcon={nextGuide.running ? <CircularProgress size={14} /> : null}
            onClick={() => {
              handleSelectStep(nextGuide.step);
              if (nextGuide.action === "run") handleRunStage(nextGuide.step);
            }}
          >
            {nextGuide.button}
          </Button>
        </Box>
      )}

      {locked && (
        <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 2 }}>
          Migration completed — stages are locked.
        </Typography>
      )}

      {/* ---------- selected step panel ---------- */}
      <Paper variant="outlined" sx={{ p: 2.5, mb: 3 }}>
        {renderStepPanel()}
      </Paper>

      {/* ---------- tables ---------- */}
      <Divider sx={{ my: 3 }} />
      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1.5 }}>
        Tables
      </Typography>
      <Paper variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ width: 40 }} />
              <TableCell>Table</TableCell>
              <TableCell align="right">Source rows</TableCell>
              <TableCell align="right">Events applied</TableCell>
              <TableCell align="right">Target rows</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {m.tables.map((t) => {
              const isOpen = expandedTable === t.name;
              const conv = conversionFor(t.name);
              return (
                <>
                  <TableRow
                    key={t.name}
                    hover
                    onClick={() => setExpandedTable(isOpen ? null : t.name)}
                    sx={{ cursor: "pointer" }}
                  >
                    <TableCell>
                      <IconButton size="small" onClick={(e) => { e.stopPropagation(); setExpandedTable(isOpen ? null : t.name); }}>
                        {isOpen ? <KeyboardArrowDownIcon fontSize="small" /> : <KeyboardArrowRightIcon fontSize="small" />}
                      </IconButton>
                    </TableCell>
                    <TableCell>
                      {t.name}
                      {!t.include && (
                        <Chip size="small" variant="outlined" label="excluded" sx={{ ml: 1 }} />
                      )}
                    </TableCell>
                    <TableCell align="right">{(t.rows || t.sourceRows || 0).toLocaleString()}</TableCell>
                    <TableCell align="right">{(m.progress?.perTable?.[t.name] || 0).toLocaleString()}</TableCell>
                    <TableCell align="right">{targetRowsFor(t).toLocaleString()}</TableCell>
                  </TableRow>
                  <TableRow key={`${t.name}-detail`}>
                    <TableCell colSpan={5} sx={{ p: 0, borderBottom: isOpen ? undefined : "none" }}>
                      <Collapse in={isOpen} timeout="auto" unmountOnExit>
                        <Box sx={{ p: 2, bgcolor: "action.hover" }}>
                          {conv ? (
                            <Stack spacing={1.5}>
                              {conv.mapping.length > 0 && (
                                <Table size="small">
                                  <TableHead>
                                    <TableRow>
                                      <TableCell>Column</TableCell>
                                      <TableCell>Source type</TableCell>
                                      <TableCell>Target type</TableCell>
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {conv.mapping.map((row, i) => {
                                      const changed = row.sourceType !== row.targetType;
                                      return (
                                        <TableRow key={i}>
                                          <TableCell>{row.column}</TableCell>
                                          <TableCell>{row.sourceType}</TableCell>
                                          <TableCell>
                                            <Box component="span" sx={{ fontWeight: changed ? 600 : 400 }}>
                                              {row.targetType}
                                            </Box>
                                            {changed && (
                                              <Typography
                                                component="span"
                                                variant="caption"
                                                color="text.secondary"
                                                sx={{ ml: 0.75 }}
                                              >
                                                changed
                                              </Typography>
                                            )}
                                          </TableCell>
                                        </TableRow>
                                      );
                                    })}
                                  </TableBody>
                                </Table>
                              )}
                              {conv.ddl && (
                                <Box
                                  component="pre"
                                  sx={{
                                    m: 0,
                                    p: 1.5,
                                    fontFamily: "monospace",
                                    fontSize: 12,
                                    bgcolor: "background.paper",
                                    border: (th) => `1px solid ${th.palette.divider}`,
                                    borderRadius: 1,
                                    overflowX: "auto",
                                  }}
                                >
                                  {conv.ddl}
                                </Box>
                              )}
                            </Stack>
                          ) : (
                            <Typography variant="body2" color="text.secondary">
                              No conversion data for this table.
                            </Typography>
                          )}
                        </Box>
                      </Collapse>
                    </TableCell>
                  </TableRow>
                </>
              );
            })}
          </TableBody>
        </Table>
      </Paper>

      {/* ---------- progress line (replicating only) ---------- */}
      {m.status === "replicating" && (
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1.5 }}>
          Events applied: <b>{(m.progress?.eventsApplied || 0).toLocaleString()}</b> · Snapshot:{" "}
          {m.progress?.snapshotComplete ? "complete — now streaming live changes" : "in progress"}
          {m.progress?.error ? (
            <Box component="span" sx={{ color: "error.main" }}>
              {" "}
              · {m.progress.error}
            </Box>
          ) : null}
        </Typography>
      )}
    </Box>
  );
}
