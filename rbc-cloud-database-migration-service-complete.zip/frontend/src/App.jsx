import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { ThemeProvider, CssBaseline, alpha } from "@mui/material";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import Button from "@mui/material/Button";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import AlertTitle from "@mui/material/AlertTitle";
import Chip from "@mui/material/Chip";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import TextField from "@mui/material/TextField";

import SwapHorizRoundedIcon from "@mui/icons-material/SwapHorizRounded";
import SpaceDashboardOutlinedIcon from "@mui/icons-material/SpaceDashboardOutlined";
import SyncAltRoundedIcon from "@mui/icons-material/SyncAltRounded";
import DnsOutlinedIcon from "@mui/icons-material/DnsOutlined";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import CircleIcon from "@mui/icons-material/Circle";

import { buildTheme } from "./theme";
import api from "./api";

import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Endpoints from "./pages/Endpoints";
import Detail from "./pages/Detail";
import Wizard from "./wizard/Wizard";

const DRAWER_WIDTH = 260;

// ---------------------------------------------------------------------------
// Toast context — a single, simple notify(title, message, severity) helper
// shared by every page/dialog without prop-drilling. Severity follows MUI
// Alert's vocabulary: "success" | "error" | "info" | "warning".
// ---------------------------------------------------------------------------
const ToastContext = createContext(() => {});
export const useToast = () => useContext(ToastContext);

function hostOf(url) {
  if (!url) return "";
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
}

export default function App() {
  // ---- theme ----
  const [mode, setMode] = useState(() => localStorage.getItem("mh-theme") || "light");
  useEffect(() => localStorage.setItem("mh-theme", mode), [mode]);
  const theme = useMemo(() => buildTheme(mode), [mode]);
  const toggleTheme = useCallback(() => setMode((m) => (m === "light" ? "dark" : "light")), []);

  // ---- top-level view ----
  const [view, setView] = useState("landing"); // "landing" | "login" | "app"
  const [page, setPage] = useState("dashboard"); // "dashboard" | "endpoints" | "detail" | "wizard"
  const [selectedMigId, setSelectedMigId] = useState(null);

  // ---- shared data (for nav counts + pages) ----
  const [endpoints, setEndpoints] = useState([]);
  const [migrations, setMigrations] = useState([]);
  const [health, setHealth] = useState(null);
  const [fallbackEngine, setFallbackEngine] = useState(null);

  // ---- toast ----
  const [toast, setToast] = useState({ open: false, title: "", message: null, severity: "success" });
  const notify = useCallback((title, message, severity = "success") => {
    setToast({ open: true, title, message: message ?? null, severity });
  }, []);
  const closeToast = () => setToast((t) => ({ ...t, open: false }));

  // ---- engine settings dialog ----
  const [engineDialogOpen, setEngineDialogOpen] = useState(false);
  const [engineForm, setEngineForm] = useState({ label: "", connectUrl: "", kafkaBootstrap: "" });
  const [engineTest, setEngineTest] = useState(null); // {ok, message} | null
  const [engineTesting, setEngineTesting] = useState(false);
  const [engineSaving, setEngineSaving] = useState(false);
  const [devinInfo, setDevinInfo] = useState(null);

  const refreshEndpoints = useCallback(async () => {
    try {
      const eps = await api.listEndpoints();
      setEndpoints(eps);
      return eps;
    } catch (e) {
      notify("Backend unreachable", e.message, "error");
      return [];
    }
  }, [notify]);

  const refreshMigrations = useCallback(async () => {
    try {
      const migs = await api.listMigrations();
      setMigrations(migs);
      return migs;
    } catch (e) {
      notify("Backend unreachable", e.message, "error");
      return [];
    }
  }, [notify]);

  const refreshHealth = useCallback(async () => {
    try {
      const h = await api.health();
      setHealth(h);
      return h;
    } catch (e) {
      setHealth({ connect: { up: false } });
      return null;
    }
  }, []);

  const refreshAll = useCallback(async () => {
    await Promise.all([refreshEndpoints(), refreshMigrations(), refreshHealth()]);
  }, [refreshEndpoints, refreshMigrations, refreshHealth]);

  // Fetch endpoints + migrations + health once the app shell mounts (sign-in).
  useEffect(() => {
    if (view === "app") refreshAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  // If health doesn't carry an "engine" block (older backend), fall back to
  // the settings endpoint so the drawer footer still has something to show.
  useEffect(() => {
    if (view === "app" && health && !health.engine && !fallbackEngine) {
      api
        .getEngineSettings()
        .then(setFallbackEngine)
        .catch(() => {});
    }
  }, [view, health, fallbackEngine]);

  // ---- navigation helpers ----
  const goDashboard = () => {
    setPage("dashboard");
    setSelectedMigId(null);
    refreshMigrations();
  };
  const goEndpoints = () => {
    setPage("endpoints");
    setSelectedMigId(null);
    refreshEndpoints();
  };
  const openMigration = (id) => {
    setSelectedMigId(id);
    setPage("detail");
  };
  const handleSignIn = async (provider) => {
    notify("Signed in", null, "success");
    setView("app");
    setPage("dashboard");
  };
  const handleSignOut = () => {
    setView("landing");
    setPage("dashboard");
    setSelectedMigId(null);
  };

  const handleLaunched = (migrationId) => {
    refreshMigrations();
    refreshEndpoints();
    setSelectedMigId(migrationId);
    setPage("detail");
  };

  const handleMigrationDeleted = () => {
    setSelectedMigId(null);
    setPage("dashboard");
    refreshMigrations();
  };

  const engineUp = !!(health && health.connect && health.connect.up);
  const effectiveEngine = (health && health.engine) || fallbackEngine || null;
  const engineFooterLabel = effectiveEngine
    ? `${effectiveEngine.label} · ${hostOf(effectiveEngine.connectUrl)}`
    : "Engine: checking…";

  // ---- engine settings dialog handlers ----
  const openEngineDialog = async () => {
    setEngineTest(null);
    setEngineDialogOpen(true);
    try {
      const s = await api.getEngineSettings();
      setEngineForm({ label: s.label, connectUrl: s.connectUrl, kafkaBootstrap: s.kafkaBootstrap });
    } catch (e) {
      if (effectiveEngine) {
        setEngineForm({
          label: effectiveEngine.label,
          connectUrl: effectiveEngine.connectUrl,
          kafkaBootstrap: effectiveEngine.kafkaBootstrap,
        });
      }
    }
    try {
      const d = await api.getDevinSettings();
      setDevinInfo(d);
    } catch (e) {
      setDevinInfo(null);
    }
  };
  const closeEngineDialog = () => {
    setEngineDialogOpen(false);
    setEngineTest(null);
  };
  const updateEngineField = (field) => (e) =>
    setEngineForm((f) => ({ ...f, [field]: e.target.value }));

  const testEngineConnection = async () => {
    setEngineTesting(true);
    setEngineTest(null);
    try {
      const r = await api.testEngineSettings({ connectUrl: engineForm.connectUrl });
      if (r.up) {
        setEngineTest({ ok: true, message: `Connected — Kafka Connect ${r.version} · cluster ${r.clusterId}` });
      } else {
        setEngineTest({ ok: false, message: r.error || "Connection failed" });
      }
    } catch (e) {
      setEngineTest({ ok: false, message: e.message });
    } finally {
      setEngineTesting(false);
    }
  };

  const saveEngineSettings = async () => {
    setEngineSaving(true);
    try {
      const saved = await api.saveEngineSettings(engineForm);
      notify("Engine target saved", saved.label, "success");
      await refreshHealth();
      setEngineDialogOpen(false);
      setEngineTest(null);
    } catch (e) {
      notify("Save failed", e.message, "error");
    } finally {
      setEngineSaving(false);
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <ToastContext.Provider value={notify}>
        {view === "landing" && <Landing onSignIn={() => setView("login")} mode={mode} onToggleTheme={toggleTheme} />}

        {view === "login" && (
          <Login onLogin={handleSignIn} onBack={() => setView("landing")} mode={mode} onToggleTheme={toggleTheme} />
        )}

        {view === "app" && (
          <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "background.default" }}>
            {/* ---------------- left drawer ---------------- */}
            <Drawer
              variant="permanent"
              sx={{
                width: DRAWER_WIDTH,
                flexShrink: 0,
                "& .MuiDrawer-paper": { width: DRAWER_WIDTH, boxSizing: "border-box" },
              }}
            >
              <Box sx={{ display: "flex", flexDirection: "column", height: "100%", px: 2, py: 2.5 }}>
                {/* brand */}
                <Stack direction="row" spacing={1.25} alignItems="center" sx={{ px: 0.5, mb: 2.5 }}>
                  <Box
                    sx={{
                      width: 34,
                      height: 34,
                      borderRadius: 2,
                      bgcolor: "primary.main",
                      color: "primary.contrastText",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <SwapHorizRoundedIcon fontSize="small" />
                  </Box>
                  <Typography variant="h5" sx={{ letterSpacing: "-0.01em" }}>
                    Migration Hub
                  </Typography>
                </Stack>

                {/* workspace card */}
                <Paper
                  variant="outlined"
                  sx={{
                    p: 1.5,
                    mb: 2.5,
                    bgcolor: (t) => (t.palette.mode === "light" ? t.palette.grey[50] : t.palette.grey[100]),
                  }}
                >
                  <Typography
                    variant="caption"
                    sx={{ color: "text.secondary", letterSpacing: "0.08em", fontWeight: 700 }}
                  >
                    WORKSPACE
                  </Typography>
                  <Typography variant="subtitle1" sx={{ mt: 0.25 }}>
                    Production — EU
                  </Typography>
                  <Typography variant="caption" sx={{ color: "text.secondary" }}>
                    Private networking · Audit on
                  </Typography>
                </Paper>

                {/* nav */}
                <List disablePadding sx={{ "& .MuiListItemButton-root": { mb: 0.5 } }}>
                  <ListItemButton selected={page === "dashboard"} onClick={goDashboard}>
                    <ListItemIcon sx={{ minWidth: 36 }}>
                      <SpaceDashboardOutlinedIcon fontSize="small" />
                    </ListItemIcon>
                    <ListItemText primary="Dashboard" primaryTypographyProps={{ fontWeight: 600, fontSize: "0.875rem" }} />
                  </ListItemButton>

                  <ListItemButton selected={page === "dashboard"} onClick={goDashboard}>
                    <ListItemIcon sx={{ minWidth: 36 }}>
                      <SyncAltRoundedIcon fontSize="small" />
                    </ListItemIcon>
                    <ListItemText primary="Migrations" primaryTypographyProps={{ fontWeight: 600, fontSize: "0.875rem" }} />
                    <Chip size="small" label={migrations.length} sx={{ bgcolor: "action.hover", fontWeight: 700 }} />
                  </ListItemButton>

                  <ListItemButton selected={page === "endpoints"} onClick={goEndpoints}>
                    <ListItemIcon sx={{ minWidth: 36 }}>
                      <DnsOutlinedIcon fontSize="small" />
                    </ListItemIcon>
                    <ListItemText primary="Endpoints" primaryTypographyProps={{ fontWeight: 600, fontSize: "0.875rem" }} />
                    <Chip size="small" label={endpoints.length} sx={{ bgcolor: "action.hover", fontWeight: 700 }} />
                  </ListItemButton>

                  <ListItemButton onClick={openEngineDialog}>
                    <ListItemIcon sx={{ minWidth: 36 }}>
                      <SettingsOutlinedIcon fontSize="small" />
                    </ListItemIcon>
                    <ListItemText primary="Settings" primaryTypographyProps={{ fontWeight: 600, fontSize: "0.875rem" }} />
                  </ListItemButton>
                </List>

                <Box sx={{ flexGrow: 1 }} />

                <Divider sx={{ my: 1.5 }} />

                {/* engine status — now a button opening engine settings */}
                <Tooltip title="Engine settings">
                  <Button
                    onClick={openEngineDialog}
                    fullWidth
                    color="inherit"
                    sx={{
                      justifyContent: "flex-start",
                      textTransform: "none",
                      px: 0.5,
                      py: 0.5,
                      mb: 1,
                      color: "text.secondary",
                      "&:hover": { bgcolor: "action.hover" },
                    }}
                    startIcon={<CircleIcon sx={{ fontSize: 8, color: engineUp ? "success.main" : "error.main" }} />}
                    endIcon={<SettingsOutlinedIcon fontSize="small" />}
                  >
                    <Typography
                      variant="caption"
                      sx={{ fontWeight: 600, flexGrow: 1, textAlign: "left", overflow: "hidden", textOverflow: "ellipsis" }}
                    >
                      {engineFooterLabel}
                    </Typography>
                  </Button>
                </Tooltip>

                <Stack direction="row" spacing={1} sx={{ px: 0.5 }}>
                  <Tooltip title={mode === "light" ? "Switch to dark" : "Switch to light"}>
                    <IconButton size="small" onClick={toggleTheme} sx={{ border: "1px solid", borderColor: "divider" }}>
                      {mode === "light" ? (
                        <DarkModeOutlinedIcon fontSize="small" />
                      ) : (
                        <LightModeOutlinedIcon fontSize="small" />
                      )}
                    </IconButton>
                  </Tooltip>
                  <Button
                    size="small"
                    fullWidth
                    variant="outlined"
                    color="inherit"
                    startIcon={<LogoutRoundedIcon fontSize="small" />}
                    onClick={handleSignOut}
                  >
                    Sign out
                  </Button>
                </Stack>
              </Box>
            </Drawer>

            {/* ---------------- main area ---------------- */}
            <Box component="main" sx={{ flexGrow: 1, minWidth: 0, display: "flex", justifyContent: "center" }}>
              <Box sx={{ width: "100%", maxWidth: 1150, px: 4, py: 4 }}>
                {page === "dashboard" && (
                  <Dashboard
                    migrations={migrations}
                    endpoints={endpoints}
                    onOpen={(m) => openMigration(m.id)}
                    onNewMigration={() => setPage("wizard")}
                    onManageEndpoints={goEndpoints}
                    refresh={refreshMigrations}
                  />
                )}
                {page === "endpoints" && (
                  <Endpoints endpoints={endpoints} refresh={refreshEndpoints} notify={notify} />
                )}
                {page === "detail" && selectedMigId && (
                  <Detail migrationId={selectedMigId} onBack={goDashboard} notify={notify} />
                )}
                {page === "wizard" && (
                  <Wizard
                    endpoints={endpoints}
                    onEndpointsChanged={refreshEndpoints}
                    onExit={goDashboard}
                    onLaunched={handleLaunched}
                  />
                )}
              </Box>
            </Box>

            {/* ---------------- engine settings dialog ---------------- */}
            <Dialog open={engineDialogOpen} onClose={closeEngineDialog} maxWidth="xs" fullWidth>
              <DialogTitle>Engine settings</DialogTitle>
              <DialogContent>
                <Stack spacing={2} sx={{ mt: 0.5 }}>
                  <TextField
                    label="Label"
                    size="small"
                    fullWidth
                    value={engineForm.label}
                    onChange={updateEngineField("label")}
                  />
                  <TextField
                    label="Connect REST URL"
                    size="small"
                    fullWidth
                    placeholder="http://127.0.0.1:8083"
                    value={engineForm.connectUrl}
                    onChange={updateEngineField("connectUrl")}
                  />
                  <TextField
                    label="Kafka bootstrap"
                    size="small"
                    fullWidth
                    placeholder="127.0.0.1:9092"
                    value={engineForm.kafkaBootstrap}
                    onChange={updateEngineField("kafkaBootstrap")}
                  />

                  <Stack direction="row" spacing={1} alignItems="center">
                    <Button size="small" variant="outlined" onClick={testEngineConnection} disabled={engineTesting}>
                      {engineTesting ? "Testing…" : "Test connection"}
                    </Button>
                  </Stack>

                  {engineTest && (
                    <Typography
                      variant="caption"
                      sx={{ color: engineTest.ok ? "success.main" : "error.main", fontWeight: 600 }}
                    >
                      {engineTest.message}
                    </Typography>
                  )}

                  <Typography variant="caption" sx={{ color: "text.secondary" }}>
                    Applies to new connector operations and replication; migrations already replicating keep
                    the engine they started on.
                  </Typography>

                  <Divider />

                  <Typography variant="subtitle2">Devin — code refactoring</Typography>

                  {devinInfo ? (
                    <Stack spacing={0.75}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <Chip
                          size="small"
                          label={devinInfo.mode === "live" ? "Live" : "Stub"}
                          color={devinInfo.mode === "live" ? "success" : "warning"}
                        />
                        <Chip
                          size="small"
                          variant="outlined"
                          label={devinInfo.configured ? "Configured" : "Not configured"}
                        />
                      </Stack>
                      <Typography variant="caption" sx={{ color: "text.secondary" }}>
                        {`Base URL: ${devinInfo.base}`}
                      </Typography>
                      {devinInfo.mode !== "live" && (
                        <Typography variant="caption" sx={{ color: "text.secondary" }}>
                          Add a Devin subscription key to run code refactoring for real.
                        </Typography>
                      )}
                    </Stack>
                  ) : (
                    <Typography variant="caption" sx={{ color: "text.secondary" }}>
                      Devin status unavailable.
                    </Typography>
                  )}
                </Stack>
              </DialogContent>
              <DialogActions sx={{ px: 3, pb: 2 }}>
                <Button onClick={closeEngineDialog} color="inherit">
                  Cancel
                </Button>
                <Button onClick={saveEngineSettings} variant="contained" disabled={engineSaving}>
                  {engineSaving ? "Saving…" : "Save"}
                </Button>
              </DialogActions>
            </Dialog>
          </Box>
        )}

        <Snackbar
          open={toast.open}
          autoHideDuration={4000}
          onClose={closeToast}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert onClose={closeToast} severity={toast.severity} variant="filled" sx={{ width: "100%" }}>
            <AlertTitle sx={{ mb: toast.message ? 0.5 : 0 }}>{toast.title}</AlertTitle>
            {toast.message}
          </Alert>
        </Snackbar>
      </ToastContext.Provider>
    </ThemeProvider>
  );
}
