// Resolves the API base: ops drops a /config.js that sets
// window.__API_BASE__ to the real base at deploy time. Locally, with no
// override, we fall back to the dev backend on :5000.
const BASE =
  typeof window !== "undefined" && window.__API_BASE__
    ? window.__API_BASE__
    : "http://localhost:5000/api";

async function request(path, opts = {}) {
  const res = await fetch(BASE + path, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(body.error || res.statusText || "Request failed");
  }
  return body;
}

const get = (path) => request(path);
const post = (path, data) => request(path, { method: "POST", body: JSON.stringify(data || {}) });
const put = (path, data) => request(path, { method: "PUT", body: JSON.stringify(data || {}) });
const del = (path) => request(path, { method: "DELETE" });

export const api = {
  // --- health ---
  health: () => get("/health"),

  // --- endpoints ---
  listEndpoints: () => get("/endpoints"),
  createEndpoint: (body) => post("/endpoints", body),
  testEndpoint: (id) => post(`/endpoints/${id}/test`),
  deleteEndpoint: (id) => del(`/endpoints/${id}`),
  listTables: (id) => get(`/endpoints/${id}/tables`),
  conversionPreview: (epId, targetEngine, tables) =>
    post(`/endpoints/${epId}/conversion-preview`, {
      targetEngine,
      ...(tables ? { tables } : {}),
    }),

  // --- migrations ---
  listMigrations: () => get("/migrations"),
  getMigration: (id) => get(`/migrations/${id}`),
  createMigration: (body) => post("/migrations", body),
  runAll: (id) => post(`/migrations/${id}/run-all`),
  runStage: (id, stage) => post(`/migrations/${id}/stages/${stage}/run`),
  deleteMigration: (id) => del(`/migrations/${id}`),

  // --- code track ---
  reviewCodeItem: (migId, itemId, decision) =>
    post(`/migrations/${migId}/code-track/items/${itemId}/review`, { decision }),
  refreshCodeTrack: (migId) => post(`/migrations/${migId}/code-track/refresh`),

  // --- engine settings ---
  getEngineSettings: () => get("/settings/engine"),
  saveEngineSettings: (body) => put("/settings/engine", body),
  testEngineSettings: (body) => post("/settings/engine/test", body),

  // --- devin settings ---
  getDevinSettings: () => get("/settings/devin"),
};

export default api;
