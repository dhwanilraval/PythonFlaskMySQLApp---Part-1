import { createTheme } from "@mui/material/styles";

// Hairline divider used as a boundary instead of elevation/shadow.
const HAIRLINE_LIGHT = "rgba(10,15,26,0.08)";
const HAIRLINE_DARK = "rgba(255,255,255,0.09)";

const FONT = [
  "Inter",
  "-apple-system",
  "BlinkMacSystemFont",
  "Segoe UI",
  "Roboto",
  "Helvetica Neue",
  "Arial",
  "sans-serif",
].join(",");

/**
 * Builds the light/dark MUI theme for the app. Kept as a single factory
 * (buildTheme) so App.jsx can rebuild the theme object whenever the user
 * toggles mode, with the preference persisted in localStorage by the caller.
 */
export function buildTheme(mode) {
  const isLight = mode === "light";

  const palette = isLight
    ? {
        mode: "light",
        background: { default: "#f7f7f8", paper: "#ffffff" },
        text: { primary: "#0a0f1a", secondary: "#5b6472" },
        primary: { main: "#2f5cff", dark: "#2447cc", light: "#5c7dff", contrastText: "#ffffff" },
        divider: HAIRLINE_LIGHT,
        success: { main: "#1a8f5a", light: "#e6f6ee" },
        error: { main: "#d13b3b", light: "#fbe9e9" },
        warning: { main: "#b4780f", light: "#fcf1de" },
        info: { main: "#2f5cff" },
        grey: { 50: "#f7f7f8", 100: "#f0f1f3", 200: "#e4e6ea", 300: "#d4d7dd" },
      }
    : {
        mode: "dark",
        background: { default: "#0d1117", paper: "#141a22" },
        text: { primary: "#eef1f6", secondary: "#9aa4b2" },
        primary: { main: "#5c86ff", dark: "#3f63d6", light: "#8aa6ff", contrastText: "#07101f" },
        divider: HAIRLINE_DARK,
        success: { main: "#3ecf8e", light: "rgba(62,207,142,0.12)" },
        error: { main: "#f16767", light: "rgba(241,103,103,0.12)" },
        warning: { main: "#e2a53d", light: "rgba(226,165,61,0.12)" },
        info: { main: "#5c86ff" },
        grey: { 50: "#141a22", 100: "#1a212b", 200: "#232b36", 300: "#2d3644" },
      };

  const hairline = isLight ? HAIRLINE_LIGHT : HAIRLINE_DARK;

  const theme = createTheme({
    palette,
    shape: { borderRadius: 8 },
    spacing: 8,
    typography: {
      fontFamily: FONT,
      h1: { fontFamily: FONT, fontWeight: 700, fontSize: "2.5rem", letterSpacing: "-0.02em" },
      h2: { fontFamily: FONT, fontWeight: 700, fontSize: "1.9rem", letterSpacing: "-0.015em" },
      h3: { fontFamily: FONT, fontWeight: 600, fontSize: "1.375rem", letterSpacing: "-0.01em" },
      h4: { fontFamily: FONT, fontWeight: 600, fontSize: "1.125rem" },
      h5: { fontFamily: FONT, fontWeight: 600, fontSize: "1rem" },
      h6: { fontFamily: FONT, fontWeight: 600, fontSize: "0.9375rem" },
      subtitle1: { fontWeight: 550 },
      subtitle2: { fontWeight: 550, fontSize: "0.8125rem" },
      body1: { fontSize: "0.9375rem" },
      body2: { fontSize: "0.8375rem" },
      button: { textTransform: "none", fontWeight: 600 },
      caption: { fontSize: "0.75rem" },
    },
    transitions: {
      duration: { shortest: 120, shorter: 120, short: 120, standard: 160 },
    },
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          body: {
            backgroundColor: palette.background.default,
            scrollbarColor: `${hairline} transparent`,
          },
          "*": { boxSizing: "border-box" },
        },
      },
      MuiButton: {
        defaultProps: { disableElevation: true },
        styleOverrides: {
          root: {
            textTransform: "none",
            fontWeight: 600,
            borderRadius: 8,
            paddingInline: 16,
            transition: "background-color 120ms ease, border-color 120ms ease, color 120ms ease",
          },
          contained: {
            boxShadow: "none",
            "&:hover": { boxShadow: "none" },
          },
          outlined: {
            borderColor: hairline,
            "&:hover": { borderColor: isLight ? "rgba(10,15,26,0.22)" : "rgba(255,255,255,0.22)" },
          },
          sizeSmall: { fontWeight: 550 },
        },
      },
      MuiIconButton: {
        styleOverrides: {
          root: { transition: "background-color 120ms ease" },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: { fontWeight: 600, borderRadius: 6 },
          label: { paddingInline: 10 },
          sizeSmall: { height: 22, fontSize: "0.72rem" },
        },
      },
      MuiPaper: {
        defaultProps: { elevation: 0 },
        styleOverrides: {
          root: {
            backgroundImage: "none",
          },
          outlined: { borderColor: hairline },
        },
      },
      MuiCard: {
        defaultProps: { elevation: 0 },
        styleOverrides: {
          root: {
            border: `1px solid ${hairline}`,
            backgroundImage: "none",
          },
        },
      },
      MuiAppBar: {
        defaultProps: { elevation: 0 },
        styleOverrides: {
          root: {
            backgroundImage: "none",
            borderBottom: `1px solid ${hairline}`,
          },
        },
      },
      MuiDrawer: {
        styleOverrides: {
          paper: {
            backgroundImage: "none",
            borderRight: `1px solid ${hairline}`,
            backgroundColor: palette.background.paper,
          },
        },
      },
      MuiDivider: {
        styleOverrides: { root: { borderColor: hairline } },
      },
      MuiTableCell: {
        styleOverrides: {
          root: {
            borderBottom: `1px solid ${hairline}`,
            padding: "9px 14px",
          },
          head: {
            fontWeight: 650,
            fontSize: "0.72rem",
            letterSpacing: "0.04em",
            textTransform: "uppercase",
            color: palette.text.secondary,
            backgroundColor: isLight ? "#fbfbfc" : "#111720",
          },
        },
      },
      MuiTableRow: {
        styleOverrides: {
          root: {
            "&:last-child td": { borderBottom: "none" },
          },
        },
      },
      MuiTextField: {
        defaultProps: { fullWidth: true, size: "small" },
      },
      MuiFormControl: {
        defaultProps: { fullWidth: true, size: "small" },
      },
      MuiOutlinedInput: {
        styleOverrides: {
          root: {
            borderRadius: 8,
            transition: "border-color 120ms ease, box-shadow 120ms ease",
          },
          notchedOutline: { borderColor: hairline },
        },
      },
      MuiInputLabel: {
        styleOverrides: { root: { fontWeight: 550 } },
      },
      MuiStepper: {
        styleOverrides: {
          root: { backgroundColor: "transparent" },
        },
      },
      MuiStepLabel: {
        styleOverrides: {
          label: {
            fontWeight: 600,
            "&.Mui-active": { color: palette.text.primary, fontWeight: 650 },
            "&.Mui-completed": { color: palette.text.primary },
          },
          iconContainer: { paddingRight: 10 },
        },
      },
      MuiStepIcon: {
        styleOverrides: {
          root: {
            color: isLight ? "#d4d7dd" : "#2d3644",
            "&.Mui-active": { color: palette.primary.main },
            "&.Mui-completed": { color: palette.success.main },
          },
          text: { fontWeight: 700 },
        },
      },
      MuiStepConnector: {
        styleOverrides: {
          line: { borderColor: hairline },
        },
      },
      MuiDialog: {
        styleOverrides: {
          paper: {
            backgroundImage: "none",
            borderRadius: 12,
            border: `1px solid ${hairline}`,
          },
        },
      },
      MuiTooltip: {
        styleOverrides: {
          tooltip: {
            backgroundColor: isLight ? "#0a0f1a" : "#2d3644",
            fontSize: "0.72rem",
            fontWeight: 550,
          },
        },
      },
      MuiLinearProgress: {
        styleOverrides: {
          root: {
            borderRadius: 999,
            height: 6,
            backgroundColor: isLight ? "#eceef1" : "#1f2730",
          },
        },
      },
      MuiTab: {
        styleOverrides: {
          root: { textTransform: "none", fontWeight: 600 },
        },
      },
      MuiAlert: {
        styleOverrides: {
          root: { borderRadius: 8, fontWeight: 500 },
        },
      },
      MuiListItemButton: {
        styleOverrides: {
          root: {
            borderRadius: 8,
            transition: "background-color 120ms ease, color 120ms ease",
          },
        },
      },
    },
  });

  return theme;
}

export default buildTheme;
