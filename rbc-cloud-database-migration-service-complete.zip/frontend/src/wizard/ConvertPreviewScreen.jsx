import React, { useEffect, useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Alert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableBody from "@mui/material/TableBody";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import Chip from "@mui/material/Chip";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import ContentCopyRoundedIcon from "@mui/icons-material/ContentCopyRounded";

import api from "../api";

// ---------------------------------------------------------------------------
// ConvertPreviewScreen — wizard step shown only for cross-engine migrations.
// Purely informational: fetches a read-only schema-conversion preview from
// the backend so the user can see what will change before launch. Actual
// conversion runs at migration launch time, not here.
// ---------------------------------------------------------------------------
function DDLBlock({ ddl }) {
  const [copied, setCopied] = useState(false);
  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(ddl || "");
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable — ignore */
    }
  };
  return (
    <Box sx={{ position: "relative", mt: 1.5 }}>
      <Box
        component="pre"
        sx={{
          m: 0,
          p: 1.5,
          pr: 5,
          borderRadius: 1.5,
          bgcolor: "action.hover",
          fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
          fontSize: "0.75rem",
          lineHeight: 1.6,
          whiteSpace: "pre-wrap",
          wordBreak: "break-word",
          maxHeight: 260,
          overflow: "auto",
        }}
      >
        {ddl || "-- no DDL"}
      </Box>
      <Tooltip title={copied ? "Copied!" : "Copy DDL"}>
        <IconButton
          size="small"
          onClick={onCopy}
          sx={{ position: "absolute", top: 6, right: 6, bgcolor: "background.paper" }}
        >
          <ContentCopyRoundedIcon sx={{ fontSize: 16 }} />
        </IconButton>
      </Tooltip>
    </Box>
  );
}

export function ConvertPreviewScreen({ form }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [tables, setTables] = useState([]);

  const includedNames = useMemo(
    () => (form.tables ? form.tables.filter((t) => t.include).map((t) => t.name) : []),
    [form.tables]
  );
  const depKey = `${form.srcEpId || ""}|${form.tgtEngine || ""}|${includedNames.join(",")}`;

  useEffect(() => {
    let cancelled = false;
    if (!form.srcEpId || !form.tgtEngine) {
      setLoading(false);
      setError("");
      setTables([]);
      return undefined;
    }
    setLoading(true);
    setError("");
    api
      .conversionPreview(form.srcEpId, form.tgtEngine, includedNames)
      .then((resp) => {
        if (cancelled) return;
        setTables((resp && resp.tables) || []);
        setLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err.message || "Could not load conversion preview");
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [depKey]);

  return (
    <Box>
      <Typography variant="h6" sx={{ fontWeight: 650 }}>
        Schema conversion
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, mb: 2 }}>
        Your source and target use different database engines, so column types will be
        translated. Here's a preview of what will change — conversion itself runs when the
        migration launches.
      </Typography>

      {loading && (
        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ py: 3 }}>
          <CircularProgress size={18} />
          <Typography variant="body2" color="text.secondary">
            Analyzing tables for type changes…
          </Typography>
        </Stack>
      )}

      {!loading && error && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          <Typography variant="body2">{error}</Typography>
          <Typography variant="caption" color="text.secondary">
            You can continue — conversion runs at launch.
          </Typography>
        </Alert>
      )}

      {!loading && !error && tables.length === 0 && (
        <Alert severity="info">No tables selected to preview.</Alert>
      )}

      {!loading &&
        !error &&
        tables.map((t) => {
          const changedCount = (t.targetColumns || []).filter((c) => c.changed).length;
          return (
            <Accordion key={t.table} disableGutters sx={{ mb: 1 }}>
              <AccordionSummary expandIcon={<ExpandMoreRoundedIcon />}>
                <Stack direction="row" spacing={1.5} alignItems="center">
                  <Typography sx={{ fontWeight: 600 }}>{t.table}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    — {(t.targetColumns || []).length} columns, {changedCount} changed
                  </Typography>
                  {changedCount > 0 && (
                    <Chip size="small" color="warning" label={`${changedCount} changed`} />
                  )}
                </Stack>
              </AccordionSummary>
              <AccordionDetails>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Column</TableCell>
                      <TableCell>Source type</TableCell>
                      <TableCell>Target type</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {(t.targetColumns || []).map((c) => (
                      <TableRow
                        key={c.name}
                        sx={c.changed ? { bgcolor: "warning.lighter", "& td": { fontWeight: 600 } } : undefined}
                      >
                        <TableCell>{c.name}</TableCell>
                        <TableCell sx={{ fontFamily: "ui-monospace, monospace" }}>{c.sourceType}</TableCell>
                        <TableCell sx={{ fontFamily: "ui-monospace, monospace" }}>
                          {c.targetType}
                          {c.changed && (
                            <Chip
                              size="small"
                              label="changed"
                              color="warning"
                              variant="outlined"
                              sx={{ ml: 1, height: 18, fontSize: "0.65rem" }}
                            />
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <DDLBlock ddl={t.ddl} />
              </AccordionDetails>
            </Accordion>
          );
        })}
    </Box>
  );
}

export default ConvertPreviewScreen;
