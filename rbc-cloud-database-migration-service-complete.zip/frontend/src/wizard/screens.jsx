import React, { useMemo } from "react";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import ButtonBase from "@mui/material/ButtonBase";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Switch from "@mui/material/Switch";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import CircularProgress from "@mui/material/CircularProgress";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";

import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import CancelRoundedIcon from "@mui/icons-material/CancelRounded";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import StorageRoundedIcon from "@mui/icons-material/StorageRounded";
import BlockRoundedIcon from "@mui/icons-material/BlockRounded";

// ---------------------------------------------------------------------------
// Static reference data — mirrors Wizard.jsx exactly (kept local here so this
// file has no dependency on Wizard's internals beyond the props contract).
// ---------------------------------------------------------------------------
const ENGINES = [
  { id: "postgres", name: "PostgreSQL", kind: "Relational", ok: true },
  { id: "mariadb", name: "MariaDB", kind: "Relational", ok: true },
  { id: "mysql", name: "MySQL", kind: "Relational", ok: true },
  { id: "oracle", name: "Oracle", kind: "Relational", ok: false },
  { id: "sqlserver", name: "SQL Server", kind: "Relational", ok: false },
  { id: "mongodb", name: "MongoDB", kind: "Document", ok: false },
];
const fam = (e) => (e === "postgres" ? "pg" : "my");
const VAULTS = ["vault://orders-ro", "vault://shop-ro", "vault://analytics-rw", "vault://target-rw"];

/* =========================================================================
 * EngineScreen
 * props: { role: "source"|"target", selected, onSelect(id), otherEngine }
 * ========================================================================= */
export function EngineScreen({ role, selected, onSelect, otherEngine }) {
  const isTarget = role === "target";

  // Cross-engine / same-family hint — only shown on the target screen, once
  // both a source and a target engine are known (mirrors current app.js).
  const hint = useMemo(() => {
    if (!isTarget || !otherEngine || !selected) return null;
    return fam(otherEngine) === fam(selected)
      ? "Same engine family — the Schema conversion stage is skipped automatically."
      : "Cross-engine — Schema conversion will translate the schema, and an optional code refactoring step follows Settings.";
  }, [isTarget, otherEngine, selected]);
  return (
    <Box>
      <Typography variant="h5">{isTarget ? "Where is it going?" : "Where is your data coming from?"}</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.75 }}>
        Pick the {role} engine. One decision per screen — connection details come next.
      </Typography>

      {hint && (
        <Paper variant="outlined" sx={{ mt: 2, p: 1.5, borderRadius: 1.5, bgcolor: "action.hover" }}>
          <Typography variant="body2">{hint}</Typography>
        </Paper>
      )}

      <Stack spacing={1.25} sx={{ mt: 3 }}>
        {ENGINES.map((e) => {
          const isSel = selected === e.id;
          return (
            <ButtonBase
              key={e.id}
              disabled={!e.ok}
              onClick={() => onSelect(e.id)}
              sx={{
                display: "block",
                textAlign: "left",
                borderRadius: 1.5,
                transition: "120ms",
              }}
            >
              <Paper
                variant="outlined"
                sx={{
                  px: 2,
                  py: 1.5,
                  borderRadius: 1.5,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  borderColor: isSel ? "primary.main" : "divider",
                  bgcolor: isSel ? "action.selected" : "background.paper",
                  opacity: e.ok ? 1 : 0.55,
                  "&:hover": { bgcolor: e.ok ? "action.hover" : undefined },
                }}
              >
                <Stack direction="row" spacing={1.5} alignItems="center">
                  <StorageRoundedIcon fontSize="small" color={isSel ? "primary" : "action"} />
                  <Box>
                    <Typography variant="body1" sx={{ fontWeight: 600 }}>
                      {e.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {e.kind}
                    </Typography>
                  </Box>
                </Stack>

                {e.ok ? (
                  isSel && <Chip size="small" color="primary" label="Selected" icon={<CheckCircleRoundedIcon />} />
                ) : (
                  <Stack direction="row" spacing={0.5} alignItems="center" sx={{ color: "text.secondary" }}>
                    <BlockRoundedIcon fontSize="small" />
                    <Typography variant="caption">not in this build</Typography>
                  </Stack>
                )}
              </Paper>
            </ButtonBase>
          );
        })}
      </Stack>
    </Box>
  );
}

/* =========================================================================
 * ConnectionScreen
 * props: {
 *   role: "source"|"target", engine, endpoints, savedSel, setSavedSel(v),
 *   form: { host, port, database, user, credentialRef }, setForm(f),
 *   status, testing, tested, onTest()
 * }
 * ========================================================================= */
export function ConnectionScreen({
  role,
  engine,
  endpoints,
  savedSel,
  setSavedSel,
  form,
  setForm,
  status,
  testing,
  tested,
  onTest,
}) {
  const [showManual, setShowManual] = React.useState(false);
  const isSrc = role === "source";
  const saved = (endpoints || []).filter((e) => e.role === role && e.engine === engine);
  const usingSaved = !!savedSel;

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  return (
    <Box>
      <Typography variant="h5">{isSrc ? "Connect to the source" : "Connect to the target"}</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.75, maxWidth: 560 }}>
        We test {isSrc ? "read" : "write"} access on the {role}. Credentials are vault references — never
        shown back in plain text. Continue unlocks when the test passes.
      </Typography>

      <Stack spacing={2} sx={{ mt: 3, maxWidth: 480 }}>
        {saved.length > 0 && (
          <FormControl fullWidth size="small">
            <InputLabel id={`saved-${role}`}>Saved endpoints</InputLabel>
            <Select
              labelId={`saved-${role}`}
              label="Saved endpoints"
              value={savedSel}
              onChange={(e) => setSavedSel(e.target.value)}
            >
              <MenuItem value="">— create new —</MenuItem>
              {saved.map((e) => (
                <MenuItem key={e.id} value={e.id}>
                  {e.name} · {e.host}:{e.port}/{e.database}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        )}

        {form && !usingSaved && (saved.length === 0 || showManual) && (
          <Stack spacing={2}>
            <TextField label="Host" size="small" fullWidth value={form.host} onChange={update("host")} />
            <TextField
              label="Port"
              size="small"
              fullWidth
              type="number"
              value={form.port}
              onChange={update("port")}
            />
            <TextField label="Database" size="small" fullWidth value={form.database} onChange={update("database")} />
            <TextField label="User" size="small" fullWidth value={form.user} onChange={update("user")} />
            <FormControl fullWidth size="small">
              <InputLabel id={`cred-${role}`}>Credential reference</InputLabel>
              <Select
                labelId={`cred-${role}`}
                label="Credential reference"
                value={form.credentialRef}
                onChange={update("credentialRef")}
              >
                {VAULTS.map((v) => (
                  <MenuItem key={v} value={v}>
                    {v}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>
        )}

        {saved.length > 0 && !usingSaved && !showManual && (
          <Button
            variant="text"
            onClick={() => setShowManual(true)}
            sx={{ textTransform: "none", px: 0.5, justifyContent: "flex-start", width: "fit-content" }}
          >
            Or enter details manually
          </Button>
        )}

        <Stack direction="row" spacing={1.5} alignItems="center">
          <Button variant="contained" onClick={onTest} disabled={testing}>
            {testing ? "Testing…" : "Test connection"}
          </Button>
          {testing && <CircularProgress size={18} />}
          <Stack direction="row" spacing={0.75} alignItems="center">
            {tested && <CheckCircleRoundedIcon fontSize="small" color="success" />}
            {!tested && status && status.startsWith("Failed") && <CancelRoundedIcon fontSize="small" color="error" />}
            <Typography
              variant="body2"
              color={tested ? "success.main" : status && status.startsWith("Failed") ? "error.main" : "text.secondary"}
            >
              {status}
            </Typography>
          </Stack>
        </Stack>
      </Stack>
    </Box>
  );
}

/* =========================================================================
 * TablesScreen
 * props: { tables, loading, search, setSearch(v), onToggle(idx, val),
 *          onIncludeAll(), onExcludeAll() }
 * ========================================================================= */

export function TablesScreen({ tables, loading, search, setSearch, onToggle, onIncludeAll, onExcludeAll }) {
  if (!tables || loading) {
    return (
      <Box>
        <Typography variant="h5">Which tables should move?</Typography>
        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mt: 3 }}>
          <CircularProgress size={20} />
          <Typography variant="body2" color="text.secondary">
            Loading inventory from the source you just connected…
          </Typography>
        </Stack>
      </Box>
    );
  }

  const q = (search || "").toLowerCase();
  const visible = tables.filter((t) => t.name.toLowerCase().includes(q));
  const inc = tables.filter((t) => t.include);
  const bytes = inc.reduce((a, t) => a + (t.sizeBytes || 0), 0);

  return (
    <Box>
      <Typography variant="h5">Which tables should move?</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.75 }}>
        Inventoried from the connected source. Excluded tables are not created on the target.
      </Typography>

      <Stack direction="row" spacing={1.5} sx={{ mt: 2.5 }}>
        <TextField
          size="small"
          placeholder="Search tables…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          sx={{ maxWidth: 260 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
        />
        <Button size="small" onClick={onIncludeAll}>
          Include all
        </Button>
        <Button size="small" onClick={onExcludeAll}>
          Exclude all
        </Button>
      </Stack>

      <Stack spacing={1} sx={{ mt: 2 }}>
        {visible.map((t) => {
          const idx = tables.indexOf(t);
          return (
            <Paper
              key={t.name}
              variant="outlined"
              sx={{
                px: 2,
                py: 1.25,
                borderRadius: 1.5,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                opacity: t.include ? 1 : 0.6,
              }}
            >
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {t.name}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {(t.rows || 0).toLocaleString()} rows · {((t.sizeBytes || 0) / 1048576).toFixed(1)} MB · PK{" "}
                  {(t.primaryKey || []).join(", ") || "—"}
                </Typography>
              </Box>
              <ToggleButtonGroup
                size="small"
                exclusive
                value={t.include ? "inc" : "exc"}
                onChange={(e, v) => {
                  if (v) onToggle(idx, v === "inc");
                }}
              >
                <ToggleButton value="inc" color="success">
                  Include
                </ToggleButton>
                <ToggleButton value="exc" color="error">
                  Exclude
                </ToggleButton>
              </ToggleButtonGroup>
            </Paper>
          );
        })}
        {visible.length === 0 && (
          <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
            No tables match “{search}”.
          </Typography>
        )}
      </Stack>

      <Divider sx={{ my: 2.5 }} />
      <Typography variant="body2" color="text.secondary">
        {inc.length} of {tables.length} included · {tables.length - inc.length} excluded · ~
        {(bytes / 1073741824).toFixed(1)} GB to migrate
      </Typography>
    </Box>
  );
}

/* =========================================================================
 * NameScreen
 * props: { name, setName(v), includedCount, totalCount }
 * ========================================================================= */
export function NameScreen({ name, setName, includedCount, totalCount }) {
  return (
    <Box>
      <Typography variant="h5">Name this migration</Typography>
      <TextField
        sx={{ mt: 3, maxWidth: 480 }}
        fullWidth
        size="small"
        label="Migration name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        autoFocus
      />
      <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
        Tables carried forward: {includedCount} of {totalCount} included.
      </Typography>
    </Box>
  );
}

/* =========================================================================
 * SettingsScreen
 * props: { settings: { fullLoad, cdc, validate }, setSettings(s) }
 * ========================================================================= */
export function SettingsScreen({ settings, setSettings }) {
  const row = (title, sub, checked, onChange, disabled) => (
    <Paper
      variant="outlined"
      sx={{
        px: 2,
        py: 1.5,
        borderRadius: 1.5,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 2,
      }}
    >
      <Box>
        <Typography variant="body2" sx={{ fontWeight: 600 }}>
          {title}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {sub}
        </Typography>
      </Box>
      <Switch checked={checked} onChange={onChange} disabled={disabled} />
    </Paper>
  );

  return (
    <Box>
      <Typography variant="h5">Settings</Typography>
      <Stack spacing={1.5} sx={{ mt: 3, maxWidth: 560 }}>
        {row(
          "Initial full load",
          "Snapshot every included table before CDC starts",
          settings.fullLoad,
          (e) => setSettings({ ...settings, fullLoad: e.target.checked }),
          false
        )}
        {row(
          "Continuous replication (CDC)",
          "Stream changes via Debezium until cutover",
          settings.cdc,
          (e) => setSettings({ ...settings, cdc: e.target.checked }),
          false
        )}
        {row(
          "Validation gate",
          "Row counts + sampled row comparison. Cutover stays locked until it passes — always on.",
          true,
          () => {},
          true
        )}
      </Stack>
    </Box>
  );
}

/* =========================================================================
 * CodeScreen
 * props: { code: { enabled, repoUrl, consent }, setCode(c) }
 * ========================================================================= */
export function CodeScreen({ code, setCode }) {
  return (
    <Box>
      <Typography variant="h5">Application code refactoring</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.75, maxWidth: 560 }}>
        Cross-engine moves change SQL dialects. This optional track prepares refactoring pull requests
        against your repo — you review and merge; nothing is auto-applied.
      </Typography>

      <Paper
        variant="outlined"
        sx={{
          mt: 3,
          px: 2,
          py: 1.5,
          borderRadius: 1.5,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          maxWidth: 560,
        }}
      >
        <Typography variant="body2" sx={{ fontWeight: 600 }}>
          Enable code refactoring track
        </Typography>
        <Switch checked={code.enabled} onChange={(e) => setCode({ ...code, enabled: e.target.checked })} />
      </Paper>

      {code.enabled && (
        <Stack spacing={2} sx={{ mt: 2, maxWidth: 560 }}>
          <TextField
            label="Repository URL"
            size="small"
            fullWidth
            placeholder="https://github.com/your-org/your-app"
            value={code.repoUrl}
            onChange={(e) => setCode({ ...code, repoUrl: e.target.value })}
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={code.consent}
                onChange={(e) => setCode({ ...code, consent: e.target.checked })}
              />
            }
            label={
              <Typography variant="body2">
                I grant permission to open pull requests on this repository.
              </Typography>
            }
            sx={{ alignItems: "flex-start", ".MuiCheckbox-root": { pt: 0 } }}
          />
        </Stack>
      )}
    </Box>
  );
}

/* =========================================================================
 * ReviewScreen
 * props: { w, endpoints }
 *   w         — the full wizard state object from Wizard.jsx (freshState())
 *   endpoints — the saved-endpoints list, used to resolve src/tgt endpoint
 *               display details (host/port/database) from srcEpId/tgtEpId
 * ========================================================================= */
export function ReviewScreen({ w, endpoints }) {
  const tables = w.tables || [];
  const inc = tables.filter((t) => t.include);
  const exc = tables.filter((t) => !t.include);
  const src = (endpoints || []).find((e) => e.id === w.srcEpId);
  const tgt = (endpoints || []).find((e) => e.id === w.tgtEpId);
  const cross = w.srcEngine && w.tgtEngine && fam(w.srcEngine) !== fam(w.tgtEngine);

  const row = (label, value) => (
    <Stack direction="row" spacing={2} sx={{ py: 1.25 }}>
      <Typography variant="body2" color="text.secondary" sx={{ minWidth: 150 }}>
        {label}
      </Typography>
      <Typography variant="body2" sx={{ fontWeight: 500 }}>
        {value}
      </Typography>
    </Stack>
  );

  return (
    <Box>
      <Typography variant="h5">Review &amp; launch</Typography>

      <Paper variant="outlined" sx={{ mt: 3, px: 2.5, borderRadius: 1.5, maxWidth: 720 }}>
        {row("Migration", w.name)}
        <Divider />
        {row("Source", `${src?.engine || ""} · ${src?.host}:${src?.port} / ${src?.database} · test passed`)}
        <Divider />
        {row("Target", `${tgt?.engine || ""} · ${tgt?.host}:${tgt?.port} / ${tgt?.database} · test passed`)}
        <Divider />
        {row(
          "Tables",
          `${inc.length} included (${inc.map((t) => t.name).join(", ")})${
            exc.length ? ` · ${exc.length} excluded` : ""
          }`
        )}
        <Divider />
        {row(
          "Settings",
          `Full load ${w.settings.fullLoad ? "on" : "off"} · CDC ${w.settings.cdc ? "on" : "off"} · Validation gate on`
        )}
        {cross && (
          <>
            <Divider />
            {row(
              "Code refactoring",
              w.code.enabled ? `On — ${w.code.repoUrl} · reviewable PRs` : "Off"
            )}
          </>
        )}
      </Paper>

      <Typography variant="body2" color="text.secondary" sx={{ mt: 2.5, maxWidth: 720 }}>
        Launching runs Discover → {cross ? "Convert → " : ""}Replicate automatically. Validate stays a
        manual hard gate before Cutover.
      </Typography>
    </Box>
  );
}
