import React, { useCallback, useEffect, useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import ButtonBase from "@mui/material/ButtonBase";
import { alpha } from "@mui/material/styles";

import ArrowBackRoundedIcon from "@mui/icons-material/ArrowBackRounded";
import CheckIcon from "@mui/icons-material/Check";

import api from "../api";
import { ConvertPreviewScreen } from "./ConvertPreviewScreen";
import { useToast } from "../App";
import {
  EngineScreen,
  ConnectionScreen,
  TablesScreen,
  NameScreen,
  SettingsScreen,
  CodeScreen,
  ReviewScreen,
} from "./screens";

// ---------------------------------------------------------------------------
// Static reference data — mirrors the current wizard's defaults exactly.
// ---------------------------------------------------------------------------
const ENGINES = [
  { id: "postgres", name: "PostgreSQL", kind: "Relational", ok: true },
  { id: "mariadb", name: "MariaDB", kind: "Relational", ok: true },
  { id: "mysql", name: "MySQL", kind: "Relational", ok: true },
  { id: "oracle", name: "Oracle", kind: "Relational", ok: false },
  { id: "sqlserver", name: "SQL Server", kind: "Relational", ok: false },
  { id: "mongodb", name: "MongoDB", kind: "Document", ok: false },
];
const ENGINE_NAME = Object.fromEntries(ENGINES.map((e) => [e.id, e.name]));
const fam = (e) => (e === "postgres" ? "pg" : "my");

const DEF = {
  source: {
    postgres: { host: "localhost", port: 5432, database: "ordersdb", user: "dbz", credentialRef: "vault://orders-ro" },
    mariadb: { host: "localhost", port: 3306, database: "shop", user: "dbz", credentialRef: "vault://shop-ro" },
    mysql: { host: "localhost", port: 3306, database: "shop", user: "dbz", credentialRef: "vault://shop-ro" },
  },
  target: {
    postgres: { host: "localhost", port: 5432, database: "targetdb", user: "dbz", credentialRef: "vault://target-rw" },
    mariadb: { host: "localhost", port: 3306, database: "targetmy", user: "dbz", credentialRef: "vault://target-rw" },
    mysql: { host: "localhost", port: 3306, database: "targetmy", user: "dbz", credentialRef: "vault://target-rw" },
  },
};

function freshState() {
  return {
    step: 0,
    srcEngine: null,
    tgtEngine: null,
    srcEpId: null,
    tgtEpId: null,
    srcTested: false,
    tgtTested: false,
    srcForm: null,
    tgtForm: null,
    srcSavedSel: "",
    tgtSavedSel: "",
    srcStatus: "Not tested yet",
    tgtStatus: "Not tested yet",
    srcTesting: false,
    tgtTesting: false,
    tables: null,
    tablesLoading: false,
    tableSearch: "",
    name: "",
    settings: { fullLoad: true, cdc: true, validate: true },
    code: { enabled: false, repoUrl: "", consent: false },
  };
}

// ---------------------------------------------------------------------------
// CrumbMark — the small numbered circle / check-glyph used in the
// step rail for completed & current steps.
// ---------------------------------------------------------------------------
function CrumbMark({ state, index }) {
  if (state === "completed") {
    return (
      <Box
        sx={{
          width: 18,
          height: 18,
          borderRadius: "50%",
          bgcolor: "success.main",
          color: "common.white",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <CheckIcon sx={{ fontSize: 11 }} />
      </Box>
    );
  }
  if (state === "current") {
    return (
      <Box
        sx={{
          width: 18,
          height: 18,
          borderRadius: "50%",
          bgcolor: "primary.main",
          color: "common.white",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 11,
          fontWeight: 700,
          flexShrink: 0,
        }}
      >
        {index + 1}
      </Box>
    );
  }
  return (
    <Box
      sx={{
        width: 18,
        height: 18,
        borderRadius: "50%",
        border: "1px solid",
        borderColor: "divider",
        color: "text.disabled",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 11,
        fontWeight: 600,
        flexShrink: 0,
      }}
    >
      {index + 1}
    </Box>
  );
}

export default function Wizard({ endpoints, onEndpointsChanged, onExit, onLaunched }) {
  const notify = useToast();
  const [w, setW] = useState(freshState());
  const [localEndpoints, setLocalEndpoints] = useState(endpoints || []);
  const [launching, setLaunching] = useState(false);

  const patch = useCallback((fields) => setW((prev) => ({ ...prev, ...fields })), []);

  // Reset to a clean wizard on mount, and pull the saved endpoint list so
  // connection screens can offer "use a saved endpoint".
  useEffect(() => {
    setW(freshState());
    setLaunching(false);
    api
      .listEndpoints()
      .then((list) => {
        setLocalEndpoints(list);
        onEndpointsChanged && onEndpointsChanged(list);
      })
      .catch(() => setLocalEndpoints([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const cross = w.srcEngine && w.tgtEngine && fam(w.srcEngine) !== fam(w.tgtEngine);

  // ---- steps (labels mirror the current wizard's step rail) ----
  const steps = useMemo(() => {
    const arr = [
      { key: "srcEngine", label: "Source engine", sub: w.srcEngine ? ENGINE_NAME[w.srcEngine] : "Where data lives now" },
      { key: "srcConn", label: "Source connection", sub: w.srcTested ? "Connected · test passed" : "Host, database, credentials" },
      { key: "tables", label: "Tables", sub: w.tables ? `${w.tables.filter((t) => t.include).length} of ${w.tables.length} included` : "Choose what moves" },
      { key: "tgtEngine", label: "Target engine", sub: w.tgtEngine ? ENGINE_NAME[w.tgtEngine] : "Where data is going" },
      { key: "name", label: "Name", sub: w.name || "Name this migration" },
      { key: "tgtConn", label: "Target connection", sub: w.tgtTested ? "Connected · test passed" : "Host, database, credentials" },
      ...(cross ? [{ key: "convert", label: "Schema conversion", sub: "Preview type changes" }] : []),
      { key: "settings", label: "Settings", sub: "Full load + CDC" },
    ];
    if (cross) arr.push({ key: "code", label: "Code refactoring", sub: w.code.enabled ? "On — reviewable PRs" : "Optional" });
    arr.push({ key: "review", label: "Review & launch", sub: "Confirm & launch" });
    return arr;
  }, [w, cross]);

  const cur = steps[w.step];

  // Reset the dependent connection state whenever the engine choice for a
  // role changes — a new engine means a new default form and a fresh test.
  useEffect(() => {
    if (w.srcEngine) {
      setW((prev) => ({
        ...prev,
        srcForm: { ...(DEF.source[prev.srcEngine] || DEF.source.postgres) },
        srcTested: false,
        srcEpId: null,
        srcStatus: "Not tested yet",
        srcSavedSel: "",
        tables: null,
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [w.srcEngine]);

  useEffect(() => {
    if (w.tgtEngine) {
      setW((prev) => ({
        ...prev,
        tgtForm: { ...(DEF.target[prev.tgtEngine] || DEF.target.postgres) },
        tgtTested: false,
        tgtEpId: null,
        tgtStatus: "Not tested yet",
        tgtSavedSel: "",
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [w.tgtEngine]);

  // Prefill the name once both engines are known, only if still blank.
  useEffect(() => {
    if (cur?.key === "name" && !w.name && w.srcEngine && w.tgtEngine) {
      patch({ name: `${ENGINE_NAME[w.srcEngine]} → ${ENGINE_NAME[w.tgtEngine]}` });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cur?.key]);

  // Load the table inventory once the source connection has passed its test.
  useEffect(() => {
    if (cur?.key === "tables" && w.tables === null && w.srcEpId && !w.tablesLoading) {
      patch({ tablesLoading: true });
      api
        .listTables(w.srcEpId)
        .then((rows) => patch({ tables: rows.map((t) => ({ ...t, include: true })), tablesLoading: false }))
        .catch((err) => {
          notify("Could not list tables — " + err.message, "error");
          patch({ tablesLoading: false });
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cur?.key, w.srcEpId, w.tables]);

  // ---- gating: Continue is disabled until the current screen's rule passes ----
  const canContinue = (() => {
    switch (cur?.key) {
      case "srcEngine":
        return !!w.srcEngine;
      case "srcConn":
        return w.srcTested;
      case "tables":
        return !!w.tables && w.tables.some((t) => t.include);
      case "tgtEngine":
        return !!w.tgtEngine;
      case "name":
        return w.name.trim().length > 1;
      case "tgtConn":
        return w.tgtTested;
      case "convert":
        return true;
      case "settings":
        return true;
      case "code":
        return !w.code.enabled || (w.code.repoUrl.trim().length > 0 && w.code.consent);
      case "review":
        return true;
      default:
        return false;
    }
  })();

  const goBack = () => patch({ step: Math.max(0, w.step - 1) });

  const testConnection = async (role) => {
    const isSrc = role === "source";
    const engine = isSrc ? w.srcEngine : w.tgtEngine;
    const savedSel = isSrc ? w.srcSavedSel : w.tgtSavedSel;
    const form = isSrc ? w.srcForm : w.tgtForm;
    const setTesting = (v) => patch(isSrc ? { srcTesting: v } : { tgtTesting: v });
    const setStatus = (v) => patch(isSrc ? { srcStatus: v } : { tgtStatus: v });

    setTesting(true);
    try {
      let epId = savedSel || null;
      if (!epId) {
        const ep = await api.createEndpoint({
          name: `${ENGINE_NAME[engine]} — ${role} (${form.database})`,
          role,
          engine,
          host: form.host,
          port: Number(form.port),
          database: form.database,
          user: form.user,
          credentialRef: form.credentialRef,
          sslMode: "disable",
        });
        epId = ep.id;
        setLocalEndpoints((prev) => {
          const next = [...prev, ep];
          onEndpointsChanged && onEndpointsChanged(next);
          return next;
        });
      }
      setStatus("Testing…");
      const r = await api.testEndpoint(epId);
      if (r.ok) {
        setStatus(`Connected — ${r.latencyMs} ms · ${r.version}`);
        if (isSrc) patch({ srcEpId: epId, srcTested: true, tables: null });
        else patch({ tgtEpId: epId, tgtTested: true });
      } else {
        setStatus("Failed — " + (r.error || "test failed"));
        patch(isSrc ? { srcTested: false } : { tgtTested: false });
      }
    } catch (err) {
      setStatus("Failed — " + err.message);
      patch(isSrc ? { srcTested: false } : { tgtTested: false });
    } finally {
      setTesting(false);
    }
  };

  const launch = async () => {
    setLaunching(true);
    try {
      const mig = await api.createMigration({
        name: w.name,
        sourceEndpointId: w.srcEpId,
        targetEndpointId: w.tgtEpId,
        tables: w.tables.map((t) => ({ name: t.name, include: t.include, primaryKey: t.primaryKey, rows: t.rows })),
        settings: w.settings,
        codeRefactoring: { enabled: w.code.enabled, repoUrl: w.code.repoUrl, prConsent: w.code.consent },
      });
      notify("Migration created — running Discover" + (cross ? " → Convert" : "") + " → Replicate…", "success");
      await api.runAll(mig.id);
      onLaunched(mig.id);
    } catch (err) {
      notify("Launch failed — " + err.message, "error");
    } finally {
      setLaunching(false);
    }
  };

  const handleContinue = () => {
    if (cur.key === "review") {
      launch();
      return;
    }
    patch({ step: w.step + 1 });
  };

  return (
    <Box>
      {/* ---------------- page head ---------------- */}
      <Box sx={{ px: 3, pt: 3, pb: 2, display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <Stack direction="row" spacing={1.5} alignItems="flex-start">
          <IconButton onClick={onExit} aria-label="Back to dashboard" size="small" sx={{ mt: 0.25 }}>
            <ArrowBackRoundedIcon fontSize="small" />
          </IconButton>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 650 }}>
              New migration
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.25 }}>
              Guided setup. You can pause anytime — checkpoints are saved.
            </Typography>
          </Box>
        </Stack>
        <Button onClick={onExit}>Cancel</Button>
      </Box>

      {/* ---------------- body: left rail + right content ---------------- */}
      <Box sx={{ display: "flex", alignItems: "flex-start" }}>
        {/* ---------------- left vertical rail ---------------- */}
        <Box
          sx={{
            width: 264,
            flexShrink: 0,
            borderRight: 1,
            borderColor: "divider",
            py: 2.5,
            px: 2,
          }}
        >
          {steps.map((s, index) => {
            const state = index < w.step ? "completed" : index === w.step ? "current" : "upcoming";
            const isLast = index === steps.length - 1;

            const markColumn = (
              <Box
                sx={{
                  width: 18,
                  mr: "10px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  flexShrink: 0,
                }}
              >
                <CrumbMark state={state} index={index} />
                {!isLast && (
                  <Box
                    sx={{
                      flex: 1,
                      width: "1px",
                      bgcolor: "divider",
                      my: 0.5,
                    }}
                  />
                )}
              </Box>
            );

            const textColumn = (
              <Box sx={{ minWidth: 0, flex: 1 }}>
                <Typography
                  className="crumb-label"
                  noWrap
                  sx={{
                    fontSize: "0.8125rem",
                    fontWeight: state === "completed" ? 550 : state === "current" ? 700 : 400,
                    color:
                      state === "completed"
                        ? "text.primary"
                        : state === "current"
                        ? "primary.main"
                        : "text.disabled",
                  }}
                >
                  {s.label}
                </Typography>
                <Typography
                  noWrap
                  variant="caption"
                  sx={{
                    display: "block",
                    color: state === "upcoming" ? "text.disabled" : "text.secondary",
                    mt: 0.125,
                  }}
                >
                  {s.sub}
                </Typography>
              </Box>
            );

            if (state === "completed") {
              return (
                <ButtonBase
                  key={s.key}
                  onClick={() => patch({ step: index })}
                  sx={{
                    display: "flex",
                    alignItems: "stretch",
                    width: "100%",
                    textAlign: "left",
                    borderRadius: 1,
                    py: 1,
                    px: 1,
                    "&:hover .crumb-label": { textDecoration: "underline" },
                  }}
                >
                  {markColumn}
                  {textColumn}
                </ButtonBase>
              );
            }

            return (
              <Box
                key={s.key}
                aria-current={state === "current" ? "step" : undefined}
                sx={{
                  display: "flex",
                  alignItems: "stretch",
                  width: "100%",
                  py: 1,
                  px: 1,
                  borderRadius: state === "current" ? 2 : 0,
                  bgcolor: state === "current" ? (theme) => alpha(theme.palette.primary.main, 0.06) : "transparent",
                }}
              >
                {markColumn}
                {textColumn}
              </Box>
            );
          })}

          {w.srcEngine && w.tgtEngine && (
            <Typography
              variant="caption"
              color="text.secondary"
              sx={{ display: "block", mt: 2, px: 1 }}
            >
              {cross
                ? `${steps.length} steps · includes schema conversion${
                    steps.some((s) => s.key === "code") ? " and code refactoring" : ""
                  }`
                : `${steps.length} steps · same engine family — no conversion step`}
            </Typography>
          )}
        </Box>

        {/* ---------------- right content column ---------------- */}
        <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
          {/* ---------------- screen content ---------------- */}
          <Box sx={{ px: 3, flexGrow: 1 }}>
            <Box sx={{ maxWidth: 680, mx: "auto", py: 3 }}>
              {cur.key === "srcEngine" && (
                <EngineScreen
                  role="source"
                  selected={w.srcEngine}
                  onSelect={(id) => patch({ srcEngine: id })}
                  otherEngine={w.tgtEngine}
                />
              )}

              {cur.key === "srcConn" && (
                <ConnectionScreen
                  role="source"
                  engine={w.srcEngine}
                  endpoints={localEndpoints}
                  savedSel={w.srcSavedSel}
                  setSavedSel={(v) => patch({ srcSavedSel: v, srcTested: false, srcStatus: "Not tested yet" })}
                  form={w.srcForm}
                  setForm={(f) => patch({ srcForm: f, srcTested: false, srcStatus: "Changed — test again" })}
                  status={w.srcStatus}
                  testing={w.srcTesting}
                  tested={w.srcTested}
                  onTest={() => testConnection("source")}
                />
              )}

              {cur.key === "tables" && (
                <TablesScreen
                  tables={w.tables}
                  loading={w.tablesLoading}
                  search={w.tableSearch}
                  setSearch={(v) => patch({ tableSearch: v })}
                  onToggle={(idx, val) =>
                    patch({ tables: w.tables.map((t, i) => (i === idx ? { ...t, include: val } : t)) })
                  }
                  onIncludeAll={() => patch({ tables: w.tables.map((t) => ({ ...t, include: true })) })}
                  onExcludeAll={() => patch({ tables: w.tables.map((t) => ({ ...t, include: false })) })}
                />
              )}

              {cur.key === "tgtEngine" && (
                <EngineScreen
                  role="target"
                  selected={w.tgtEngine}
                  onSelect={(id) => patch({ tgtEngine: id })}
                  otherEngine={w.srcEngine}
                />
              )}

              {cur.key === "name" && (
                <NameScreen
                  name={w.name}
                  setName={(v) => patch({ name: v })}
                  includedCount={w.tables ? w.tables.filter((t) => t.include).length : 0}
                  totalCount={w.tables ? w.tables.length : 0}
                />
              )}

              {cur.key === "tgtConn" && (
                <ConnectionScreen
                  role="target"
                  engine={w.tgtEngine}
                  endpoints={localEndpoints}
                  savedSel={w.tgtSavedSel}
                  setSavedSel={(v) => patch({ tgtSavedSel: v, tgtTested: false, tgtStatus: "Not tested yet" })}
                  form={w.tgtForm}
                  setForm={(f) => patch({ tgtForm: f, tgtTested: false, tgtStatus: "Changed — test again" })}
                  status={w.tgtStatus}
                  testing={w.tgtTesting}
                  tested={w.tgtTested}
                  onTest={() => testConnection("target")}
                />
              )}

              {cur.key === "convert" && <ConvertPreviewScreen form={w} />}

              {cur.key === "settings" && (
                <SettingsScreen settings={w.settings} setSettings={(s) => patch({ settings: s })} />
              )}

              {cur.key === "code" && (
                <CodeScreen code={w.code} setCode={(c) => patch({ code: c })} />
              )}

              {cur.key === "review" && <ReviewScreen w={w} endpoints={localEndpoints} />}
            </Box>
          </Box>

          {/* ---------------- footer action bar ---------------- */}
          <Box
            sx={{
              position: "sticky",
              bottom: 0,
              bgcolor: "background.default",
              borderTop: 1,
              borderColor: "divider",
              py: 2,
              mt: 2,
              px: 3,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Button onClick={goBack} disabled={w.step === 0} sx={{ visibility: w.step === 0 ? "hidden" : "visible" }}>
              Back
            </Button>

            <Typography variant="body2" color="text.secondary">
              Step {w.step + 1} of {steps.length}
            </Typography>

            {cur.key === "review" ? (
              <Button variant="contained" onClick={launch} disabled={launching}>
                {launching ? "Launching…" : "Launch migration"}
              </Button>
            ) : (
              <Button variant="contained" onClick={handleContinue} disabled={!canContinue}>
                Continue →
              </Button>
            )}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
