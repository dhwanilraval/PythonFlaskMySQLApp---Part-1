// errorText.js
// Pure helper functions that translate raw backend/engine error strings
// into plain, user-friendly language. No JSX, no React imports — safe to
// use anywhere (UI components, logging, tests, etc.).

const RULES = [
  [
    /relation\s+"?([\w.]+)"?\s+does not exist/i,
    (match) =>
      `The target table "${match[1]}" doesn't exist — the target wasn't prepared for this table.`,
  ],
  [
    /duplicate key|unique constraint|duplicate entry/i,
    () => "A row with the same key already exists on the target.",
  ],
  [
    /connection refused|could not connect|econnrefused/i,
    () =>
      "Can't reach the database — check it's running and the connection details are right.",
  ],
  [
    /password authentication failed|access denied/i,
    () => "The database rejected the login — check the credential reference.",
  ],
  [
    /replication slot|\bWAL\b|binlog/i,
    () =>
      "Change capture isn't available on the source — its replication settings need attention.",
  ],
];

export function rawErrorText(input) {
  if (typeof input === "string") return input;
  if (input instanceof Error) return input.message;
  return String(input ?? "");
}

export function friendlyError(input) {
  const raw = rawErrorText(input);

  for (const [pattern, format] of RULES) {
    const match = raw.match(pattern);
    if (match) {
      return format(match);
    }
  }

  const trimmed = raw.trim();
  if (trimmed.length > 140) {
    return `${trimmed.slice(0, 139)}…`;
  }
  return trimmed;
}
