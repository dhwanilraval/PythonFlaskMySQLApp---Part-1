import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
STATE_FILE = os.path.join(DATA_DIR, "state.json")

CONNECT_URL = os.environ.get("CONNECT_URL", "http://127.0.0.1:8083")
KAFKA_BOOTSTRAP = os.environ.get("KAFKA_BOOTSTRAP", "127.0.0.1:9092")
PORT = int(os.environ.get("PORT", "5000"))

# Passwords for the local demo databases live in env, never in state.json.
# state.json stores only a credentialRef like "vault://orders-ro"; the vault
# is this local map for the prototype.
LOCAL_VAULT = {
    "vault://orders-ro": os.environ.get("PW_ORDERS_RO", "dbz"),
    "vault://analytics-rw": os.environ.get("PW_ANALYTICS_RW", "dbz"),
    "vault://shop-ro": os.environ.get("PW_SHOP_RO", "dbz"),
    "vault://target-rw": os.environ.get("PW_TARGET_RW", "dbz"),
}


def vault_password(credential_ref: str) -> str:
    return LOCAL_VAULT.get(credential_ref, "dbz")
