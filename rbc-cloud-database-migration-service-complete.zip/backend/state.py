"""Tiny JSON-file state store. One process, one lock — enough for the
prototype and honest about it (a real deployment moves this to Postgres)."""
import json
import os
import threading

import config

_lock = threading.RLock()
_state = None


def _defaults():
    return {"endpoints": [], "migrations": [], "settings": {}}


def _load():
    global _state
    if _state is None:
        if os.path.exists(config.STATE_FILE):
            with open(config.STATE_FILE) as f:
                _state = json.load(f)
            # Backfill keys for state files written before they existed, so
            # older state.json files keep working untouched.
            for k, v in _defaults().items():
                _state.setdefault(k, v)
        else:
            _state = _defaults()
    return _state


def _save():
    os.makedirs(config.DATA_DIR, exist_ok=True)
    tmp = config.STATE_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(_state, f, indent=2, default=str)
    os.replace(tmp, config.STATE_FILE)


def get_state():
    with _lock:
        return _load()


def mutate(fn):
    """Run fn(state) under the lock and persist."""
    with _lock:
        s = _load()
        out = fn(s)
        _save()
        return out


def find_endpoint(state, ep_id):
    return next((e for e in state["endpoints"] if e["id"] == ep_id), None)


def find_migration(state, mig_id):
    return next((m for m in state["migrations"] if m["id"] == mig_id), None)
