"""Migration orchestration: the five stages (Discover -> Convert -> Replicate
-> Validate -> Cutover) plus the parallel code-refactoring track for
cross-engine pairs. Validation is a hard gate: cutover refuses to run unless
the last validation passed.
"""
import datetime as dt
import hashlib
import threading

import config
import state as state_mod
from services import connect_client, consumer, db_probe, devin_client, engine_settings, schema_translate

_appliers = {}
_lock = threading.Lock()

PG = {"postgres", "postgresql"}

STAGE_ORDER = ["discover", "convert", "replicate", "validate", "cutover"]


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _event(mig, stage, msg):
    mig.setdefault("events", []).insert(0, {"ts": _now(), "stage": stage, "msg": msg})
    mig["events"] = mig["events"][:200]


def _get(mig_id):
    s = state_mod.get_state()
    mig = state_mod.find_migration(s, mig_id)
    if not mig:
        raise KeyError(f"migration {mig_id} not found")
    src = state_mod.find_endpoint(s, mig["sourceEndpointId"])
    tgt = state_mod.find_endpoint(s, mig["targetEndpointId"])
    return mig, src, tgt


def _update(mig_id, fn):
    def apply(s):
        mig = state_mod.find_migration(s, mig_id)
        if mig:
            fn(mig)
        return mig
    return state_mod.mutate(apply)


def homogeneous(mig):
    src_fam = "pg" if mig["sourceEngine"] in PG else "my"
    tgt_fam = "pg" if mig["targetEngine"] in PG else "my"
    return src_fam == tgt_fam


# --------------------------------------------------------------------- stages
def run_stage(mig_id, stage):
    if stage not in STAGE_ORDER:
        raise ValueError(f"unknown stage: {stage}")

    mig, _src, _tgt = _get(mig_id)

    if mig.get("status") == "completed":
        raise ValueError("migration is completed — its stages are locked")

    if stage == "cutover":
        validation = mig.get("validation")
        if not validation or not validation.get("passed"):
            raise ValueError("validation has not passed")

    def mark_running(m):
        m.setdefault("stages", {})[stage] = "running"

    mig = _update(mig_id, mark_running)

    fn = {
        "discover": _discover,
        "convert": _convert,
        "replicate": _replicate,
        "validate": _validate,
        "cutover": _cutover,
    }[stage]

    t = threading.Thread(target=_run_stage_safe, args=(mig_id, stage, fn), daemon=True)
    t.start()
    return mig


def _run_stage_safe(mig_id, stage, fn):
    try:
        fn(mig_id)
    except Exception as e:
        def work(m):
            m.setdefault("stages", {})[stage] = "failed"
            _event(m, stage, f"{stage} failed: {e}")
        try:
            _update(mig_id, work)
        except Exception:
            pass


def _discover(mig_id):
    mig, src, _tgt = _get(mig_id)
    inventory = db_probe.list_tables(src)

    def work(m):
        existing_includes = {t["name"]: t.get("include", True) for t in (m.get("tables") or [])}
        tables = []
        for t in inventory:
            tables.append({
                "name": t["name"],
                "rows": t["rows"],
                "sizeMb": round((t.get("sizeBytes") or 0) / (1024 * 1024), 2),
                "primaryKey": t.get("primaryKey") or [],
                "include": existing_includes.get(t["name"], True),
            })
        m["tables"] = tables
        m.setdefault("stages", {})["discover"] = "done"
        _event(m, "discover", f"Discovered {len(tables)} tables")

    _update(mig_id, work)


def _build_code_track_items(conversion):
    """Deterministic review items derived from the conversion report: one per
    column whose type actually changed, capped at 8 items."""
    items = []
    for t in conversion.get("tables", []):
        table = t["table"]
        src_cols = {c["name"]: c.get("type") for c in t.get("sourceColumns", [])}
        tgt_cols = {c["name"]: c.get("type") for c in t.get("targetColumns", [])}
        for name, src_type in src_cols.items():
            tgt_type = tgt_cols.get(name)
            if tgt_type is not None and tgt_type != src_type:
                items.append({
                    "id": f"ct-{len(items) + 1}",
                    "kind": "type-change",
                    "title": f"{table}.{name}",
                    "detail": (f"Type changed {src_type} -> {tgt_type}; review queries, "
                               f"casts and ORM mappings for this column."),
                    "status": "pending",
                    "file": f"src/db/{table}.ts",
                    "before": f"CAST({name} AS {src_type})",
                    "after": f"CAST({name} AS {tgt_type})",
                })
                if len(items) >= 8:
                    return items
    return items


def _raw_source_type(src, col):
    """Build a human-readable raw source type string from a db_probe column
    dict (shape depends on engine)."""
    if src["engine"] in PG:
        base = col.get("dataType")
        clen = col.get("length")
        prec = col.get("precision")
        scale = col.get("scale")
        if clen is not None:
            return f"{base}({clen})"
        if prec is not None and scale is not None:
            return f"{base}({prec},{scale})"
        if prec is not None:
            return f"{base}({prec})"
        return base
    return col.get("columnType") or col.get("dataType")


def _convert(mig_id):
    mig, src, tgt = _get(mig_id)

    if homogeneous(mig):
        def work(m):
            m.setdefault("stages", {})["convert"] = "skipped"
            _event(m, "convert", "Schema conversion skipped — same engine family")
        _update(mig_id, work)
        return

    included = [t["name"] for t in mig.get("tables", []) if t.get("include")]

    ddl_map = schema_translate.apply_schema(src, tgt, included)

    conversion_tables = []
    for t in included:
        raw_cols = db_probe.get_columns(src, t)
        source_cols = [{"name": c["name"], "type": _raw_source_type(src, c)} for c in raw_cols]

        translated = schema_translate.translate_columns(src, tgt["engine"], t)
        target_cols = [{"name": c.get("name"), "type": c.get("type")} for c in translated]

        conversion_tables.append({
            "table": t,
            "sourceColumns": source_cols,
            "targetColumns": target_cols,
            "ddl": ddl_map.get(t),
        })

    conversion = {"generatedAt": _now(), "tables": conversion_tables}

    def work(m):
        m["convertedDdl"] = ddl_map
        m["conversion"] = conversion
        m.setdefault("stages", {})["convert"] = "done"
        _event(m, "convert", f"Converted {len(conversion_tables)} tables")

        if (m.get("codeRefactoring") or {}).get("enabled"):
            items = _build_code_track_items(conversion)
            m["codeTrack"] = {
                "repo": m["codeRefactoring"]["repoUrl"],
                "status": "active",
                "steps": [
                    {"name": "Scan repo", "status": "done"},
                    {"name": "Generate PRs", "status": "done"},
                    {"name": "You review & merge", "status": "waiting"},
                    {"name": "Verify", "status": "pending"},
                ],
                "items": items,
                "summary": {"total": len(items), "approved": 0},
            }

    _update(mig_id, work)

    mig2, _s2, _t2 = _get(mig_id)
    if mig2.get("codeTrack"):
        ensure_devin_session(mig_id)


def _server_id(mig_id):
    h = hashlib.sha256(mig_id.encode()).hexdigest()
    return int(h[:8], 16) % 100000 + 1


def _build_connector_config(mig, src, included):
    engine = engine_settings.get_engine()
    is_pg = src["engine"] in PG
    password = config.vault_password(src["credentialRef"])

    cfg = {
        "connector.class": ("io.debezium.connector.postgresql.PostgresConnector" if is_pg
                             else "io.debezium.connector.mysql.MySqlConnector"),
        "database.hostname": src["host"],
        "database.port": str(src["port"]),
        "database.user": src["user"],
        "database.password": password,
        "database.dbname": src["database"],
        "topic.prefix": mig["id"],
        "snapshot.mode": "initial",
        "decimal.handling.mode": "double",
    }

    if is_pg:
        cfg["plugin.name"] = "pgoutput"
        cfg["time.precision.mode"] = "adaptive"
        cfg["table.include.list"] = ",".join(f"public.{t}" for t in included)
    else:
        cfg["database.server.id"] = str(_server_id(mig["id"]))
        cfg["database.connectionTimeZone"] = "UTC"
        cfg["time.precision.mode"] = "adaptive_time_microseconds"
        cfg["table.include.list"] = ",".join(f"{src['database']}.{t}" for t in included)
        cfg["schema.history.internal.kafka.bootstrap.servers"] = engine["kafkaBootstrap"]
        cfg["schema.history.internal.kafka.topic"] = f"schema-changes.{mig['id']}"

    return cfg


def _replicate(mig_id):
    mig, src, tgt = _get(mig_id)
    included = [t["name"] for t in mig["tables"] if t["include"]]

    def start_prep(m):
        m["status"] = "replicating"
        m.setdefault("stages", {})["replicate"] = "running"
        m["progress"] = {
            "eventsApplied": 0,
            "snapshotComplete": False,
            "lastEventAt": None,
            "perTable": {},
            "phase": "preparing",
            "targetTables": len(included),
            "recentChanges": [],
        }
        _event(m, "replicate", "Preparing target — creating tables and indexes")

    _update(mig_id, start_prep)

    prep_failed = False
    try:
        schema_translate.apply_schema(src, tgt, included)
    except Exception as err:
        prep_failed = True

        def on_fail(m):
            m.setdefault("stages", {})["replicate"] = "failed"
            m.setdefault("progress", {})["phase"] = "failed"
            _event(m, "replicate", f"Target preparation failed — {err}")

        _update(mig_id, on_fail)
        return

    def on_prep_done(m):
        _event(m, "replicate", f"Target ready — {len(included)} tables prepared")

    _update(mig_id, on_prep_done)

    cfg = _build_connector_config(mig, src, included)
    connect_client.create_or_update(mig["id"], cfg)

    snapshot_done_flag = {"done": False}

    def on_progress(stats):
        def work(m):
            m["progress"] = {
                "eventsApplied": stats["eventsApplied"],
                "snapshotComplete": stats["snapshotComplete"],
                "lastEventAt": stats["lastEventAt"],
                "perTable": stats["perTable"],
                "phase": "failed" if stats.get("error") else (
                    "streaming" if stats["snapshotComplete"] else "loading"
                ),
                "recentChanges": list(stats.get("recentChanges", [])),
            }
            if stats["snapshotComplete"] and not snapshot_done_flag["done"]:
                snapshot_done_flag["done"] = True
                _event(m, "replicate", "Snapshot complete — live change streaming")
            if stats.get("error"):
                m.setdefault("stages", {})["replicate"] = "failed"
                _event(m, "replicate", f"Replication error: {stats['error']}")
        _update(mig_id, work)

    applier = consumer.Applier(mig, src, tgt, on_progress)
    with _lock:
        _appliers[mig_id] = applier
    applier.start()

    if not prep_failed:
        def on_loading(m):
            if m.get("progress", {}).get("phase") == "preparing":
                m["progress"]["phase"] = "loading"

        _update(mig_id, on_loading)


def _validate(mig_id):
    mig, src, tgt = _get(mig_id)
    included = [t["name"] for t in mig["tables"] if t["include"]]

    tables = {}
    for t in included:
        source_rows = db_probe.row_count(src, t)
        target_rows = db_probe.row_count(tgt, t)
        tables[t] = {
            "sourceRows": source_rows,
            "targetRows": target_rows,
            "match": source_rows == target_rows,
        }

    passed = all(v["match"] for v in tables.values())

    def work(m):
        m["validation"] = {"passed": passed, "checkedAt": _now(), "tables": tables}
        m.setdefault("stages", {})["validate"] = "done" if passed else "failed"
        if passed:
            m["status"] = "ready"
        if passed:
            _event(m, "validate", f"Validation passed — {len(tables)} tables match")
        else:
            mismatched = [name for name, v in tables.items() if not v["match"]]
            _event(m, "validate", f"Validation failed — mismatched tables: {', '.join(mismatched)}")

    _update(mig_id, work)


def _cutover(mig_id):
    teardown_errors = []
    try:
        connect_client.pause(mig_id)
    except Exception as e:
        teardown_errors.append(str(e))
    try:
        connect_client.delete(mig_id)
    except Exception as e:
        teardown_errors.append(str(e))

    with _lock:
        applier = _appliers.get(mig_id)
    if applier:
        applier.stop_event.set()

    def work(m):
        stages = m.setdefault("stages", {})
        if stages.get("replicate") == "running":
            stages["replicate"] = "done"
        if teardown_errors:
            _event(m, "cutover", f"Cutover warning — connector cleanup failed: {teardown_errors[0]}")
        stages["cutover"] = "done"
        m["status"] = "completed"
        m["completedAt"] = _now()
        _event(m, "cutover", "Cutover complete — target is now primary")

    _update(mig_id, work)


def stop_migration(mig_id):
    with _lock:
        applier = _appliers.pop(mig_id, None)
    if applier:
        applier.stop_event.set()
    try:
        connect_client.pause(mig_id)
    except Exception:
        pass


def build_refactor_prompt(mig):
    ct = mig.get("codeTrack") or {}
    repo = (
        mig.get("codeRefactoring", {}).get("repoUrl")
        or (mig.get("codeTrack") or {}).get("repo")
        or "(no repository configured)"
    )
    lines = [
        f"Repository: {repo}",
        f"Database migration: {mig.get('sourceEngine')} -> {mig.get('targetEngine')}. "
        f"Column types changed as follows:",
    ]
    conversion = mig.get("conversion") or {}
    for t in conversion.get("tables", []):
        table = t.get("table")
        src_cols = {c.get("name"): c.get("sourceType", c.get("type")) for c in t.get("sourceColumns", [])}
        tgt_cols = {c.get("name"): c.get("targetType", c.get("type")) for c in t.get("targetColumns", [])}
        for name, tgt_type in tgt_cols.items():
            src_type = src_cols.get(name)
            if tgt_type != src_type:
                lines.append(f"- {table}.{name}: {src_type} -> {tgt_type}")
    lines.append(
        "Update the application code for these type changes (SQL queries, casts, ORM models and "
        "serializers), keep behavior otherwise identical, run the existing tests, "
        "and open a pull request with the changes."
    )
    return "\n".join(lines)


def ensure_devin_session(mig_id):
    try:
        mig, _s, _t = _get(mig_id)
        ct = mig.get("codeTrack")
        if not ct:
            return None
        existing = ct.get("devin") or {}
        if existing.get("sessionId"):
            return existing

        try:
            result = devin_client.create_session(build_refactor_prompt(mig))
        except Exception as e:
            result = {
                "sessionId": None,
                "mode": "stub" if not devin_client.configured() else "live",
                "status": "error",
                "url": None,
                "prUrl": None,
                "detail": str(e),
            }

        devin = {**result, "createdAt": _now()}

        def work(m):
            m["codeTrack"]["devin"] = devin
            if devin.get("status") != "error":
                _event(m, "code", f"Devin session started ({devin['mode']} mode)")

        _update(mig_id, work)
        return devin
    except Exception:
        return None
