"""CDC applier: consumes Debezium topics for one migration and applies the
change events to the target database.

Debezium emits the initial snapshot through the same topics (op='r'), then
live inserts/updates/deletes (op='c'/'u'/'d'). The applier upserts/deletes by
primary key, converts Debezium's Connect-mode temporal encodings (dates as
epoch-days, timestamps as epoch-millis) to real values for the target column
types, and commits Kafka offsets only after the batch is applied.
"""
import base64
import datetime as dt
import json
import threading
import time

from services import db_probe
from services.engine_settings import get_engine

PG = {"postgres", "postgresql"}


def _convert(value, target_type):
    if value is None:
        return None
    t = target_type.lower()
    if t == "date" and isinstance(value, int):
        return dt.date(1970, 1, 1) + dt.timedelta(days=value)
    if t.startswith(("timestamp", "datetime")) and isinstance(value, int):
        if value > 10**14:  # micros
            return dt.datetime.fromtimestamp(value / 1_000_000, dt.timezone.utc).replace(tzinfo=None)
        return dt.datetime.fromtimestamp(value / 1000, dt.timezone.utc).replace(tzinfo=None)
    if t == "boolean" and isinstance(value, int):
        return bool(value)
    if t in ("json", "jsonb") and isinstance(value, (dict, list)):
        return json.dumps(value)
    if t == "bytea" and isinstance(value, str):
        try:
            return base64.b64decode(value)
        except Exception:
            return value
    return value


class Applier(threading.Thread):
    def __init__(self, mig, source_ep, target_ep, on_progress):
        super().__init__(daemon=True, name=f"applier-{mig['id']}")
        self.mig = mig
        self.source_ep = source_ep
        self.target_ep = target_ep
        self.on_progress = on_progress
        self.stop_event = threading.Event()
        self.stats = {"eventsApplied": 0, "snapshotComplete": False,
                      "lastEventAt": None, "perTable": {}, "error": None,
                      "recentChanges": []}
        self._coltypes = {}   # table -> {col: target type}
        self._pks = {}        # table -> [pk cols]

    # -- setup ---------------------------------------------------------------
    def _prepare(self):
        from services import schema_translate

        for t in self.mig["tables"]:
            if not t["include"]:
                continue
            cols = schema_translate.translate_columns(
                self.source_ep, self.target_ep["engine"], t["name"])
            self._coltypes[t["name"]] = {c["name"]: c["type"] for c in cols}
            self._pks[t["name"]] = [c["name"] for c in cols if c["primaryKey"]]
            self.stats["perTable"][t["name"]] = 0

    def _record_change(self, table, payload):
        """Append one applied change to the recentChanges ring buffer
        (newest first, capped at 100) for the live change stream."""
        label = {"c": "insert", "u": "update", "d": "delete", "r": "read"}.get(payload.get("op"))
        if label is None:
            return
        source = payload.get("before") if payload.get("op") == "d" else payload.get("after")
        parts = []
        for pk in self._pks.get(table) or []:
            if source and source.get(pk) is not None:
                parts.append(f"{pk}={source.get(pk)}")
        key = ", ".join(parts)
        if len(key) > 40:
            key = key[:40]
        entry = {
            "ts": dt.datetime.now(dt.timezone.utc).isoformat(),
            "table": table,
            "op": label,
            "key": key,
        }
        buf = self.stats["recentChanges"]
        buf.insert(0, entry)
        del buf[100:]

    def topics(self):
        prefix = self.mig["id"]
        if self.source_ep["engine"] in PG:
            scope = "public"
        else:
            scope = self.source_ep["database"]
        return [f"{prefix}.{scope}.{t['name']}"
                for t in self.mig["tables"] if t["include"]]

    # -- apply -----------------------------------------------------------------
    def _apply(self, conn, table, payload):
        op = payload.get("op")
        coltypes = self._coltypes[table]
        pks = self._pks[table]
        is_pg = self.target_ep["engine"] in PG
        q = '"' if is_pg else "`"

        def rows_of(d):
            return {k: _convert(v, coltypes.get(k, "text"))
                    for k, v in (d or {}).items() if k in coltypes}

        if op in ("r", "c", "u"):
            row = rows_of(payload.get("after"))
            if not row:
                return
            cols = list(row.keys())
            collist = ", ".join(f"{q}{c}{q}" for c in cols)
            ph = ", ".join(["%s"] * len(cols))
            if is_pg and pks:
                upd = ", ".join(f"{q}{c}{q}=EXCLUDED.{q}{c}{q}" for c in cols if c not in pks)
                sql = (f"INSERT INTO {q}{table}{q} ({collist}) VALUES ({ph}) "
                       f"ON CONFLICT ({', '.join(q + p + q for p in pks)}) "
                       + (f"DO UPDATE SET {upd}" if upd else "DO NOTHING"))
            elif not is_pg:
                upd = ", ".join(f"{q}{c}{q}=VALUES({q}{c}{q})" for c in cols if c not in pks)
                sql = (f"INSERT INTO {q}{table}{q} ({collist}) VALUES ({ph})"
                       + (f" ON DUPLICATE KEY UPDATE {upd}" if upd else ""))
            else:
                sql = f"INSERT INTO {q}{table}{q} ({collist}) VALUES ({ph})"
            self._exec(conn, sql, [row[c] for c in cols], is_pg)
        elif op == "d" and pks:
            before = rows_of(payload.get("before"))
            where = " AND ".join(f"{q}{p}{q}=%s" for p in pks)
            self._exec(conn, f"DELETE FROM {q}{table}{q} WHERE {where}",
                       [before.get(p) for p in pks], is_pg)

    @staticmethod
    def _exec(conn, sql, params, is_pg):
        if is_pg:
            conn.execute(sql, params)
        else:
            with conn.cursor() as cur:
                cur.execute(sql, params)

    # -- main loop --------------------------------------------------------------
    def run(self):
        from kafka import KafkaConsumer

        try:
            self._prepare()
            kafka_bootstrap = get_engine()["kafkaBootstrap"]
            # Debezium creates its topics as the snapshot starts. If the
            # consumer joins its group before the topics exist, kafka-python
            # assigns it zero partitions and never recovers — so wait until
            # every expected topic is visible in cluster metadata.
            probe = KafkaConsumer(bootstrap_servers=kafka_bootstrap)
            try:
                deadline = time.time() + 120
                wanted = set(self.topics())
                while time.time() < deadline and not self.stop_event.is_set():
                    if wanted <= probe.topics():
                        break
                    time.sleep(1)
            finally:
                probe.close()
            consumer = KafkaConsumer(
                *self.topics(),
                bootstrap_servers=kafka_bootstrap,
                group_id=f"applier-{self.mig['id']}",
                enable_auto_commit=False,
                auto_offset_reset="earliest",
                value_deserializer=lambda b: json.loads(b.decode("utf-8")) if b else None,
                consumer_timeout_ms=1000,
            )
            conn = db_probe.connect(self.target_ep)
            idle_since = time.time()
            got_any = False
            while not self.stop_event.is_set():
                batches = consumer.poll(timeout_ms=500)
                applied_now = 0
                for _tp, records in batches.items():
                    for rec in records:
                        if rec.value is None:  # tombstone; the 'd' already applied
                            continue
                        table = rec.topic.rsplit(".", 1)[-1]
                        if table in self._coltypes:
                            self._apply(conn, table, rec.value)
                            self._record_change(table, rec.value)
                            applied_now += 1
                            self.stats["perTable"][table] += 1
                if applied_now:
                    consumer.commit()
                    got_any = True
                    idle_since = time.time()
                    self.stats["eventsApplied"] += applied_now
                    self.stats["lastEventAt"] = dt.datetime.now(dt.timezone.utc).isoformat()
                    self.on_progress(self.stats)
                elif got_any and not self.stats["snapshotComplete"] \
                        and time.time() - idle_since > 3:
                    # Stream went quiet after data flowed: snapshot phase done,
                    # we are now tailing live changes.
                    self.stats["snapshotComplete"] = True
                    self.on_progress(self.stats)
            consumer.close()
            conn.close()
        except Exception as e:  # surfaced on the migration detail
            self.stats["error"] = str(e)
            self.on_progress(self.stats)

    def stop(self):
        self.stop_event.set()
