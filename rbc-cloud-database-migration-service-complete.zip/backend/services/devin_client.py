"""Thin client for the Devin Cloud API (https://api.devin.ai/v1).

Behind the same interface this module runs in one of two modes:

- "live"  — DEVIN_API_KEY is set in the environment. Real HTTP calls are made
            against DEVIN_API_BASE (default https://api.devin.ai/v1).
- "stub"  — no key configured. A deterministic, clearly-labeled stub session
            is synthesized instead so the rest of the product (UI, orchestrator,
            review flow) can be built and demoed before a real subscription
            exists. Swapping to live mode later needs only the env var.

Nothing in here ever raises: network/HTTP failures are converted into
{"status": "error", "detail": str(e), ...} dicts so callers can always persist
a result.
"""
import datetime as dt
import os
import uuid

import requests

STATUS_MAP = {
    "new": "working",
    "working": "working",
    "blocked": "blocked",
    "finished": "finished",
    "suspended": "error",
    "expired": "error",
}

STUB_WORKING_SECONDS = 75


def base():
    return os.environ.get("DEVIN_API_BASE", "https://api.devin.ai/v1")


def _api_key():
    return os.environ.get("DEVIN_API_KEY")


def configured():
    return bool(_api_key())


def _extract_pr_url(data):
    try:
        prs = data.get("pull_requests") or []
        if prs:
            u = prs[0].get("pr_url") or prs[0].get("url")
            if u:
                return u
    except Exception:
        pass
    try:
        so = data.get("structured_output") or {}
        u = so.get("pr_url") or so.get("prUrl")
        if u:
            return u
    except Exception:
        pass
    return None


def create_session(prompt, title=None):
    """Create a Devin session for the given prompt. Never raises."""
    if not configured():
        return {
            "sessionId": f"stub-{uuid.uuid4().hex[:8]}",
            "mode": "stub",
            "status": "working",
            "url": None,
            "prUrl": None,
            "detail": "Stub session — no Devin API key configured",
        }
    try:
        body = {"prompt": prompt}
        if title:
            body["title"] = title
        resp = requests.post(
            f"{base()}/sessions",
            json=body,
            headers={"Authorization": f"Bearer {_api_key()}"},
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json() if resp.content else {}
        session_id = data.get("session_id") or data.get("id") or data.get("sessionId")
        url = data.get("url") or data.get("session_url")
        status_raw = data.get("status") or "working"
        status = STATUS_MAP.get(status_raw, "working")
        return {
            "sessionId": session_id,
            "mode": "live",
            "status": status,
            "url": url,
            "prUrl": _extract_pr_url(data),
            "detail": data.get("status_detail") or data.get("detail") or "",
        }
    except Exception as e:
        return {
            "sessionId": None,
            "mode": "live",
            "status": "error",
            "url": None,
            "prUrl": None,
            "detail": str(e),
        }


def get_session(session_id, created_at=None):
    """Fetch current session status. Never raises.

    created_at: ISO timestamp the caller stored when the (stub) session was
    created; used only in stub mode to deterministically age the session.
    """
    if not configured():
        elapsed = 0.0
        if created_at:
            try:
                created_dt = dt.datetime.fromisoformat(created_at)
                if created_dt.tzinfo is None:
                    created_dt = created_dt.replace(tzinfo=dt.timezone.utc)
                elapsed = (dt.datetime.now(dt.timezone.utc) - created_dt).total_seconds()
            except Exception:
                elapsed = 0.0
        if elapsed < STUB_WORKING_SECONDS:
            return {
                "sessionId": session_id,
                "mode": "stub",
                "status": "working",
                "url": None,
                "prUrl": None,
                "detail": "Stub session — no Devin API key configured",
            }
        return {
            "sessionId": session_id,
            "mode": "stub",
            "status": "blocked",
            "url": None,
            "prUrl": None,
            "detail": "Waiting for review of the generated changes",
        }
    try:
        resp = requests.get(
            f"{base()}/sessions/{session_id}",
            headers={"Authorization": f"Bearer {_api_key()}"},
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json() if resp.content else {}
        status_raw = data.get("status") or "working"
        status = STATUS_MAP.get(status_raw, "working")
        return {
            "sessionId": session_id,
            "mode": "live",
            "status": status,
            "url": data.get("url") or data.get("session_url"),
            "prUrl": _extract_pr_url(data),
            "detail": data.get("status_detail") or data.get("detail") or "",
        }
    except Exception as e:
        return {
            "sessionId": session_id,
            "mode": "live",
            "status": "error",
            "url": None,
            "prUrl": None,
            "detail": str(e),
        }
