"""Thin client for the Kafka Connect REST API (the cdc-engine repo)."""
import requests

from services.engine_settings import get_engine

TIMEOUT = 10


def _base():
    return get_engine()["connectUrl"].rstrip("/")


def _url(path):
    return _base() + path


def cluster_info():
    try:
        r = requests.get(_url("/"), timeout=3)
        return {"up": r.ok, "version": r.json().get("version") if r.ok else None}
    except requests.RequestException as e:
        return {"up": False, "error": str(e)}


def list_connectors():
    r = requests.get(_url("/connectors"), timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def create_or_update(name, cfg):
    r = requests.put(_url(f"/connectors/{name}/config"),
                     json=cfg, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def get_status(name):
    try:
        r = requests.get(_url(f"/connectors/{name}/status"), timeout=TIMEOUT)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()
    except requests.RequestException:
        return None


def pause(name):
    requests.put(_url(f"/connectors/{name}/pause"), timeout=TIMEOUT)


def resume(name):
    requests.put(_url(f"/connectors/{name}/resume"), timeout=TIMEOUT)


def delete(name):
    try:
        requests.delete(_url(f"/connectors/{name}"), timeout=TIMEOUT)
    except requests.RequestException:
        pass
