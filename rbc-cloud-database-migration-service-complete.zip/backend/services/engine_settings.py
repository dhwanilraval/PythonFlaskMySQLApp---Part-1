"""Resolves which Debezium/Kafka Connect deployment the backend talks to.

Resolution order: state-stored override (state.settings.engine) -> env vars
(CONNECT_URL / KAFKA_BOOTSTRAP) -> built-in defaults. This lets the same
backend point at different "engines" (local rig, staging, etc.) without code
edits or restarts.
"""
import requests

import config
import state

DEFAULT_CONNECT_URL = "http://127.0.0.1:8083"
DEFAULT_KAFKA_BOOTSTRAP = "127.0.0.1:9092"
DEFAULT_LABEL = "Local rig"

PROBE_TIMEOUT = 5


def get_engine():
    s = state.get_state()
    override = (s.get("settings") or {}).get("engine")
    if override:
        return {
            "label": override.get("label") or DEFAULT_LABEL,
            "connectUrl": override.get("connectUrl") or DEFAULT_CONNECT_URL,
            "kafkaBootstrap": override.get("kafkaBootstrap") or DEFAULT_KAFKA_BOOTSTRAP,
            "source": "settings",
        }

    env_connect = __import__("os").environ.get("CONNECT_URL")
    env_kafka = __import__("os").environ.get("KAFKA_BOOTSTRAP")
    if env_connect or env_kafka:
        return {
            "label": DEFAULT_LABEL,
            "connectUrl": env_connect or config.CONNECT_URL,
            "kafkaBootstrap": env_kafka or config.KAFKA_BOOTSTRAP,
            "source": "env",
        }

    return {
        "label": DEFAULT_LABEL,
        "connectUrl": config.CONNECT_URL,
        "kafkaBootstrap": config.KAFKA_BOOTSTRAP,
        "source": "default",
    }


def set_engine(label, connect_url, kafka_bootstrap):
    def _mutate(s):
        s.setdefault("settings", {})
        s["settings"]["engine"] = {
            "label": label or DEFAULT_LABEL,
            "connectUrl": connect_url,
            "kafkaBootstrap": kafka_bootstrap,
        }
        return s["settings"]["engine"]

    state.mutate(_mutate)
    return get_engine()


def probe(connect_url):
    try:
        r = requests.get(connect_url.rstrip("/") + "/", timeout=PROBE_TIMEOUT)
        if not r.ok:
            return {"up": False, "error": f"HTTP {r.status_code}"}
        body = r.json() if r.content else {}
        return {
            "up": True,
            "version": body.get("version"),
            "clusterId": body.get("kafka_cluster_id") or body.get("clusterId"),
        }
    except requests.RequestException as e:
        return {"up": False, "error": str(e)}
