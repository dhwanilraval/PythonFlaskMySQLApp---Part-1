"""Live probes against source/target databases: test, inventory, columns,
row counts and sampled rows. Engines: postgres, mariadb, mysql."""
import time

import config

PG_ENGINES = {"postgres", "postgresql"}
MY_ENGINES = {"mariadb", "mysql"}


def _register_str_loaders(conn):
    """This PG build returns text-family columns as bytes via psycopg's
    binary protocol path. Force str decoding for name/text/bpchar/varchar."""
    from psycopg.adapt import Loader

    class _StrLoader(Loader):
        def load(self, data):
            if isinstance(data, (bytes, bytearray, memoryview)):
                return bytes(data).decode("utf-8", "replace")
            return data

    for oid in (19, 25, 1042, 1043):
        conn.adapters.register_loader(oid, _StrLoader)


def pg_conn(ep):
    import psycopg

    conn = psycopg.connect(
        host=ep["host"], port=ep["port"], dbname=ep["database"],
        user=ep["user"], password=config.vault_password(ep["credentialRef"]),
        connect_timeout=5, autocommit=True,
    )
    try:
        _register_str_loaders(conn)
    except Exception:
        pass
    return conn


def my_conn(ep):
    import pymysql

    return pymysql.connect(
        host=ep["host"], port=ep["port"], database=ep["database"],
        user=ep["user"], password=config.vault_password(ep["credentialRef"]),
        connect_timeout=5, autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


def connect(ep):
    return pg_conn(ep) if ep["engine"] in PG_ENGINES else my_conn(ep)


def my_query(conn, sql, params=None):
    """pymysql has no Connection.execute — run via a DictCursor."""
    with conn.cursor() as cur:
        cur.execute(sql, params or ())
        return cur.fetchall()


def test_endpoint(ep):
    t0 = time.time()
    try:
        with connect(ep) as c:
            if ep["engine"] in PG_ENGINES:
                row = c.execute("select version()").fetchone()
                version = row[0].split(",")[0]
            else:
                row = my_query(c, "select version() as v")[0]
                version = "MariaDB/MySQL " + row["v"]
        return {"ok": True, "latencyMs": round((time.time() - t0) * 1000), "version": version}
    except Exception as e:  # surfaced to the UI as the test result
        return {"ok": False, "error": str(e).strip().split("\n")[0]}


def list_tables(ep):
    """[{name, rows, sizeBytes, primaryKey:[cols]}] for user tables."""
    out = []
    with connect(ep) as c:
        if ep["engine"] in PG_ENGINES:
            names = [r[0] for r in c.execute(
                "select tablename from pg_tables where schemaname='public' order by 1")]
            for t in names:
                n = c.execute(f'select count(*) from "{t}"').fetchone()[0]
                size = c.execute(
                    "select pg_total_relation_size(%s)", (f'public."{t}"',)).fetchone()[0]
                pk = [r[0] for r in c.execute(
                    """select a.attname from pg_index i
                       join pg_attribute a on a.attrelid=i.indrelid and a.attnum=any(i.indkey)
                       where i.indrelid=%s::regclass and i.indisprimary order by a.attnum""",
                    (f'public."{t}"',))]
                out.append({"name": t, "rows": n, "sizeBytes": size, "primaryKey": pk})
        else:
            rows = my_query(c,
                """select table_name as t from information_schema.tables
                   where table_schema=%s and table_type='BASE TABLE' order by 1""",
                (ep["database"],))
            for r in rows:
                t = r["t"]
                n = my_query(c, f"select count(*) as n from `{t}`")[0]["n"]
                sz = my_query(c,
                    """select coalesce(data_length+index_length,0) as s from information_schema.tables
                       where table_schema=%s and table_name=%s""",
                    (ep["database"], t))[0]["s"]
                pkrows = my_query(c,
                    """select column_name as c from information_schema.key_column_usage
                       where table_schema=%s and table_name=%s and constraint_name='PRIMARY'
                       order by ordinal_position""", (ep["database"], t))
                out.append({"name": t, "rows": n, "sizeBytes": int(sz or 0),
                            "primaryKey": [x["c"] for x in pkrows]})
    return out


def get_columns(ep, table):
    """Column metadata used for DDL translation and value conversion."""
    cols = []
    with connect(ep) as c:
        if ep["engine"] in PG_ENGINES:
            rows = c.execute(
                """select column_name, data_type, udt_name, character_maximum_length,
                          numeric_precision, numeric_scale, is_nullable, column_default
                   from information_schema.columns
                   where table_schema='public' and table_name=%s order by ordinal_position""",
                (table,)).fetchall()
            pk = {r[0] for r in c.execute(
                """select a.attname from pg_index i
                   join pg_attribute a on a.attrelid=i.indrelid and a.attnum=any(i.indkey)
                   where i.indrelid=%s::regclass and i.indisprimary""", (f'public."{table}"',))}
            for name, dtype, udt, clen, prec, scale, nullable, default in rows:
                cols.append({"name": name, "dataType": dtype, "udt": udt,
                             "length": clen, "precision": prec, "scale": scale,
                             "nullable": nullable == "YES", "default": default,
                             "primaryKey": name in pk})
        else:
            rows = my_query(c,
                """select column_name as name, data_type as dt, column_type as ct,
                          is_nullable as nullable, column_key as ck, extra, column_default as dflt
                   from information_schema.columns
                   where table_schema=%s and table_name=%s order by ordinal_position""",
                (ep["database"], table))
            for r in rows:
                cols.append({"name": r["name"], "dataType": r["dt"], "columnType": r["ct"],
                             "nullable": r["nullable"] == "YES",
                             "primaryKey": r["ck"] == "PRI",
                             "autoIncrement": "auto_increment" in (r["extra"] or ""),
                             "default": r["dflt"]})
    return cols


def row_count(ep, table):
    with connect(ep) as c:
        if ep["engine"] in PG_ENGINES:
            return c.execute(f'select count(*) from "{table}"').fetchone()[0]
        return my_query(c, f"select count(*) as n from `{table}`")[0]["n"]


def sample_rows(ep, table, pk_cols, limit=25):
    """Return {pk_tuple_str: row_dict} for a deterministic sample (first N by PK)."""
    if not pk_cols:
        return {}
    q = ", ".join(f'"{c}"' if ep["engine"] in PG_ENGINES else f"`{c}`" for c in pk_cols)
    tbl = f'"{table}"' if ep["engine"] in PG_ENGINES else f"`{table}`"
    out = {}
    with connect(ep) as c:
        if ep["engine"] in PG_ENGINES:
            cur = c.execute(f"select * from {tbl} order by {q} limit {int(limit)}")
            names = [d.name for d in cur.description]
            for row in cur.fetchall():
                d = dict(zip(names, row))
                out["|".join(str(d[p]) for p in pk_cols)] = d
        else:
            for d in my_query(c, f"select * from {tbl} order by {q} limit {int(limit)}"):
                out["|".join(str(d[p]) for p in pk_cols)] = d
    return out
