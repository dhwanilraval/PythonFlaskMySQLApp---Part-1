"""Schema translation: read source column metadata, emit target DDL.

Cross-engine paths implemented: MariaDB/MySQL -> PostgreSQL and
PostgreSQL -> MariaDB/MySQL. Same-engine paths copy the source types with
identity mapping.
"""
import re

from services import db_probe

PG = {"postgres", "postgresql"}


def _mysql_to_pg(col):
    ct = (col.get("columnType") or "").lower()
    dt = (col.get("dataType") or "").lower()
    m = re.match(r"(\w+)(?:\((\d+)(?:,(\d+))?\))?", ct)
    base, a1, a2 = (m.group(1), m.group(2), m.group(3)) if m else (dt, None, None)
    unsigned = "unsigned" in ct
    if base == "tinyint":
        return "boolean" if a1 == "1" else "smallint"
    if base in ("smallint",):
        return "smallint"
    if base in ("mediumint", "int"):
        return "bigint" if unsigned else "integer"
    if base == "bigint":
        return "bigint"
    if base in ("decimal", "numeric"):
        return f"numeric({a1 or 10},{a2 or 0})"
    if base == "double":
        return "double precision"
    if base == "float":
        return "real"
    if base == "varchar":
        return f"varchar({a1 or 255})"
    if base == "char":
        return f"char({a1 or 1})"
    if base in ("text", "tinytext", "mediumtext", "longtext"):
        return "text"
    if base == "datetime":
        return "timestamp"
    if base == "timestamp":
        return "timestamp"
    if base == "date":
        return "date"
    if base == "time":
        return "time"
    if base == "json":
        return "jsonb"
    if base in ("blob", "tinyblob", "mediumblob", "longblob", "binary", "varbinary"):
        return "bytea"
    if base == "enum":
        return "text"
    if base == "year":
        return "smallint"
    return "text"


def _pg_type(col):
    dt, udt = col["dataType"], col.get("udt") or ""
    if dt == "character varying":
        return f"varchar({col['length']})" if col.get("length") else "varchar"
    if dt == "character":
        return f"char({col['length']})" if col.get("length") else "char"
    if dt == "numeric":
        if col.get("precision"):
            return f"numeric({col['precision']},{col.get('scale') or 0})"
        return "numeric"
    simple = {
        "integer": "integer", "bigint": "bigint", "smallint": "smallint",
        "text": "text", "boolean": "boolean", "date": "date",
        "double precision": "double precision", "real": "real",
        "timestamp without time zone": "timestamp",
        "timestamp with time zone": "timestamptz",
        "time without time zone": "time", "json": "json", "jsonb": "jsonb",
        "uuid": "uuid", "bytea": "bytea",
    }
    return simple.get(dt, udt or "text")


def _pg_to_mysql(col):
    dt = (col.get("dataType") or "").lower()
    if dt == "character varying":
        return f"varchar({col['length']})" if col.get("length") else "varchar(255)"
    if dt == "character":
        return f"char({col['length']})" if col.get("length") else "char(1)"
    if dt == "numeric":
        if col.get("precision"):
            return f"decimal({col['precision']},{col.get('scale') or 0})"
        return "decimal(38,10)"
    simple = {
        "integer": "int", "bigint": "bigint", "smallint": "smallint",
        "text": "text", "boolean": "tinyint(1)", "date": "date",
        "double precision": "double", "real": "float",
        # datetime(6): keep PG's microsecond precision on the MariaDB side
        "timestamp without time zone": "datetime(6)",
        "timestamp with time zone": "datetime(6)",
        "time without time zone": "time", "time with time zone": "time",
        "json": "json", "jsonb": "json",
        "uuid": "char(36)", "bytea": "blob",
    }
    return simple.get(dt, "text")


def translate_columns(source_ep, target_engine, table):
    """Return [{name, type, nullable, primaryKey}] for the target."""
    cols = db_probe.get_columns(source_ep, table)
    out = []
    for c in cols:
        if target_engine in PG:
            t = _pg_type(c) if source_ep["engine"] in PG else _mysql_to_pg(c)
        elif source_ep["engine"] in PG:
            t = _pg_to_mysql(c)
        else:  # MySQL-family -> MySQL-family: keep the column type verbatim
            t = c.get("columnType") or c["dataType"]
        out.append({"name": c["name"], "type": t, "nullable": c["nullable"],
                    "primaryKey": c["primaryKey"]})
    return out


def create_table_ddl(target_engine, table, cols):
    q = '"' if target_engine in PG else "`"
    defs = []
    for c in cols:
        d = f"{q}{c['name']}{q} {c['type']}"
        if not c["nullable"]:
            d += " NOT NULL"
        defs.append(d)
    pk = [c["name"] for c in cols if c["primaryKey"]]
    if pk:
        defs.append("PRIMARY KEY (" + ", ".join(f"{q}{p}{q}" for p in pk) + ")")
    return f"CREATE TABLE IF NOT EXISTS {q}{table}{q} (" + ", ".join(defs) + ")"


def apply_schema(source_ep, target_ep, tables):
    """Create target tables for the included tables. Returns {table: ddl}."""
    applied = {}
    with db_probe.connect(target_ep) as conn:
        for t in tables:
            cols = translate_columns(source_ep, target_ep["engine"], t)
            ddl = create_table_ddl(target_ep["engine"], t, cols)
            if target_ep["engine"] in PG:
                conn.execute(ddl)
            else:
                with conn.cursor() as cur:
                    cur.execute(ddl)
            applied[t] = ddl
    return applied


def _source_type_str(source_ep, col):
    """Human-readable type string for the column as it exists on the source,
    using the same canonicalisation the mapping tables rely on."""
    if source_ep["engine"] in PG:
        return _pg_type(col)
    return (col.get("columnType") or col.get("dataType") or "").lower()


def preview_conversion(source_ep, tables, target_engine):
    """Read-only preview of the schema conversion for the given tables.

    Returns [{table, sourceColumns:[{name,type}],
              targetColumns:[{name, sourceType, targetType, changed}],
              ddl}] — reuses the same type-mapping tables as
    translate_columns/create_table_ddl without touching the target DB.
    """
    out = []
    for t in tables:
        cols = db_probe.get_columns(source_ep, t)
        source_columns = []
        target_columns = []
        mapped_cols = []
        for c in cols:
            src_type = _source_type_str(source_ep, c)
            if target_engine in PG:
                tgt_type = _pg_type(c) if source_ep["engine"] in PG else _mysql_to_pg(c)
            elif source_ep["engine"] in PG:
                tgt_type = _pg_to_mysql(c)
            else:
                tgt_type = c.get("columnType") or c["dataType"]
            changed = str(src_type).lower() != str(tgt_type).lower()
            source_columns.append({"name": c["name"], "type": src_type})
            target_columns.append({
                "name": c["name"], "sourceType": src_type,
                "targetType": tgt_type, "changed": changed,
            })
            mapped_cols.append({
                "name": c["name"], "type": tgt_type,
                "nullable": c["nullable"], "primaryKey": c["primaryKey"],
            })
        ddl = create_table_ddl(target_engine, t, mapped_cols)
        out.append({
            "table": t, "sourceColumns": source_columns,
            "targetColumns": target_columns, "ddl": ddl,
        })
    return out
