import datetime as dt
import uuid

from flask import Blueprint, jsonify, request

import state as state_mod
from services import db_probe, schema_translate

bp = Blueprint("endpoints", __name__, url_prefix="/api/endpoints")


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


@bp.get("")
def list_endpoints():
    return jsonify(state_mod.get_state()["endpoints"])


@bp.post("")
def create_endpoint():
    body = request.get_json(force=True)
    ep = {
        "id": "ep-" + uuid.uuid4().hex[:8],
        "name": body["name"], "role": body["role"], "engine": body["engine"],
        "host": body["host"], "port": int(body["port"]),
        "database": body["database"], "user": body["user"],
        "credentialRef": body["credentialRef"],
        "sslMode": body.get("sslMode", "disable"),
        "lastTest": None, "createdAt": _now(),
    }
    state_mod.mutate(lambda s: s["endpoints"].append(ep))
    return jsonify(ep), 201


@bp.post("/<ep_id>/test")
def test(ep_id):
    s = state_mod.get_state()
    ep = state_mod.find_endpoint(s, ep_id)
    if not ep:
        return jsonify({"error": "endpoint not found"}), 404
    result = db_probe.test_endpoint(ep)
    result["at"] = _now()

    def save(st):
        e = state_mod.find_endpoint(st, ep_id)
        if e:
            e["lastTest"] = result
    state_mod.mutate(save)
    return jsonify(result)


@bp.get("/<ep_id>/tables")
def tables(ep_id):
    s = state_mod.get_state()
    ep = state_mod.find_endpoint(s, ep_id)
    if not ep:
        return jsonify({"error": "endpoint not found"}), 404
    try:
        return jsonify(db_probe.list_tables(ep))
    except Exception as e:
        return jsonify({"error": str(e)}), 502


@bp.post("/<ep_id>/conversion-preview")
def conversion_preview(ep_id):
    """Read-only preview of the schema conversion to targetEngine for this
    endpoint's tables (or a subset). No target connection, no DDL executed."""
    s = state_mod.get_state()
    ep = state_mod.find_endpoint(s, ep_id)
    if not ep:
        return jsonify({"error": "endpoint not found"}), 404

    body = request.get_json(force=True, silent=True) or {}
    target_engine = (body.get("targetEngine") or "").strip().lower()
    if not target_engine:
        return jsonify({"error": "targetEngine is required"}), 400

    requested = body.get("tables")

    try:
        inventory = db_probe.list_tables(ep)
    except Exception as e:
        return jsonify({"error": str(e)}), 502

    names = [t["name"] for t in inventory]
    if requested:
        wanted = set(requested)
        names = [n for n in names if n in wanted]

    try:
        tables_out = schema_translate.preview_conversion(ep, names, target_engine)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    return jsonify({"tables": tables_out})


@bp.delete("/<ep_id>")
def delete(ep_id):
    def rm(s):
        s["endpoints"] = [e for e in s["endpoints"] if e["id"] != ep_id]
    state_mod.mutate(rm)
    return jsonify({"deleted": ep_id})
