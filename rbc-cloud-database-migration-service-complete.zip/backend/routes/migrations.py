import datetime as dt
import uuid

from flask import Blueprint, jsonify, request

import state as state_mod
from services import devin_client, orchestrator

bp = Blueprint("migrations", __name__, url_prefix="/api/migrations")

STAGES = ["discover", "convert", "replicate", "validate", "cutover"]
CODE_DECISIONS = {"approved", "changes-requested"}


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _public(mig):
    return mig


@bp.get("")
def list_migrations():
    return jsonify([_public(m) for m in state_mod.get_state()["migrations"]])


@bp.post("")
def create_migration():
    body = request.get_json(force=True)
    s = state_mod.get_state()
    src = state_mod.find_endpoint(s, body["sourceEndpointId"])
    tgt = state_mod.find_endpoint(s, body["targetEndpointId"])
    if not src or not tgt:
        return jsonify({"error": "source/target endpoint not found"}), 400
    mig_id = "mig-" + uuid.uuid4().hex[:8]
    mig = {
        "id": mig_id, "name": body["name"],
        "sourceEndpointId": src["id"], "targetEndpointId": tgt["id"],
        "sourceEngine": src["engine"], "targetEngine": tgt["engine"],
        "tables": [{"name": t["name"], "include": bool(t.get("include", True)),
                    "primaryKey": t.get("primaryKey", []),
                    "sourceRows": t.get("rows"), "targetRows": 0}
                   for t in body["tables"]],
        "settings": body.get("settings", {"fullLoad": True, "cdc": True, "validate": True}),
        "codeRefactoring": body.get("codeRefactoring", {"enabled": False}),
        "stages": {st: "pending" for st in STAGES},
        "status": "draft", "connectorName": f"{mig_id}-source",
        "progress": {"eventsApplied": 0, "snapshotComplete": False, "perTable": {}},
        "validation": None, "codeTrack": None, "inventory": None,
        "events": [{"ts": _now(), "msg": "Migration created from wizard"}],
        "createdAt": _now(),
    }
    state_mod.mutate(lambda st: st["migrations"].append(mig))
    return jsonify(mig), 201


@bp.get("/<mig_id>")
def get_migration(mig_id):
    mig = state_mod.find_migration(state_mod.get_state(), mig_id)
    if not mig:
        return jsonify({"error": "migration not found"}), 404
    return jsonify(_public(mig))


@bp.post("/<mig_id>/stages/<stage>/run")
def run_stage(mig_id, stage):
    if stage not in STAGES:
        return jsonify({"error": f"unknown stage {stage}"}), 400
    try:
        mig = orchestrator.run_stage(mig_id, stage)
        return jsonify(_public(mig))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@bp.post("/<mig_id>/run-all")
def run_all(mig_id):
    """Convenience for tests/smoke: discover -> convert -> replicate."""
    try:
        orchestrator.run_stage(mig_id, "discover")
        orchestrator.run_stage(mig_id, "convert")
        mig = orchestrator.run_stage(mig_id, "replicate")
        return jsonify(_public(mig))
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@bp.post("/<mig_id>/code-track/items/<item_id>/review")
def review_code_item(mig_id, item_id):
    """Review a code-track item (approve / request changes). This is parallel
    to the data track and is NOT subject to the completed-migration lock
    that run_stage enforces.
    """
    body = request.get_json(force=True) or {}
    decision = body.get("decision")
    if decision not in CODE_DECISIONS:
        return jsonify({"error": "decision must be 'approved' or 'changes-requested'"}), 400

    def apply(s):
        mig = state_mod.find_migration(s, mig_id)
        if not mig:
            return {"error": "migration"}
        ct = mig.get("codeTrack") or {}
        items = ct.get("items") or []
        item = next((it for it in items if it["id"] == item_id), None)
        if not item:
            return {"error": "item"}
        item["status"] = decision
        ct["summary"] = {
            "total": len(items),
            "approved": sum(1 for it in items if it["status"] == "approved"),
        }
        mig["codeTrack"] = ct
        mig.setdefault("events", []).insert(0, {"ts": _now(), "msg": f"Code track: item {item_id} {decision}"})
        mig["events"] = mig["events"][:200]
        return {"migration": mig}

    result = state_mod.mutate(apply)
    if result.get("error") == "migration":
        return jsonify({"error": "migration not found"}), 404
    if result.get("error") == "item":
        return jsonify({"error": "code track item not found"}), 404
    return jsonify(_public(result["migration"]))


@bp.post("/<mig_id>/code-track/refresh")
def refresh_code_track(mig_id):
    mig = state_mod.find_migration(state_mod.get_state(), mig_id)
    if not mig:
        return jsonify({"error": "migration not found"}), 404
    if not mig.get("codeTrack"):
        return jsonify({"error": "migration has no code track"}), 400

    devin = orchestrator.ensure_devin_session(mig_id)

    session_info = None
    if devin and devin.get("sessionId"):
        session_info = devin_client.get_session(devin["sessionId"], created_at=devin.get("createdAt"))

    def apply(s):
        m = state_mod.find_migration(s, mig_id)
        if not m:
            return {"error": "migration"}
        ct = m.get("codeTrack") or {}
        dv = ct.get("devin") or {}

        status_changed = False
        if session_info is not None:
            old_status = dv.get("status")
            if session_info.get("status") is not None:
                dv["status"] = session_info.get("status")
            if session_info.get("prUrl") is not None:
                dv["prUrl"] = session_info.get("prUrl")
            if session_info.get("detail") is not None:
                dv["detail"] = session_info.get("detail")
            ct["devin"] = dv
            status_changed = old_status != dv.get("status")

        has_session = bool(dv.get("sessionId"))
        steps = ct.get("steps") or []

        for step in steps:
            name = step.get("name")
            if name == "Scan repo":
                if has_session:
                    step["status"] = "done"
            elif name == "Generate PRs":
                if dv.get("status") == "finished" or dv.get("prUrl"):
                    step["status"] = "done"

        ct["steps"] = steps

        m["codeTrack"] = ct

        if status_changed:
            m.setdefault("events", []).insert(0, {
                "ts": _now(), "stage": "code",
                "msg": f"Devin session {dv.get('status')}",
            })
            m["events"] = m["events"][:200]

        return {"migration": m}

    result = state_mod.mutate(apply)
    if result.get("error") == "migration":
        return jsonify({"error": "migration not found"}), 404
    return jsonify(_public(result["migration"]))


@bp.delete("/<mig_id>")
def delete_migration(mig_id):
    try:
        orchestrator.stop_migration(mig_id)
    except Exception:
        pass

    def rm(s):
        s["migrations"] = [m for m in s["migrations"] if m["id"] != mig_id]
    state_mod.mutate(rm)
    return jsonify({"deleted": mig_id})
