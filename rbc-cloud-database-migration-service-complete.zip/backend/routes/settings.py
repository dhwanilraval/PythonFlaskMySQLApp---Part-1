import re

from flask import Blueprint, jsonify, request

from services import devin_client, engine_settings

bp = Blueprint("settings", __name__, url_prefix="/api/settings")

KAFKA_RE = re.compile(r"^[^,\s:]+:\d+$")


@bp.get("/engine")
def get_engine_settings():
    return jsonify(engine_settings.get_engine())


@bp.put("/engine")
def put_engine_settings():
    body = request.get_json(force=True) or {}
    label = body.get("label")
    connect_url = (body.get("connectUrl") or "").strip()
    kafka_bootstrap = (body.get("kafkaBootstrap") or "").strip()

    if not (connect_url.startswith("http://") or connect_url.startswith("https://")):
        return jsonify({"error": "connectUrl must start with http:// or https://"}), 400
    if not KAFKA_RE.match(kafka_bootstrap):
        return jsonify({"error": "kafkaBootstrap must look like host:port"}), 400

    effective = engine_settings.set_engine(label, connect_url, kafka_bootstrap)
    return jsonify(effective)


@bp.post("/engine/test")
def test_engine_settings():
    body = request.get_json(silent=True) or {}
    connect_url = (body.get("connectUrl") or "").strip() or engine_settings.get_engine()["connectUrl"]
    return jsonify(engine_settings.probe(connect_url))


@bp.get("/devin")
def get_devin_settings():
    """Honest status of the Devin Cloud wiring. Never exposes the key itself."""
    cfg = devin_client.configured()
    return jsonify({
        "configured": cfg,
        "base": devin_client.base(),
        "mode": "live" if cfg else "stub",
    })
