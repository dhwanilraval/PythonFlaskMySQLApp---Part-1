from flask import Flask, jsonify
from flask_cors import CORS

import config
from routes import endpoints, migrations, settings as settings_routes
from services import connect_client, engine_settings


def create_app():
    app = Flask(__name__)
    CORS(app)
    app.register_blueprint(endpoints.bp)
    app.register_blueprint(migrations.bp)
    app.register_blueprint(settings_routes.bp)

    @app.get("/api/health")
    def health():
        return jsonify({
            "ok": True,
            "connect": connect_client.cluster_info(),
            "engine": engine_settings.get_engine(),
        })

    @app.errorhandler(Exception)
    def on_error(e):
        code = getattr(e, "code", 500)
        return jsonify({"error": str(e)}), code

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=config.PORT, threaded=True)
