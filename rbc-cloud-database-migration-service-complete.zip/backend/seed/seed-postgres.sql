-- Seed for the PostgreSQL SOURCE database (ordersdb).
drop table if exists order_items, orders, products, customers, audit_log cascade;

create table customers (
  id integer primary key,
  name varchar(100) not null,
  email varchar(150) not null,
  created_at timestamp not null default now()
);
create table products (
  id integer primary key,
  sku varchar(30) not null,
  name varchar(100) not null,
  price numeric(10,2) not null
);
create table orders (
  id integer primary key,
  customer_id integer not null,
  status varchar(20) not null,
  total numeric(10,2) not null,
  created_at timestamp not null default now()
);
create table order_items (
  id integer primary key,
  order_id integer not null,
  product_id integer not null,
  qty integer not null,
  price numeric(10,2) not null
);
create table audit_log (
  id integer primary key,
  message text,
  created_at timestamp not null default now()
);

insert into customers (id, name, email) values
  (1,'Ava Stone','ava@example.com'),(2,'Ben Ortiz','ben@example.com'),
  (3,'Cleo Park','cleo@example.com'),(4,'Dev Rao','dev@example.com'),
  (5,'Eli Novak','eli@example.com'),(6,'Fay Chen','fay@example.com');
insert into products (id, sku, name, price) values
  (1,'SKU-100','Widget',19.99),(2,'SKU-200','Gadget',49.50),
  (3,'SKU-300','Doohickey',9.75),(4,'SKU-400','Thingamajig',99.00),
  (5,'SKU-500','Whatsit',4.25);
insert into orders (id, customer_id, status, total) values
  (101,1,'paid',69.48),(102,2,'paid',49.50),(103,3,'pending',109.74),
  (104,1,'shipped',19.99),(105,4,'paid',148.50),(106,5,'cancelled',9.75),
  (107,6,'paid',23.74),(108,2,'shipped',99.00);
insert into order_items (id, order_id, product_id, qty, price) values
  (1,101,1,1,19.99),(2,101,2,1,49.50),(3,102,2,1,49.50),(4,103,4,1,99.00),
  (5,103,3,1,9.75),(6,104,1,1,19.99),(7,105,2,3,49.50),(8,106,3,1,9.75),
  (9,107,1,1,19.99),(10,107,5,1,4.25),(11,108,4,1,99.00),(12,101,5,2,4.25);
insert into audit_log (id, message) values
  (1,'login ok'),(2,'password rotated'),(3,'export requested');
